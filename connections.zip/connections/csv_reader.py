"""
CSV File Reader & Streamer for ETL Validation.
Supports file inspection, schema discovery, chunked reading, and Pandas DataFrames.
"""
import os
import pandas as pd
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path


class CSVConnector:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = Path(base_dir or os.path.join(os.path.dirname(__file__), "..", "data"))
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def list_files(self) -> List[Dict[str, Any]]:
        """Lists all CSV files available in the data directory."""
        files = []
        if self.base_dir.exists():
            for p in self.base_dir.glob("*.csv"):
                files.append({
                    "filename": p.name,
                    "file_path": str(p.resolve()),
                    "size_bytes": p.stat().st_size,
                    "size_kb": round(p.stat().st_size / 1024, 2)
                })
        return files

    def get_metadata(self, file_path_or_name: str) -> Dict[str, Any]:
        """Returns row count, column count, column names, and data types."""
        path = self._resolve_path(file_path_or_name)
        if not path.exists():
            raise FileNotFoundError(f"CSV file not found: {path}")

        # Read sample for columns & datatypes
        df_sample = pd.read_csv(path, nrows=50)
        
        # Fast row count
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            row_count = sum(1 for _ in f) - 1  # subtract header

        columns = [{"name": col, "type": str(dtype)} for col, dtype in df_sample.dtypes.items()]

        return {
            "filename": path.name,
            "file_path": str(path),
            "row_count": max(0, row_count),
            "column_count": len(df_sample.columns),
            "columns": columns,
            "column_names": list(df_sample.columns)
        }

    def read_dataframe(self, file_path_or_name: str, limit: Optional[int] = None) -> pd.DataFrame:
        """Reads CSV file into a DataFrame with optional row limit."""
        path = self._resolve_path(file_path_or_name)
        return pd.read_csv(path, nrows=limit)

    def _resolve_path(self, file_path_or_name: str) -> Path:
        p = Path(file_path_or_name)
        if p.is_absolute() and p.exists():
            return p
        return self.base_dir / p.name
