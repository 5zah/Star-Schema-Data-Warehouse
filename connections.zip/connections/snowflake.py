"""
Snowflake Data Warehouse Connector and Execution Engine.
Supports both remote cloud Snowflake accounts and configured local fallback instances.
"""
import os
import sqlalchemy as sa
from sqlalchemy import text
from typing import Dict, Any, List, Optional, Tuple
import pandas as pd


class SnowflakeConnector:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._get_default_config()
        self._engine = None

    def _get_default_config(self) -> Dict[str, Any]:
        return {
            "account": os.getenv("SNOWFLAKE_ACCOUNT", ""),
            "user": os.getenv("SNOWFLAKE_USER", ""),
            "password": os.getenv("SNOWFLAKE_PASSWORD", ""),
            "warehouse": os.getenv("SNOWFLAKE_WAREHOUSE", "COMPUTE_WH"),
            "database": os.getenv("SNOWFLAKE_DATABASE", ""),
            "schema": os.getenv("SNOWFLAKE_SCHEMA", "PUBLIC"),
            "role": os.getenv("SNOWFLAKE_ROLE", "ACCOUNTADMIN"),
            "authenticator": os.getenv("SNOWFLAKE_AUTHENTICATOR", "snowflake"),
            "connection_string": os.getenv("SNOWFLAKE_CONNECTION_STRING", "")
        }

    def get_connection_url(self) -> str:
        if self.config.get("connection_string"):
            return self.config["connection_string"]
        
        account = self.config.get("account")
        user = self.config.get("user")
        pwd = self.config.get("password")
        database = self.config.get("database")
        schema = self.config.get("schema", "PUBLIC")
        warehouse = self.config.get("warehouse", "COMPUTE_WH")
        role = self.config.get("role", "ACCOUNTADMIN")
        
        if account and user and database:
            return f"snowflake://{user}:{pwd}@{account}/{database}/{schema}?warehouse={warehouse}&role={role}"
        
        # Fallback to local sample database if no credentials provided
        local_db = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data", "snowflake_sales_dw.db"))
        return f"sqlite:///{local_db}"

    def get_engine(self) -> sa.engine.Engine:
        if self._engine is None:
            url = self.get_connection_url()
            self._engine = sa.create_engine(url)
        return self._engine

    def test_connection(self) -> Tuple[bool, str]:
        """Tests live database connectivity."""
        try:
            engine = self.get_engine()
            with engine.connect() as conn:
                conn.execute(text("SELECT 1")).fetchone()
            return True, "Connected successfully to Snowflake Data Warehouse."
        except Exception as e:
            return False, f"Connection Failed: {str(e)}"

    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """Executes a SQL query and returns results as DataFrame."""
        engine = self.get_engine()
        with engine.connect() as conn:
            return pd.read_sql(text(query), conn, params=params)

    def execute_scalar(self, query: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Executes a scalar query (e.g. COUNT, SUM) directly in database."""
        engine = self.get_engine()
        with engine.connect() as conn:
            result = conn.execute(text(query), params or {})
            return result.scalar()
