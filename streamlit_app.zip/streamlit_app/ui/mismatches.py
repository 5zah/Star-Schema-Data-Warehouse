"""
Mismatches Page — ETL Reconciliation Platform.
Shows drill-down view of cell-level mismatches for a selected run.
"""
import streamlit as st
import pandas as pd
from repository.sqlite_repository import SQLiteRepository


def render_mismatches_page():
    """Streamlit page to inspect cell-level mismatches for a selected run."""
    st.title('🚨 Mismatch Drill‑Down')
    st.caption('Explore detailed record‑level validation mismatches.')

    repo = SQLiteRepository()
    
    executions = repo.list_executions(limit=100)
    if not executions:
        st.info('No execution history found.')
        return

    df_execs = pd.DataFrame(executions)
    
    # Format for dropdown
    run_options = df_execs['execution_id'].tolist()
    
    selected_run_id = st.selectbox('Select Run ID', run_options)
    
    if not selected_run_id:
        return
        
    run_details = repo.get_execution(selected_run_id)
    mismatches = run_details.get('mismatches', [])
    
    if not mismatches:
        st.success('No mismatches found for this execution – all records matched.')
        return

    st.subheader('Mismatches Overview')
    mismatches_df = pd.DataFrame(mismatches)
    
    display_df = mismatches_df.drop(columns=['id', 'execution_id'], errors='ignore')
    st.dataframe(display_df, use_container_width=True)

    # Download CSV
    csv_data = display_df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label='Download Mismatches CSV', 
        data=csv_data, 
        file_name=f'mismatches_{selected_run_id}.csv', 
        mime='text/csv'
    )

if __name__ == '__main__':
    render_mismatches_page()
