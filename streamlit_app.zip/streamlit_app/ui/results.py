"""
Test Results Page — ETL Reconciliation Platform.
Shows the execution summary and per-validation results for the most recent
or any selected historical run. Provides mismatch drill-down links.
"""
import streamlit as st
import pandas as pd
import json
from repository.sqlite_repository import SQLiteRepository


def _status_badge(status: str) -> str:
    badges = {
        "PASS": "🟢 PASS",
        "FAIL": "🔴 FAIL",
        "WARNING": "🟡 WARNING",
        "ERROR": "⚠️ ERROR",
        "SKIPPED": "⬜ SKIPPED",
    }
    return badges.get(status, status)


def page():
    """Render the Test Results page."""
    st.title("📋 Test Results")
    st.caption("View detailed validation results for any execution run.")

    repo = SQLiteRepository()
    executions = repo.list_executions(limit=50)

    if not executions:
        st.info("No executions found yet. Run a validation scenario first.")
        return

    # ----------------------------------------------------------------
    # Execution selector
    # ----------------------------------------------------------------
    exec_options = {
        e["execution_id"]: f"{e['execution_id']}  |  {e['timestamp']}  |  {e['scenario_name']}  |  {e['overall_status']}"
        for e in executions
    }
    selected_id = st.selectbox(
        "Select Execution",
        list(exec_options.keys()),
        format_func=lambda x: exec_options[x]
    )

    data = repo.get_execution(selected_id)
    if not data:
        st.error("Execution data not found.")
        return

    st.divider()

    # ----------------------------------------------------------------
    # Summary KPIs
    # ----------------------------------------------------------------
    st.subheader(f"Execution: `{data['execution_id']}`")

    overall = data.get("overall_status", "—")
    badge = _status_badge(overall)
    kpi_style = "background:#1a472a" if overall == "PASS" else "background:#5c0000"
    st.markdown(
        f'<div style="{kpi_style}; color:white; padding:10px 18px; border-radius:8px; '
        f'font-size:1.3rem; font-weight:bold; display:inline-block; margin-bottom:12px">'
        f'Overall Status: {badge}</div>',
        unsafe_allow_html=True
    )

    c1, c2, c3, c4, c5, c6 = st.columns(6)
    c1.metric("Scenario", data.get("scenario_name", "—"))
    c2.metric("Pass Rate", f"{data.get('pass_rate_pct', 0):.1f}%")
    c3.metric("Total Tests", data.get("total_validations", 0))
    c4.metric("✅ Passed", data.get("passed_count", 0))
    c5.metric("❌ Failed", data.get("failed_count", 0))
    c6.metric("Mismatches", data.get("total_mismatches", 0))

    c7, c8, c9 = st.columns(3)
    c7.metric("Rows Audited", f"{data.get('total_rows_audited', 0):,}")
    c8.metric("Cells Audited", f"{data.get('total_cells_audited', 0):,}")
    c9.metric("Duration (s)", f"{data.get('execution_duration_sec', 0):.2f}")

    st.divider()

    # ----------------------------------------------------------------
    # Per-Validation Results Table
    # ----------------------------------------------------------------
    results = data.get("results", [])
    if results:
        st.subheader("🧪 Validation Results")
        df = pd.DataFrame(results)
        display_cols = [c for c in [
            "test_name", "category", "status",
            "source_metric", "target_metric", "delta", "delta_pct",
            "mismatches_count", "execution_time_sec"
        ] if c in df.columns]
        df_display = df[display_cols].rename(columns={
            "test_name": "Test",
            "category": "Category",
            "status": "Status",
            "source_metric": "Source",
            "target_metric": "Target",
            "delta": "Delta",
            "delta_pct": "Delta %",
            "mismatches_count": "Mismatches",
            "execution_time_sec": "Duration (s)"
        })

        def colour_status(val):
            if val == "PASS":
                return "background-color: #1a472a; color: #a3ffba"
            elif val == "FAIL":
                return "background-color: #5c0000; color: #ffb3b3"
            elif val == "WARNING":
                return "background-color: #3d3000; color: #ffe680"
            return ""

        if "Status" in df_display.columns:
            styled = df_display.style.applymap(colour_status, subset=["Status"])
            st.dataframe(styled, use_container_width=True)
        else:
            st.dataframe(df_display, use_container_width=True)

        # Expand details for failed tests
        failed = df[df.get("status", pd.Series()) == "FAIL"] if "status" in df.columns else pd.DataFrame()
        if not failed.empty:
            st.subheader("🔍 Failed Test Details")
            for _, row in failed.iterrows():
                with st.expander(f"❌ {row.get('test_name', 'Unknown')}"):
                    details_raw = row.get("details_json") or row.get("details")
                    if details_raw:
                        try:
                            details = json.loads(details_raw) if isinstance(details_raw, str) else details_raw
                            st.json(details)
                        except Exception:
                            st.text(str(details_raw))
                    else:
                        st.text("No additional details available.")
    else:
        st.info("No detailed results found for this execution.")

    st.divider()

    # ----------------------------------------------------------------
    # Mismatch Preview
    # ----------------------------------------------------------------
    mismatches = data.get("mismatches", [])
    total_mm = data.get("total_mismatches", 0)
    st.subheader(f"🚨 Mismatches ({total_mm:,} total)")

    if mismatches:
        df_mm = pd.DataFrame(mismatches)
        display_mm_cols = [c for c in [
            "record_key", "validation_test", "source_column", "target_column",
            "source_value", "target_value", "difference", "status"
        ] if c in df_mm.columns]
        st.dataframe(df_mm[display_mm_cols], use_container_width=True)

        if total_mm > len(mismatches):
            st.caption(f"Showing first {len(mismatches)} of {total_mm:,} mismatches. Navigate to **Mismatch Drill-Down** for full view.")

        csv_bytes = df_mm.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="⬇️ Download Mismatches CSV",
            data=csv_bytes,
            file_name=f"{selected_id}_mismatches.csv",
            mime="text/csv"
        )
    else:
        st.success("No mismatches recorded for this execution.")

    # ----------------------------------------------------------------
    # Report Downloads
    # ----------------------------------------------------------------
    st.divider()
    st.subheader("📄 Generated Reports")
    html_path = data.get("report_html_path")
    excel_path = data.get("report_excel_path")

    col1, col2 = st.columns(2)
    with col1:
        if html_path and __import__("pathlib").Path(html_path).is_file():
            with open(html_path, "rb") as f:
                st.download_button(
                    "⬇️ Download HTML Report",
                    data=f.read(),
                    file_name=__import__("pathlib").Path(html_path).name,
                    mime="text/html"
                )
        else:
            st.caption("HTML report not available.")
    with col2:
        if excel_path and __import__("pathlib").Path(excel_path).is_file():
            with open(excel_path, "rb") as f:
                st.download_button(
                    "⬇️ Download Excel Report",
                    data=f.read(),
                    file_name=__import__("pathlib").Path(excel_path).name,
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
        else:
            st.caption("Excel report not available.")
