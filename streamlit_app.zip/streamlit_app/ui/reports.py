"""
Reports Page — ETL Reconciliation Platform.
Lists all generated HTML and Excel reconciliation reports stored in
the reports/ directory and allows downloading them.
"""
import streamlit as st
from pathlib import Path
from config.settings import REPORTS_DIR


def page():
    """Render the Reports download page."""
    st.title("📄 Reports")
    st.caption(f"All generated reconciliation reports stored in `{REPORTS_DIR}`.")

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    html_files = sorted(REPORTS_DIR.glob("*.html"), reverse=True)
    excel_files = sorted(REPORTS_DIR.glob("*.xlsx"), reverse=True)
    all_files = sorted(list(html_files) + list(excel_files), key=lambda f: f.stat().st_mtime, reverse=True)

    if not all_files:
        st.info("No reports found. Run a validation scenario to generate a report.")
        return

    st.success(f"Found {len(html_files)} HTML and {len(excel_files)} Excel report(s).")
    st.divider()

    # ----------------------------------------------------------------
    # HTML Reports
    # ----------------------------------------------------------------
    if html_files:
        st.subheader("🌐 HTML Reports")
        for f in html_files:
            col1, col2, col3 = st.columns([4, 1, 1])
            col1.text(f.name)
            col2.caption(f"{f.stat().st_size / 1024:.1f} KB")
            with col3:
                with open(f, "rb") as fh:
                    st.download_button(
                        label="⬇️ Download",
                        data=fh.read(),
                        file_name=f.name,
                        mime="text/html",
                        key=f"dl_html_{f.name}"
                    )

    # ----------------------------------------------------------------
    # Excel Reports
    # ----------------------------------------------------------------
    if excel_files:
        st.divider()
        st.subheader("📊 Excel Reports")
        for f in excel_files:
            col1, col2, col3 = st.columns([4, 1, 1])
            col1.text(f.name)
            col2.caption(f"{f.stat().st_size / 1024:.1f} KB")
            with col3:
                with open(f, "rb") as fh:
                    st.download_button(
                        label="⬇️ Download",
                        data=fh.read(),
                        file_name=f.name,
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        key=f"dl_xlsx_{f.name}"
                    )
