"""
History Page — ETL Reconciliation Platform.
Shows past execution runs with filtering by status and scenario name.
Allows downloading reports from previous runs.
"""
import streamlit as st
import pandas as pd
from pathlib import Path
from repository.sqlite_repository import SQLiteRepository


def page():
    """Render the execution History page."""
    st.title("📜 Execution History")
    st.caption("Browse and filter all past validation runs.")

    repo = SQLiteRepository()

    # ----------------------------------------------------------------
    # Filters
    # ----------------------------------------------------------------
    col1, col2, col3 = st.columns(3)
    status_options = ["ALL", "PASS", "FAIL", "WARNING", "ERROR"]
    selected_status = col1.selectbox("Filter by Status", status_options, key="hist_status")
    keyword = col2.text_input("Search Scenario", placeholder="e.g. Customer", key="hist_kw")
    limit = col3.slider("Max Rows", min_value=10, max_value=500, value=100, step=10, key="hist_limit")

    # ----------------------------------------------------------------
    # Load & display
    # ----------------------------------------------------------------
    executions = repo.list_executions(
        limit=limit,
        status_filter=selected_status if selected_status != "ALL" else None,
        scenario_filter=keyword if keyword else None,
    )

    if not executions:
        st.info("No matching history records found.")
        return

    df = pd.DataFrame(executions)
    display_cols = [c for c in [
        "execution_id", "timestamp", "scenario_name", "source_desc",
        "target_desc", "overall_status", "pass_rate_pct",
        "total_validations", "passed_count", "failed_count",
        "total_mismatches", "execution_duration_sec"
    ] if c in df.columns]

    df_display = df[display_cols].rename(columns={
        "execution_id": "ID",
        "timestamp": "Timestamp",
        "scenario_name": "Scenario",
        "source_desc": "Source",
        "target_desc": "Target",
        "overall_status": "Status",
        "pass_rate_pct": "Pass %",
        "total_validations": "Tests",
        "passed_count": "✅ Pass",
        "failed_count": "❌ Fail",
        "total_mismatches": "Mismatches",
        "execution_duration_sec": "Duration (s)"
    })

    def colour_status(val):
        if val == "PASS":
            return "background-color: #1a472a; color: #a3ffba"
        elif val == "FAIL":
            return "background-color: #5c0000; color: #ffb3b3"
        elif val == "WARNING":
            return "background-color: #3d3000; color: #ffe680"
        return ""

    if "Status" in df_display.columns:
        styled = df_display.style.applymap(colour_status, subset=["Status"])
        st.dataframe(styled, use_container_width=True)
    else:
        st.dataframe(df_display, use_container_width=True)

    st.caption(f"Showing {len(df)} run(s).")
    st.divider()

    # ----------------------------------------------------------------
    # Per-run report download
    # ----------------------------------------------------------------
    st.subheader("⬇️ Download Report for a Specific Run")
    run_ids = df["execution_id"].tolist() if "execution_id" in df.columns else []

    if run_ids:
        selected_run_id = st.selectbox("Select Run ID", [""] + run_ids, key="hist_sel_run")
        if selected_run_id:
            run_data = repo.get_execution(selected_run_id)
            if run_data:
                col1, col2 = st.columns(2)
                html_p = run_data.get("report_html_path")
                excel_p = run_data.get("report_excel_path")

                with col1:
                    if html_p and Path(html_p).is_file():
                        with open(html_p, "rb") as f:
                            st.download_button(
                                "⬇️ HTML Report",
                                data=f.read(),
                                file_name=Path(html_p).name,
                                mime="text/html",
                                key="hist_dl_html"
                            )
                    else:
                        st.caption("HTML report not found.")

                with col2:
                    if excel_p and Path(excel_p).is_file():
                        with open(excel_p, "rb") as f:
                            st.download_button(
                                "⬇️ Excel Report",
                                data=f.read(),
                                file_name=Path(excel_p).name,
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                key="hist_dl_excel"
                            )
                    else:
                        st.caption("Excel report not found.")
