"""
Data Objects Discovery Page — ETL Reconciliation Platform.
Dynamically discovers schemas, tables, views, and columns from
Azure SQL and Snowflake using the metadata layer.
"""
import streamlit as st
import pandas as pd
from metadata.azure_sql_metadata import AzureSQLMetadata
from metadata.snowflake_metadata import SnowflakeMetadata
from connections.azure_sql import AzureSQLConnector
from connections.snowflake import SnowflakeConnector
from connections.csv_reader import CSVConnector


def _get_azure_meta() -> AzureSQLMetadata:
    """Return AzureSQLMetadata using session connector if available."""
    connector = st.session_state.get("azure_connector") or AzureSQLConnector()
    return AzureSQLMetadata(connector=connector)


def _get_snow_meta() -> SnowflakeMetadata:
    """Return SnowflakeMetadata using session connector if available."""
    connector = st.session_state.get("snowflake_connector") or SnowflakeConnector()
    return SnowflakeMetadata(connector=connector)


def page():
    """Render the Data Objects discovery page."""
    st.title("🗂️ Data Object Discovery")
    st.caption(
        "Dynamically explore schemas, tables, views, and column metadata "
        "from your connected data sources."
    )

    system = st.radio(
        "Select system to explore",
        ["Azure SQL (Source)", "Snowflake (Target)", "CSV Files"],
        horizontal=True
    )

    st.divider()

    # ----------------------------------------------------------------
    # Azure SQL Discovery
    # ----------------------------------------------------------------
    if system == "Azure SQL (Source)":
        st.subheader("🔷 Azure SQL Object Explorer")

        if st.button("🔄 Load Schemas", key="az_schemas_btn"):
            with st.spinner("Querying Azure SQL metadata…"):
                try:
                    meta = _get_azure_meta()
                    schemas = meta.get_schemas()
                    st.session_state["az_schemas"] = schemas
                except Exception as e:
                    st.error(f"Failed to retrieve schemas: {e}")

        schemas = st.session_state.get("az_schemas", [])
        if schemas:
            selected_schema = st.selectbox("Schema", schemas, key="az_sel_schema")

            col1, col2 = st.columns(2)
            with col1:
                if st.button("📋 Load Tables", key="az_tables_btn"):
                    with st.spinner(f"Loading tables from [{selected_schema}]…"):
                        try:
                            meta = _get_azure_meta()
                            tables = meta.get_tables(schema=selected_schema)
                            st.session_state["az_tables"] = tables
                        except Exception as e:
                            st.error(f"Failed to load tables: {e}")
            with col2:
                if st.button("👁️ Load Views", key="az_views_btn"):
                    with st.spinner(f"Loading views from [{selected_schema}]…"):
                        try:
                            meta = _get_azure_meta()
                            views = meta.get_views(schema=selected_schema)
                            st.session_state["az_views"] = views
                        except Exception as e:
                            st.error(f"Failed to load views: {e}")

            az_tables = st.session_state.get("az_tables", [])
            az_views = st.session_state.get("az_views", [])
            all_objects = az_tables + [f"[VIEW] {v}" for v in az_views]

            if all_objects:
                st.success(f"Found {len(az_tables)} tables and {len(az_views)} views.")
                selected_obj = st.selectbox("Select Table / View", all_objects, key="az_sel_obj")
                obj_name = selected_obj.replace("[VIEW] ", "")

                if st.button("🔍 Inspect Columns", key="az_cols_btn"):
                    with st.spinner(f"Loading columns for {obj_name}…"):
                        try:
                            meta = _get_azure_meta()
                            cols = meta.get_columns(obj_name, schema=selected_schema)
                            if cols:
                                df = pd.DataFrame(cols)
                                st.dataframe(df, use_container_width=True)
                                st.caption(f"{len(cols)} column(s) in {selected_schema}.{obj_name}")
                                # Store for configuration page
                                st.session_state["source_object"] = obj_name
                                st.session_state["source_schema"] = selected_schema
                                st.session_state["source_columns"] = [c["name"] for c in cols]
                                st.session_state["source_system"] = "azure_sql"
                                st.info("✅ Source object set. Go to **Test Configuration** to continue.")
                            else:
                                st.warning("No columns returned. Check permissions or object name.")
                        except Exception as e:
                            st.error(f"Column discovery failed: {e}")
        else:
            st.info("Click **Load Schemas** to begin discovery.")

    # ----------------------------------------------------------------
    # Snowflake Discovery
    # ----------------------------------------------------------------
    elif system == "Snowflake (Target)":
        st.subheader("❄️ Snowflake Object Explorer")

        if st.button("🔄 Load Schemas", key="sf_schemas_btn"):
            with st.spinner("Querying Snowflake metadata…"):
                try:
                    meta = _get_snow_meta()
                    schemas = meta.get_schemas()
                    st.session_state["sf_schemas"] = schemas
                except Exception as e:
                    st.error(f"Failed to retrieve schemas: {e}")

        schemas = st.session_state.get("sf_schemas", [])
        if schemas:
            selected_schema = st.selectbox("Schema", schemas, key="sf_sel_schema")

            col1, col2 = st.columns(2)
            with col1:
                if st.button("📋 Load Tables", key="sf_tables_btn"):
                    with st.spinner(f"Loading tables from [{selected_schema}]…"):
                        try:
                            meta = _get_snow_meta()
                            tables = meta.get_tables(schema=selected_schema)
                            st.session_state["sf_tables"] = tables
                        except Exception as e:
                            st.error(f"Failed to load tables: {e}")
            with col2:
                if st.button("👁️ Load Views", key="sf_views_btn"):
                    with st.spinner(f"Loading views from [{selected_schema}]…"):
                        try:
                            meta = _get_snow_meta()
                            views = meta.get_views(schema=selected_schema)
                            st.session_state["sf_views"] = views
                        except Exception as e:
                            st.error(f"Failed to load views: {e}")

            sf_tables = st.session_state.get("sf_tables", [])
            sf_views = st.session_state.get("sf_views", [])
            all_objects = sf_tables + [f"[VIEW] {v}" for v in sf_views]

            if all_objects:
                st.success(f"Found {len(sf_tables)} tables and {len(sf_views)} views.")
                selected_obj = st.selectbox("Select Table / View", all_objects, key="sf_sel_obj")
                obj_name = selected_obj.replace("[VIEW] ", "")

                if st.button("🔍 Inspect Columns", key="sf_cols_btn"):
                    with st.spinner(f"Loading columns for {obj_name}…"):
                        try:
                            meta = _get_snow_meta()
                            cols = meta.get_columns(obj_name, schema=selected_schema)
                            if cols:
                                df = pd.DataFrame(cols)
                                st.dataframe(df, use_container_width=True)
                                st.caption(f"{len(cols)} column(s) in {selected_schema}.{obj_name}")
                                st.session_state["target_object"] = obj_name
                                st.session_state["target_schema"] = selected_schema
                                st.session_state["target_columns"] = [c["name"] for c in cols]
                                st.session_state["target_system"] = "snowflake"
                                st.info("✅ Target object set. Go to **Test Configuration** to continue.")
                            else:
                                st.warning("No columns returned. Check permissions or object name.")
                        except Exception as e:
                            st.error(f"Column discovery failed: {e}")
        else:
            st.info("Click **Load Schemas** to begin discovery.")

    # ----------------------------------------------------------------
    # CSV Discovery
    # ----------------------------------------------------------------
    elif system == "CSV Files":
        st.subheader("📄 CSV File Explorer")
        import json
        from pathlib import Path
        cfg_path = Path("config") / "connections.json"
        csv_root = None
        if cfg_path.is_file():
            try:
                cfg = json.loads(cfg_path.read_text())
                csv_root = cfg.get("csv", {}).get("root")
            except Exception:
                pass

        csv_conn = CSVConnector(base_dir=csv_root)
        files = csv_conn.list_files()
        if not files:
            st.warning(f"No CSV files found in `{csv_conn.base_dir}`. Check the Connections page.")
        else:
            st.success(f"Found {len(files)} CSV file(s).")
            df_files = pd.DataFrame(files)
            st.dataframe(df_files, use_container_width=True)

            selected_file = st.selectbox(
                "Select file to inspect",
                [f["filename"] for f in files],
                key="csv_sel_file"
            )
            if st.button("🔍 Inspect CSV Schema", key="csv_inspect_btn"):
                with st.spinner(f"Reading schema from {selected_file}…"):
                    try:
                        meta = csv_conn.get_metadata(selected_file)
                        st.metric("Row Count", meta["row_count"])
                        st.metric("Column Count", meta["column_count"])
                        df_cols = pd.DataFrame(meta["columns"])
                        st.dataframe(df_cols, use_container_width=True)
                        st.session_state["source_object"] = selected_file
                        st.session_state["source_schema"] = None
                        st.session_state["source_columns"] = meta["column_names"]
                        st.session_state["source_system"] = "csv"
                        st.info("✅ Source CSV set. Go to **Test Configuration** to continue.")
                    except Exception as e:
                        st.error(f"Failed to inspect CSV: {e}")
