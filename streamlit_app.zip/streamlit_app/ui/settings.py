"""
Settings Page — ETL Reconciliation Platform.
Configure runtime validation parameters: tolerance thresholds,
batch sizes, sample limits, and pushdown execution options.
Values are written to a .env file for persistence.
"""
import streamlit as st
import os
from pathlib import Path
from dotenv import dotenv_values, set_key

ENV_FILE = Path(".env")


def _read_env() -> dict:
    """Read current .env values (or fall back to os.environ)."""
    if ENV_FILE.is_file():
        return dotenv_values(ENV_FILE)
    return {}


def page():
    """Render the Settings page."""
    st.title("⚙️ Settings")
    st.caption("Configure validation execution parameters. Values are saved to `.env`.")

    env = _read_env()

    st.subheader("Validation Parameters")

    col1, col2 = st.columns(2)

    tolerance = col1.number_input(
        "Default Numeric Tolerance (absolute)",
        min_value=0.0,
        max_value=1000.0,
        value=float(env.get("DEFAULT_TOLERANCE", os.getenv("DEFAULT_TOLERANCE", "0.01"))),
        step=0.01,
        format="%.4f",
        help="Maximum allowed difference for numeric aggregate comparisons.",
        key="cfg_tolerance"
    )
    batch_size = col2.number_input(
        "Batch Size (rows per chunk)",
        min_value=1000,
        max_value=500000,
        value=int(env.get("DEFAULT_BATCH_SIZE", os.getenv("DEFAULT_BATCH_SIZE", "50000"))),
        step=1000,
        help="Number of rows processed per batch during record reconciliation.",
        key="cfg_batch"
    )
    sample_limit = col1.number_input(
        "Sample Limit (preview rows)",
        min_value=10,
        max_value=10000,
        value=int(env.get("DEFAULT_SAMPLE_LIMIT", os.getenv("DEFAULT_SAMPLE_LIMIT", "1000"))),
        step=10,
        help="Maximum number of sample mismatch rows to display in UI.",
        key="cfg_sample"
    )
    max_mismatches = col2.number_input(
        "Max Mismatches Saved to DB",
        min_value=100,
        max_value=100000,
        value=int(env.get("MAX_MISMATCHES_SAVED", os.getenv("MAX_MISMATCHES_SAVED", "1000"))),
        step=100,
        help="Maximum mismatch records persisted to the SQLite repository per execution.",
        key="cfg_max_mm"
    )

    pushdown = st.checkbox(
        "Enable Database-Side Pushdown Execution",
        value=(env.get("DB_PUSHDOWN_ENABLED", os.getenv("DB_PUSHDOWN_ENABLED", "true")).lower() == "true"),
        help="When enabled, COUNT/SUM/aggregation queries are pushed down to the database "
             "rather than fetching all rows into memory. Recommended for large tables.",
        key="cfg_pushdown"
    )

    st.divider()

    if st.button("💾 Save Settings", type="primary"):
        try:
            ENV_FILE.touch(exist_ok=True)
            set_key(str(ENV_FILE), "DEFAULT_TOLERANCE", str(tolerance))
            set_key(str(ENV_FILE), "DEFAULT_BATCH_SIZE", str(int(batch_size)))
            set_key(str(ENV_FILE), "DEFAULT_SAMPLE_LIMIT", str(int(sample_limit)))
            set_key(str(ENV_FILE), "MAX_MISMATCHES_SAVED", str(int(max_mismatches)))
            set_key(str(ENV_FILE), "DB_PUSHDOWN_ENABLED", "true" if pushdown else "false")
            st.success("✅ Settings saved to `.env`. Restart the app to apply changes.")
        except Exception as e:
            st.error(f"Failed to save settings: {e}")

    st.info(
        "💡 Settings take effect on the next application start. "
        "The `.env` file is local to your machine and is not tracked by git."
    )
