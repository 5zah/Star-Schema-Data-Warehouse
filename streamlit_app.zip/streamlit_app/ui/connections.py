"""
Connections Page — ETL Reconciliation Platform.
Configure and test Azure SQL, Snowflake, and CSV connections.
Credentials are saved to config/connections.json and loaded as env vars —
they are NEVER logged or stored in source code.
"""
import streamlit as st
import json
import os
from pathlib import Path
from connections.azure_sql import AzureSQLConnector
from connections.snowflake import SnowflakeConnector
from connections.csv_reader import CSVConnector

CONFIG_FILE = Path("config") / "connections.json"


def _load_saved() -> dict:
    """Load saved (non-sensitive) connection config from JSON."""
    if CONFIG_FILE.is_file():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            return {}
    return {}


def _save_config(cfg: dict):
    """Persist non-sensitive settings (no passwords) to connections.json."""
    safe = {
        "azure_sql": {
            "server": cfg.get("azure_sql", {}).get("server", ""),
            "database": cfg.get("azure_sql", {}).get("database", ""),
            "username": cfg.get("azure_sql", {}).get("username", ""),
            "port": cfg.get("azure_sql", {}).get("port", "1433"),
            "driver": cfg.get("azure_sql", {}).get("driver", "ODBC Driver 17 for SQL Server"),
        },
        "snowflake": {
            "account": cfg.get("snowflake", {}).get("account", ""),
            "user": cfg.get("snowflake", {}).get("user", ""),
            "warehouse": cfg.get("snowflake", {}).get("warehouse", ""),
            "database": cfg.get("snowflake", {}).get("database", ""),
            "schema": cfg.get("snowflake", {}).get("schema", ""),
            "role": cfg.get("snowflake", {}).get("role", "ACCOUNTADMIN"),
        },
        "csv": {
            "root": cfg.get("csv", {}).get("root", ""),
        },
    }
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(safe, indent=2))


def page():
    """Render the Connections configuration page."""
    st.title("🔌 Connection Manager")
    st.caption(
        "Configure source and target database connections. "
        "Passwords are used only in-session and are never written to disk."
    )

    cfg = _load_saved()

    # ----------------------------------------------------------------
    # Azure SQL
    # ----------------------------------------------------------------
    with st.expander("🔷 Azure SQL (Source)", expanded=True):
        az_cfg = cfg.get("azure_sql", {})
        col1, col2 = st.columns(2)
        az_server   = col1.text_input("Server", value=az_cfg.get("server", "etl-recon-server.database.windows.net"), key="az_server")
        az_db       = col2.text_input("Database", value=az_cfg.get("database", "EnterpriseSourceDB"), key="az_db")
        az_user     = col1.text_input("Username", value=az_cfg.get("username", "etladmin"), key="az_user")
        az_pwd      = col2.text_input("Password", value="", type="password", key="az_pwd",
                                      placeholder="Enter password (not saved to disk)")
        az_driver   = col1.text_input("ODBC Driver", value=az_cfg.get("driver", "ODBC Driver 17 for SQL Server"), key="az_driver")
        az_port     = col2.text_input("Port", value=str(az_cfg.get("port", "1433")), key="az_port")

        if st.button("🔍 Test Azure SQL Connection", key="btn_test_azure"):
            with st.spinner("Connecting to Azure SQL…"):
                try:
                    connector = AzureSQLConnector(config={
                        "server": az_server,
                        "database": az_db,
                        "username": az_user,
                        "password": az_pwd,
                        "port": int(az_port) if az_port.isdigit() else 1433,
                        "driver": az_driver,
                    })
                    ok, msg = connector.test_connection()
                    if ok:
                        st.success(f"✅ {msg}")
                        # Store engine in session state for reuse
                        st.session_state["azure_connector"] = connector
                    else:
                        st.error(f"❌ {msg}")
                except Exception as e:
                    st.error(f"❌ Connection error: {type(e).__name__} — {e}")

    # ----------------------------------------------------------------
    # Snowflake
    # ----------------------------------------------------------------
    with st.expander("❄️ Snowflake (Target)", expanded=True):
        sf_cfg = cfg.get("snowflake", {})
        col1, col2 = st.columns(2)
        sf_account  = col1.text_input("Account", value=sf_cfg.get("account", "BVHNZII-RK64999"), key="sf_account")
        sf_user     = col2.text_input("User", value=sf_cfg.get("user", "5zah"), key="sf_user")
        sf_pwd      = col1.text_input("Password", value="", type="password", key="sf_pwd",
                                      placeholder="Enter password (not saved to disk)")
        sf_wh       = col2.text_input("Warehouse", value=sf_cfg.get("warehouse", "ETL_WH"), key="sf_wh")
        sf_db       = col1.text_input("Database", value=sf_cfg.get("database", "ENTERPRISE_DWH"), key="sf_db")
        sf_schema   = col2.text_input("Schema", value=sf_cfg.get("schema", "TARGET"), key="sf_schema")
        sf_role     = col1.text_input("Role", value=sf_cfg.get("role", "ACCOUNTADMIN"), key="sf_role")

        if st.button("🔍 Test Snowflake Connection", key="btn_test_sf"):
            with st.spinner("Connecting to Snowflake…"):
                try:
                    connector = SnowflakeConnector(config={
                        "account": sf_account,
                        "user": sf_user,
                        "password": sf_pwd,
                        "warehouse": sf_wh,
                        "database": sf_db,
                        "schema": sf_schema,
                        "role": sf_role,
                    })
                    ok, msg = connector.test_connection()
                    if ok:
                        st.success(f"✅ {msg}")
                        st.session_state["snowflake_connector"] = connector
                    else:
                        st.error(f"❌ {msg}")
                except Exception as e:
                    st.error(f"❌ Connection error: {type(e).__name__} — {e}")

    # ----------------------------------------------------------------
    # CSV
    # ----------------------------------------------------------------
    with st.expander("📄 CSV / File Source"):
        csv_cfg = cfg.get("csv", {})
        csv_root = st.text_input(
            "CSV base directory",
            value=csv_cfg.get("root", str(Path("data").resolve())),
            key="csv_root"
        )
        if st.button("✅ Validate CSV Path", key="btn_csv"):
            p = Path(csv_root)
            if p.is_dir():
                files = list(p.glob("*.csv"))
                st.success(f"Directory found. {len(files)} CSV file(s) available.")
                if files:
                    st.code("\n".join(f.name for f in files[:20]))
            else:
                st.error("Directory not found. Please check the path.")

    st.divider()

    # ----------------------------------------------------------------
    # Save non-sensitive config
    # ----------------------------------------------------------------
    if st.button("💾 Save Connection Settings (non-sensitive only)", type="primary"):
        new_cfg = {
            "azure_sql": {
                "server": st.session_state.get("az_server", ""),
                "database": st.session_state.get("az_db", ""),
                "username": st.session_state.get("az_user", ""),
                "port": st.session_state.get("az_port", "1433"),
                "driver": st.session_state.get("az_driver", "ODBC Driver 17 for SQL Server"),
            },
            "snowflake": {
                "account": st.session_state.get("sf_account", ""),
                "user": st.session_state.get("sf_user", ""),
                "warehouse": st.session_state.get("sf_wh", ""),
                "database": st.session_state.get("sf_db", ""),
                "schema": st.session_state.get("sf_schema", ""),
                "role": st.session_state.get("sf_role", "ACCOUNTADMIN"),
            },
            "csv": {
                "root": st.session_state.get("csv_root", ""),
            },
        }
        _save_config(new_cfg)
        st.success("✅ Settings saved. Passwords are NOT stored — re-enter them each session.")

    st.info(
        "🔒 **Security note**: Passwords are kept only in Streamlit session memory and "
        "are never written to `connections.json`, logs, or reports. "
        "Store passwords in a `.env` file or OS keyring for persistent sessions."
    )
