"""
Execution Page — ETL Reconciliation Platform.
Provides live table dropdowns (populated from connected databases),
auto-populated business key multiselect, and runs the full validation suite.
"""
import streamlit as st
import sys, os
from config.models import (
    ValidationConfig, SourceTargetSpec, SystemType,
)
from engine.result_processor import ResultProcessor
from engine.pytest_runner import PytestRunner

# Safely import predefined scenarios if available
try:
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..")))
    from src.web.app import PYTEST_SCENARIOS
except ImportError:
    PYTEST_SCENARIOS = [{"id": "all", "name": "Execute All Automated Test Suites (Full Suite)"}]

# Predefined scenario presets for quick selection
SCENARIO_PRESETS = [
    "Ad-hoc Reconciliation",
    "Daily Sales Volume Check",
    "Weekly Dimension Integrity Check",
    "Monthly KPI Aggregate Validation",
    "Schema Drift Detection",
    "Full Regression Suite",
]

ALL_TESTS = {
    "row_count":             "📦 Volume / Row Count",
    "schema":                "🔎 Schema & Column Names",
    "null_check":            "🚫 Null Constraint Validation",
    "duplicate_check":       "🔁 Duplicate Business Key Check",
    "aggregate":             "🔢 Numeric KPI Aggregates",
    "record_reconciliation": "🔬 Record-Level Reconciliation",
    "business_rules":        "📐 Business Rule Validation",
}

SRC_TYPE_MAP = {
    "azure_sql": SystemType.AZURE_SQL,
    "snowflake": SystemType.SNOWFLAKE,
    "csv":       SystemType.CSV,
}


# ─────────────────────────────────────────────────────────────────────────────
# Helper: live metadata fetchers with caching
# ─────────────────────────────────────────────────────────────────────────────

@st.cache_data(show_spinner=False, ttl=120)
def _get_azure_tables(schema: str) -> list:
    try:
        from metadata.azure_sql_metadata import AzureSQLMetadata
        connector = st.session_state.get("azure_connector")
        if connector is None:
            return []
        meta = AzureSQLMetadata(connector=connector)
        tables = meta.get_tables(schema=schema)
        views  = meta.get_views(schema=schema)
        return sorted(set(tables + views))
    except Exception:
        return []


@st.cache_data(show_spinner=False, ttl=120)
def _get_snowflake_tables(schema: str) -> list:
    try:
        from metadata.snowflake_metadata import SnowflakeMetadata
        connector = st.session_state.get("snowflake_connector")
        if connector is None:
            return []
        meta = SnowflakeMetadata(connector=connector)
        tables = meta.get_tables(schema=schema)
        views  = meta.get_views(schema=schema)
        return sorted(set(tables + views))
    except Exception:
        return []


@st.cache_data(show_spinner=False, ttl=120)
def _get_columns(system: str, schema: str, table: str) -> list:
    """Returns list of column names for a given table."""
    try:
        if system == "azure_sql":
            from metadata.azure_sql_metadata import AzureSQLMetadata
            connector = st.session_state.get("azure_connector")
            if connector is None:
                return []
            cols = AzureSQLMetadata(connector=connector).get_columns(table, schema=schema)
        elif system == "snowflake":
            from metadata.snowflake_metadata import SnowflakeMetadata
            connector = st.session_state.get("snowflake_connector")
            if connector is None:
                return []
            cols = SnowflakeMetadata(connector=connector).get_columns(table, schema=schema)
        else:
            return []
        return [c["name"] for c in cols]
    except Exception:
        return []


# ─────────────────────────────────────────────────────────────────────────────
# Page
# ─────────────────────────────────────────────────────────────────────────────

def page():
    """Render the Run Tests / Execution page."""
    st.title("🚀 Run Validation")
    st.caption("Configure your reconciliation scenario and execute all selected tests.")

    tab_adhoc, tab_suite = st.tabs(["🎯 Interactive Ad-Hoc Run", "🤖 Automated Pytest Suite"])

    with tab_adhoc:
        _render_adhoc_tab()
    with tab_suite:
        _render_suite_tab()


# ─────────────────────────────────────────────────────────────────────────────
# Ad-hoc tab
# ─────────────────────────────────────────────────────────────────────────────

def _render_adhoc_tab():
    az_ok = st.session_state.get("azure_connector") is not None
    sf_ok = st.session_state.get("snowflake_connector") is not None

    if not az_ok and not sf_ok:
        st.warning("⚠️ No database connections found. Go to **🔌 Connections** first and test your connections.")

    # ── Scenario Name ────────────────────────────────────────────────────────
    st.subheader("📝 Scenario Name")
    scenario_col1, scenario_col2 = st.columns([2, 3])
    with scenario_col1:
        preset = st.selectbox(
            "Choose a preset or type your own below",
            options=["(type custom)"] + SCENARIO_PRESETS,
            index=0,
            key="exec_preset"
        )
    with scenario_col2:
        default_name = "" if preset == "(type custom)" else preset
        scenario_name = st.text_input(
            "Scenario Name",
            value=default_name or st.session_state.get("scenario_name", ""),
            placeholder="e.g. Daily Sales Volume Check",
            key="exec_scenario_name"
        )

    st.divider()

    # ── Source Setup ─────────────────────────────────────────────────────────
    st.subheader("📤 Source")
    src_col1, src_col2, src_col3 = st.columns(3)
    with src_col1:
        source_system = st.selectbox(
            "Source System",
            ["azure_sql", "snowflake", "csv"],
            index=["azure_sql", "snowflake", "csv"].index(
                st.session_state.get("source_system", "azure_sql")
            ),
            key="exec_src_system"
        )
    with src_col2:
        source_schema = st.text_input(
            "Source Schema",
            value=st.session_state.get("source_schema", "dbo"),
            key="exec_src_schema"
        )
    with src_col3:
        # Live table dropdown
        if source_system == "azure_sql" and az_ok:
            src_tables = _get_azure_tables(source_schema)
        elif source_system == "snowflake" and sf_ok:
            src_tables = _get_snowflake_tables(source_schema)
        else:
            src_tables = []

        if src_tables:
            prev_src = st.session_state.get("source_object", "")
            src_idx  = src_tables.index(prev_src) if prev_src in src_tables else 0
            source_object = st.selectbox(
                "Source Table / View",
                options=src_tables,
                index=src_idx,
                key="exec_src_obj"
            )
        else:
            source_object = st.text_input(
                "Source Table / View",
                value=st.session_state.get("source_object", ""),
                placeholder="Connect DB to see live list, or type manually",
                key="exec_src_obj"
            )

    # ── Target Setup ─────────────────────────────────────────────────────────
    st.subheader("📥 Target")
    tgt_col1, tgt_col2, tgt_col3 = st.columns(3)
    with tgt_col1:
        target_system = st.selectbox(
            "Target System",
            ["snowflake", "azure_sql", "csv"],
            index=["snowflake", "azure_sql", "csv"].index(
                st.session_state.get("target_system", "snowflake")
            ),
            key="exec_tgt_system"
        )
    with tgt_col2:
        target_schema = st.text_input(
            "Target Schema",
            value=st.session_state.get("target_schema", "TARGET"),
            key="exec_tgt_schema"
        )
    with tgt_col3:
        if target_system == "snowflake" and sf_ok:
            tgt_tables = _get_snowflake_tables(target_schema)
        elif target_system == "azure_sql" and az_ok:
            tgt_tables = _get_azure_tables(target_schema)
        else:
            tgt_tables = []

        if tgt_tables:
            prev_tgt = st.session_state.get("target_object", "")
            tgt_idx  = tgt_tables.index(prev_tgt) if prev_tgt in tgt_tables else 0
            target_object = st.selectbox(
                "Target Table / View",
                options=tgt_tables,
                index=tgt_idx,
                key="exec_tgt_obj"
            )
        else:
            target_object = st.text_input(
                "Target Table / View",
                value=st.session_state.get("target_object", ""),
                placeholder="Connect DB to see live list, or type manually",
                key="exec_tgt_obj"
            )

    # ── Business Keys ────────────────────────────────────────────────────────
    st.divider()
    st.subheader("🔑 Business Keys")

    # Try to auto-load columns from the selected source table
    src_cols  = _get_columns(source_system, source_schema, source_object) if source_object else []
    prev_keys = st.session_state.get("business_keys", [])

    if src_cols:
        st.caption("Columns are fetched live from the source table. Select which columns are the business / primary keys.")
        business_keys = st.multiselect(
            "Select Business Key Column(s)",
            options=src_cols,
            default=[k for k in prev_keys if k in src_cols],
            key="exec_bk_multi"
        )
    else:
        st.caption("Type your business keys manually (comma-separated), or connect to DB to get a live column list.")
        bk_raw = st.text_input(
            "Business Keys (comma-separated)",
            value=", ".join(prev_keys),
            placeholder="e.g. order_id, customer_id",
            key="exec_bk_text"
        )
        business_keys = [k.strip() for k in bk_raw.split(",") if k.strip()]

    # ── Test Selection ───────────────────────────────────────────────────────
    st.divider()
    st.subheader("🧪 Select Validations to Run")
    hdr_col1, hdr_col2 = st.columns([6, 1])
    with hdr_col2:
        if st.button("Select All", key="btn_sel_all"):
            for k in ALL_TESTS:
                st.session_state[f"chk_{k}"] = True

    selected_cfg   = st.session_state.get("test_config", {})
    selected_tests = []
    cols = st.columns(3)
    for i, (key, label) in enumerate(ALL_TESTS.items()):
        default = st.session_state.get(f"chk_{key}", key in selected_cfg.get("selected_tests", list(ALL_TESTS.keys())))
        checked = cols[i % 3].checkbox(label, value=default, key=f"chk_{key}")
        if checked:
            selected_tests.append(key)

    # ── Run ──────────────────────────────────────────────────────────────────
    st.divider()
    ready = bool(source_object and target_object and selected_tests)
    if not ready:
        st.info("ℹ️ Set source table, target table, and select at least one validation to enable the run button.")

    if st.button("▶ Run Validation", type="primary", disabled=not ready):
        # Persist to session state
        st.session_state.update({
            "source_system":  source_system,
            "target_system":  target_system,
            "source_object":  source_object,
            "target_object":  target_object,
            "source_schema":  source_schema,
            "target_schema":  target_schema,
            "business_keys":  business_keys,
            "scenario_name":  scenario_name,
        })

        config = ValidationConfig(
            scenario_name=scenario_name,
            source=SourceTargetSpec(
                system_type=SRC_TYPE_MAP.get(source_system, SystemType.AZURE_SQL),
                object_name=source_object.strip(),
                schema=source_schema.strip() or "dbo",
                file_path=source_object.strip() if source_system == "csv" else None,
            ),
            target=SourceTargetSpec(
                system_type=SRC_TYPE_MAP.get(target_system, SystemType.SNOWFLAKE),
                object_name=target_object.strip(),
                schema=target_schema.strip() or "TARGET",
            ),
            business_keys=business_keys,
            selected_tests=selected_tests,
        )

        progress_bar = st.progress(0.0, text="Initialising…")
        log_area     = st.empty()
        log_lines    = []

        def on_progress(pct: float, msg: str):
            progress_bar.progress(min(pct, 1.0), text=msg)
            log_lines.append(f"[{pct*100:.0f}%] {msg}")
            log_area.code("\n".join(log_lines[-10:]))

        with st.spinner("Running validations…"):
            try:
                processor = ResultProcessor()
                summary   = processor.execute_and_process(config, progress_callback=on_progress)
                progress_bar.progress(1.0, text="✅ Complete")

                st.divider()
                overall = summary.overall_status.value
                if overall == "PASS":
                    st.success(f"✅ PASS — {summary.passed_count}/{summary.total_validations} validations passed  |  Pass rate: {summary.pass_rate_pct}%")
                else:
                    st.error(f"❌ {overall} — {summary.failed_count} failure(s)  |  Pass rate: {summary.pass_rate_pct}%")

                c1, c2, c3, c4 = st.columns(4)
                c1.metric("Execution ID",  summary.execution_id)
                c2.metric("Rows Audited",  f"{summary.total_rows_audited:,}")
                c3.metric("Mismatches",    summary.total_mismatches)
                c4.metric("Duration",      f"{summary.execution_duration_sec:.2f}s")

                st.session_state["last_execution_id"] = summary.execution_id
                st.info("📋 Navigate to **Test Results** or **Mismatch Drill-Down** to explore results.")

            except Exception as e:
                progress_bar.empty()
                st.error(f"❌ Execution failed: {type(e).__name__}: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# Automated Pytest suite tab
# ─────────────────────────────────────────────────────────────────────────────

def _render_suite_tab():
    st.subheader("🤖 Run Predefined Automated Suites")
    st.write("Execute pre-configured end-to-end pytest scenarios across your data warehouse in one click.")

    scenario_map = {s["id"]: s["name"] for s in PYTEST_SCENARIOS}
    selected_id  = st.selectbox(
        "Select Scenario",
        options=list(scenario_map.keys()),
        format_func=lambda x: f"{x} – {scenario_map[x]}"
    )

    st.divider()
    if st.button("▶ Run Automated Suite", type="primary", key="btn_run_suite"):
        log_area  = st.empty()
        log_lines = []

        def on_log(line: str):
            log_lines.append(line)
            log_area.code("\n".join(log_lines[-20:]), language="shell")

        with st.spinner(f"Running: {scenario_map.get(selected_id)}…"):
            runner      = PytestRunner()
            test_filter = None if selected_id == "all" else selected_id
            try:
                exit_code, full_logs = runner.run_tests(
                    test_filter=test_filter,
                    log_callback=on_log
                )
                log_area.empty()

                if exit_code == 0:
                    st.success("✅ Automated Suite Completed Successfully!")
                else:
                    st.error(f"❌ Suite Failed (Exit Code: {exit_code})")

                with st.expander("📄 Full Execution Logs", expanded=True):
                    st.code("\n".join(full_logs), language="shell")

            except Exception as e:
                st.error(f"❌ Failed to execute pytest suite: {type(e).__name__}: {e}")
