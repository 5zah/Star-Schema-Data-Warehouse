"""
Dashboard Page — ETL Reconciliation Platform.
Displays KPI summary cards from execution history, recent runs table,
and quick-navigation buttons to all platform pages.
"""
import streamlit as st
import pandas as pd
from pathlib import Path
from repository.sqlite_repository import SQLiteRepository
from config.settings import REPORTS_DIR


def page():
    """Render the Dashboard landing page."""
    st.title("📊 ETL Reconciliation Dashboard")
    st.caption("Real-time overview of data warehouse validation health.")

    repo = SQLiteRepository()

    # ----------------------------------------------------------------
    # KPI Row — pulled from execution history
    # ----------------------------------------------------------------
    executions = repo.list_executions(limit=200)

    total_runs = len(executions)
    passed = sum(1 for e in executions if e["overall_status"] == "PASS")
    failed = sum(1 for e in executions if e["overall_status"] == "FAIL")
    last_status = executions[0]["overall_status"] if executions else "—"
    last_run_ts = executions[0]["timestamp"] if executions else "—"
    avg_pass_rate = (
        round(sum(e.get("pass_rate_pct", 0) for e in executions) / total_runs, 1)
        if total_runs > 0 else 0.0
    )

    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Total Runs", total_runs)
    col2.metric("✅ Passed", passed, delta=None)
    col3.metric("❌ Failed", failed, delta=None)
    col4.metric("Avg Pass Rate", f"{avg_pass_rate}%")

    last_color = "🟢" if last_status == "PASS" else ("🔴" if last_status == "FAIL" else "⚪")
    col5.metric("Last Run", f"{last_color} {last_status}", delta=last_run_ts)

    st.divider()

    # ----------------------------------------------------------------
    # Recent Executions Table
    # ----------------------------------------------------------------
    st.subheader("🕒 Recent Executions")

    if not executions:
        st.info("No executions found. Run a validation scenario to get started.")
    else:
        df = pd.DataFrame(executions)
        display_cols = [
            "execution_id", "timestamp", "scenario_name", "source_desc",
            "target_desc", "overall_status", "pass_rate_pct",
            "total_validations", "passed_count", "failed_count",
            "total_mismatches", "execution_duration_sec"
        ]
        display_cols = [c for c in display_cols if c in df.columns]
        df_display = df[display_cols].rename(columns={
            "execution_id": "ID",
            "timestamp": "Timestamp",
            "scenario_name": "Scenario",
            "source_desc": "Source",
            "target_desc": "Target",
            "overall_status": "Status",
            "pass_rate_pct": "Pass %",
            "total_validations": "Tests",
            "passed_count": "✅ Pass",
            "failed_count": "❌ Fail",
            "total_mismatches": "Mismatches",
            "execution_duration_sec": "Duration (s)"
        })

        # Colour-code status column
        def colour_status(val):
            if val == "PASS":
                return "background-color: #1a472a; color: #a3ffba"
            elif val == "FAIL":
                return "background-color: #5c0000; color: #ffb3b3"
            elif val == "WARNING":
                return "background-color: #3d3000; color: #ffe680"
            return ""

        styled = df_display.style.applymap(colour_status, subset=["Status"])
        st.dataframe(styled, use_container_width=True)

    st.divider()

    # ----------------------------------------------------------------
    # Quick Navigation
    # ----------------------------------------------------------------
    st.subheader("⚡ Quick Actions")
    c1, c2, c3, c4 = st.columns(4)
    c1.info("🔌 **Connections**\nConfigure Azure SQL, Snowflake & CSV sources.")
    c2.info("🗂️ **Data Objects**\nDiscover schemas, tables & columns dynamically.")
    c3.info("⚙️ **Test Config**\nBuild a validation scenario and select tests.")
    c4.info("🚀 **Run Tests**\nExecute the selected scenario and view results.")

    st.caption("Use the sidebar to navigate between pages.")
