# Implementation Plan — Restructure Streamlit App

This plan will clean up your root directory by moving all the files needed for the new Streamlit application into a single, dedicated folder named `streamlit_app`. This will neatly separate our new work from the old Flask application and legacy files.

## User Review Required
Please review the list of files and folders to be moved below. If you approve, I will automatically create the folder and move everything over.

## Proposed Changes

I will create a new folder: `c:\Users\faiza\Downloads\Testing Profile\ETL testing\streamlit_app`

### 📁 Folders to Move
The following directories contain the core backend logic, UI, and test suites for the Streamlit app. They will be moved inside `streamlit_app/`:
- `ui/`
- `config/`
- `connections/`
- `engine/`
- `metadata/`
- `reporting/`
- `repository/`
- `validations/`
- `tests/`
- `database/`
- `reports/`

### 📄 Files to Move
- `app.py` ➡️ `streamlit_app/app.py`
- `.env.example` ➡️ `streamlit_app/.env.example`
- `pytest.ini` ➡️ `streamlit_app/pytest.ini`

## Verification Plan
1. I will execute the move operations using Python/PowerShell commands.
2. I will verify the structure using a directory listing.
3. Because the `engine/pytest_runner.py` and other modules use relative paths based on their own file locations, moving the entire group of folders together will naturally "align" them without breaking internal imports. I will double-check that the imports still work by doing a quick test run of `streamlit_app/app.py`.
