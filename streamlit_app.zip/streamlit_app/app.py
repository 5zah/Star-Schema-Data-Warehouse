# app.py
import streamlit as st
from ui import dashboard, connections, objects, execution, results, mismatches, history, reports, settings

st.set_page_config(page_title="ETL Reconciliation", layout="wide")

# Initialize session state defaults
_defaults = {
    "azure_connector": None,
    "snowflake_connector": None,
    "source_system": "azure_sql",
    "target_system": "snowflake",
    "source_schema": "dbo",
    "target_schema": "TARGET",
    "source_object": "",
    "target_object": "",
    "source_columns": [],
    "target_columns": [],
    "business_keys": [],
    "scenario_name": "Ad-hoc Reconciliation",
    "test_config": {},
    "last_execution_id": None,
}
for k, v in _defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

# Sidebar navigation
pages = {
    "📊 Dashboard":          dashboard.page,
    "🔌 Connections":        connections.page,
    "🗂️ Data Objects":       objects.page,
    "🚀 Run Tests":          execution.page,
    "📋 Test Results":       results.page,
    "🚨 Mismatch Drill-Down": mismatches.render_mismatches_page,
    "📜 History":            history.page,
    "📄 Reports":            reports.page,
    "🔧 Settings":           settings.page,
}

st.sidebar.title("ETL Recon Platform")
st.sidebar.caption("Data Warehouse Validation")
st.sidebar.divider()
selection = st.sidebar.radio("Navigate", list(pages.keys()), label_visibility="collapsed")

# Connection status indicators
az_ok = st.session_state.get("azure_connector") is not None
sf_ok = st.session_state.get("snowflake_connector") is not None
st.sidebar.divider()
st.sidebar.caption(
    f"Azure SQL: {'🟢 Connected' if az_ok else '🔴 Not connected'}\n\n"
    f"Snowflake:  {'🟢 Connected' if sf_ok else '🔴 Not connected'}"
)

# Render selected page
pages[selection]()
