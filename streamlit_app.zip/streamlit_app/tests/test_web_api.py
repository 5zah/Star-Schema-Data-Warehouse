"""
Unit tests for Flask API and Sales Reconciliation Web Server.
"""
import pytest
import json
from src.web.app import app

@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client

def test_index_route(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"SALES DATA WAREHOUSE" in response.data

def test_connections_config(client):
    response = client.get("/api/connections/config")
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    assert "azure_sql" in data["config"]

def test_connections_test(client):
    response = client.post("/api/connections/test", json={"system": "azure_sql"})
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"

def test_list_entities(client):
    response = client.get("/api/connections/entities?system=azure_sql")
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    assert "fact_sales" in data["tables"]

def test_reconcile_api_file_vs_table(client):
    payload = {
        "source_system": "files",
        "source_entity": "sales_raw_source.csv",
        "target_system": "azure_sql",
        "target_entity": "stg_sales_transactions",
        "pk_column": "order_id",
        "selected_checks": ["volume", "schema", "attribute", "duplicates", "nulls"]
    }
    response = client.post("/api/reconcile/run", json=payload)
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    assert data["results"]["overall_status"] == "PASSED"

def test_reconcile_api_azure_vs_snowflake(client):
    payload = {
        "source_system": "azure_sql",
        "source_entity": "fact_sales",
        "target_system": "snowflake",
        "target_entity": "fact_sales_orders",
        "pk_column": "order_id",
        "selected_checks": ["volume", "schema", "attribute", "aggregates", "referential", "business_rules"]
    }
    response = client.post("/api/reconcile/run", json=payload)
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    assert data["results"]["overall_status"] == "PASSED"

def test_pytest_scenarios_list(client):
    response = client.get("/api/pytest/scenarios")
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    assert len(data["scenarios"]) >= 12

def test_pytest_run_single_scenario(client):
    payload = {"scenario_id": "test_01_csv_file_vs_azure_sql_staging_volume"}
    response = client.post("/api/pytest/run", json=payload)
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data["status"] == "success"
    assert data["results"]["overall_status"] == "PASSED"
