"""
Sales Data Warehouse Automated Pytest Suite (test_sales_dw_reconciliation.py).
Validates:
1. Files vs Tables (CSV raw source vs Azure SQL Staging)
2. Azure SQL Transformations & Business Rules (Facts and Analytical Views)
3. Azure SQL vs Snowflake Parity (Volumes, Attributes, KPIs, Analytical Views)
4. Data Integrity Constraints (Referential integrity, Nulls, Duplicates, Bounds)
"""
import os
import pytest
import pandas as pd
from sqlalchemy import text


# ====================================================================
# SECTION 1: FILE VS TABLE VALIDATIONS (CSV Source -> Azure SQL Staging)
# ====================================================================

def test_01_csv_file_vs_azure_sql_staging_volume(azure_sql_sales_engine, sales_source_csv_path):
    """[File vs Azure SQL] Verify row count in source CSV matches Azure SQL Staging."""
    df_csv = pd.read_csv(sales_source_csv_path)
    csv_count = len(df_csv)

    with azure_sql_sales_engine.connect() as conn:
        stg_count = conn.execute(text("SELECT COUNT(*) FROM stg_sales_transactions;")).scalar()

    print(f"\n[CSV vs Azure SQL Volume] CSV: {csv_count} | Staging: {stg_count}")
    assert csv_count == stg_count, f"Volume mismatch: CSV has {csv_count} rows but Azure SQL Staging has {stg_count}"


def test_02_csv_file_vs_azure_sql_staging_schema_and_keys(azure_sql_sales_engine, sales_source_csv_path):
    """[File vs Azure SQL] Verify CSV columns and primary keys are preserved in Staging."""
    df_csv = pd.read_csv(sales_source_csv_path, nrows=5)
    with azure_sql_sales_engine.connect() as conn:
        df_stg = pd.read_sql(text("SELECT * FROM stg_sales_transactions LIMIT 5;"), conn)

    for col in ["order_id", "customer_id", "product_id", "store_id", "quantity", "unit_price"]:
        assert col in df_stg.columns, f"Required column '{col}' missing from Azure SQL Staging schema"


# ====================================================================
# SECTION 2: AZURE SQL INTERNAL TRANSFORMATION & BUSINESS RULES
# ====================================================================

def test_03_azure_sql_transformation_business_rules(azure_sql_sales_engine):
    """[Azure SQL Business Rules] Validate transformation arithmetic in fact_sales."""
    with azure_sql_sales_engine.connect() as conn:
        df = pd.read_sql(text("""
            SELECT 
                order_id,
                quantity,
                unit_price,
                gross_amount,
                discount_amount,
                net_amount,
                tax_amount,
                total_sales_amount,
                cost_amount,
                margin_amount,
                margin_pct
            FROM fact_sales;
        """), conn)

    # 1. Gross = Qty * Unit Price
    gross_diff = (df["quantity"] * df["unit_price"] - df["gross_amount"]).abs().max()
    assert gross_diff < 0.02, f"Gross amount transformation error: max diff {gross_diff}"

    # 2. Net = Gross - Discount
    net_diff = (df["gross_amount"] - df["discount_amount"] - df["net_amount"]).abs().max()
    assert net_diff < 0.02, f"Net sales amount calculation error: max diff {net_diff}"

    # 3. Total Sales = Net + Tax
    tot_diff = (df["net_amount"] + df["tax_amount"] - df["total_sales_amount"]).abs().max()
    assert tot_diff < 0.02, f"Total sales with tax calculation error: max diff {tot_diff}"

    # 4. Margin = Net - Cost
    margin_diff = (df["net_amount"] - df["cost_amount"] - df["margin_amount"]).abs().max()
    assert margin_diff < 0.02, f"Margin calculation error: max diff {margin_diff}"


def test_04_azure_sql_fact_vs_regional_view_aggregates(azure_sql_sales_engine):
    """[Azure SQL Table vs View] Verify total revenue in fact_sales matches regional summary view."""
    with azure_sql_sales_engine.connect() as conn:
        fact_total_rev = conn.execute(text("SELECT ROUND(SUM(total_sales_amount), 2) FROM fact_sales;")).scalar()
        view_total_rev = conn.execute(text("SELECT ROUND(SUM(total_revenue), 2) FROM vw_sales_regional_summary;")).scalar()

    diff = abs((fact_total_rev or 0.0) - (view_total_rev or 0.0))
    print(f"\n[Azure SQL Fact vs View] Fact Total: {fact_total_rev} | View Total: {view_total_rev}")
    assert diff <= 0.05, f"Discrepancy between fact_sales ({fact_total_rev}) and vw_sales_regional_summary ({view_total_rev})"


# ====================================================================
# SECTION 3: AZURE SQL VS SNOWFLAKE TARGET RECONCILIATION
# ====================================================================

def test_05_azure_sql_fact_vs_snowflake_fact_volume(azure_sql_sales_engine, snowflake_sales_engine):
    """[Azure SQL vs Snowflake] Assert exact row count parity between source fact and Snowflake fact."""
    with azure_sql_sales_engine.connect() as conn_src:
        src_count = conn_src.execute(text("SELECT COUNT(*) FROM fact_sales;")).scalar()

    with snowflake_sales_engine.connect() as conn_tgt:
        tgt_count = conn_tgt.execute(text("SELECT COUNT(*) FROM fact_sales_orders;")).scalar()

    print(f"\n[Azure SQL vs Snowflake Volume] Source: {src_count} | Snowflake Target: {tgt_count}")
    assert src_count == tgt_count, f"Volume drift: Azure SQL has {src_count} rows, Snowflake has {tgt_count}"


def test_06_azure_sql_fact_vs_snowflake_fact_attributes(azure_sql_sales_engine, snowflake_sales_engine):
    """[Azure SQL vs Snowflake] Validate row-by-row attribute alignment on Order ID."""
    with azure_sql_sales_engine.connect() as conn_src:
        df_src = pd.read_sql(text("SELECT order_id, net_amount, margin_amount FROM fact_sales;"), conn_src)

    with snowflake_sales_engine.connect() as conn_tgt:
        df_tgt = pd.read_sql(text("SELECT order_id, net_amount, margin_amount FROM fact_sales_orders;"), conn_tgt)

    merged = pd.merge(df_src, df_tgt, on="order_id", suffixes=("_src", "_tgt"))
    assert len(merged) == len(df_src), f"Missing orders during reconciliation merge: {len(df_src) - len(merged)}"

    net_diff = (merged["net_amount_src"] - merged["net_amount_tgt"]).abs().max()
    assert net_diff <= 0.01, f"Row-level net_amount mismatch between Azure SQL and Snowflake: max diff {net_diff}"


def test_07_azure_sql_fact_vs_snowflake_fact_numeric_kpis(azure_sql_sales_engine, snowflake_sales_engine):
    """[Azure SQL vs Snowflake] Assert numeric KPI sums match within strict 0.01 tolerance."""
    query = text("""
        SELECT 
            ROUND(SUM(gross_amount), 2) AS total_gross,
            ROUND(SUM(net_amount), 2) AS total_net,
            ROUND(SUM(total_sales_amount), 2) AS total_revenue,
            ROUND(SUM(margin_amount), 2) AS total_margin,
            SUM(quantity) AS total_units
        FROM {table};
    """.replace("{table}", "fact_sales"))

    with azure_sql_sales_engine.connect() as conn_src:
        src_row = pd.read_sql(query, conn_src).iloc[0]

    with snowflake_sales_engine.connect() as conn_tgt:
        tgt_query = text(str(query).replace("fact_sales", "fact_sales_orders"))
        tgt_row = pd.read_sql(tgt_query, conn_tgt).iloc[0]

    for metric in ["total_gross", "total_net", "total_revenue", "total_margin", "total_units"]:
        diff = abs(src_row[metric] - tgt_row[metric])
        print(f"\n[KPI Parity] Metric '{metric}': Azure SQL={src_row[metric]} | Snowflake={tgt_row[metric]}")
        assert diff <= 0.02, f"KPI drift on '{metric}': diff={diff}"


def test_08_snowflake_duplicate_business_keys(snowflake_sales_engine):
    """[Snowflake Target] Assert zero duplicate order_id records exist in fact_sales_orders."""
    with snowflake_sales_engine.connect() as conn:
        df = pd.read_sql(text("""
            SELECT order_id, COUNT(*) as cnt 
            FROM fact_sales_orders 
            GROUP BY order_id 
            HAVING COUNT(*) > 1;
        """), conn)

    assert len(df) == 0, f"Duplicate business keys found in Snowflake fact_sales_orders: {df.to_dict()}"


def test_09_snowflake_referential_integrity_orphaned_keys(snowflake_sales_engine):
    """[Snowflake Target] Assert all customer_id foreign keys resolve against dim_customer."""
    with snowflake_sales_engine.connect() as conn:
        df = pd.read_sql(text("""
            SELECT f.order_id, f.customer_id
            FROM fact_sales_orders f
            LEFT JOIN dim_customer c ON f.customer_id = c.customer_id
            WHERE c.customer_id IS NULL;
        """), conn)

    assert len(df) == 0, f"Referential integrity failure: Found {len(df)} orphaned order records in Snowflake"


def test_10_snowflake_null_constraints_mandatory_columns(snowflake_sales_engine):
    """[Snowflake Target] Assert no NULL values in primary key or financial measure columns."""
    with snowflake_sales_engine.connect() as conn:
        df = pd.read_sql(text("""
            SELECT 
                SUM(CASE WHEN order_id IS NULL THEN 1 ELSE 0 END) AS null_orders,
                SUM(CASE WHEN date_key IS NULL THEN 1 ELSE 0 END) AS null_dates,
                SUM(CASE WHEN net_amount IS NULL THEN 1 ELSE 0 END) AS null_net_sales,
                SUM(CASE WHEN quantity IS NULL THEN 1 ELSE 0 END) AS null_quantities
            FROM fact_sales_orders;
        """), conn)

    total_nulls = int(df.iloc[0].sum())
    assert total_nulls == 0, f"Mandatory column null check failed in Snowflake: {df.to_dict()}"


def test_11_azure_sql_view_vs_snowflake_analytical_view_parity(azure_sql_sales_engine, snowflake_sales_engine):
    """[Azure SQL View vs Snowflake View] Reconcile daily rollup views across both systems."""
    with azure_sql_sales_engine.connect() as conn_src:
        df_src = pd.read_sql(text("SELECT date_key, sum_total_sales FROM vw_daily_sales_reconciliation ORDER BY date_key;"), conn_src)

    with snowflake_sales_engine.connect() as conn_tgt:
        df_tgt = pd.read_sql(text("SELECT date_key, sum_total_sales FROM vw_daily_sales_reconciliation ORDER BY date_key;"), conn_tgt)

    merged = pd.merge(df_src, df_tgt, on="date_key", suffixes=("_azure", "_snowflake"))
    diff = (merged["sum_total_sales_azure"] - merged["sum_total_sales_snowflake"]).abs().max()
    assert diff <= 0.05, f"Daily view reconciliation drift across Azure SQL & Snowflake: max diff {diff}"


def test_12_sales_operational_bounds_and_validity(snowflake_sales_engine):
    """[Snowflake Target] Assert no negative quantities or corrupt margin percentages exist."""
    with snowflake_sales_engine.connect() as conn:
        df = pd.read_sql(text("""
            SELECT order_id, quantity, margin_pct
            FROM fact_sales_orders
            WHERE quantity <= 0 OR margin_pct < -50.0 OR margin_pct > 100.0;
        """), conn)

    assert len(df) == 0, f"Operational bounds violation detected in Snowflake fact: {len(df)} rows"
