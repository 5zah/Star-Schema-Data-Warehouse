"""
Pytest Context and Configuration File for Sales & Enterprise DWH Automation.
Provides shared database fixtures for Microsoft Azure SQL, Snowflake, and CSV Files.
"""
import os
import pytest
import sqlalchemy as sa

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "data"))
AZURE_SQL_PATH = os.path.join(DATA_DIR, "azure_sql_sales_dw.db")
SNOWFLAKE_PATH = os.path.join(DATA_DIR, "snowflake_sales_dw.db")
SALES_CSV_PATH = os.path.join(DATA_DIR, "sales_raw_source.csv")
MANUFACTURING_DWH_PATH = os.path.join(DATA_DIR, "manufacturing_dwh.db")
TEST_MANUFACTURING_PATH = os.path.join(DATA_DIR, "test_manufacturing_dwh.db")


# --- Sales DWH Fixtures ---

@pytest.fixture(scope="session")
def azure_sql_sales_engine():
    """Returns SQLAlchemy connection engine for Azure SQL Sales DB."""
    conn_str = os.getenv("AZURE_SQL_CONNECTION_STRING", f"sqlite:///{AZURE_SQL_PATH}")
    engine = sa.create_engine(conn_str)
    yield engine
    engine.dispose()


@pytest.fixture(scope="session")
def snowflake_sales_engine():
    """Returns SQLAlchemy connection engine for Snowflake Analytical DW."""
    conn_str = os.getenv("SNOWFLAKE_CONNECTION_STRING", f"sqlite:///{SNOWFLAKE_PATH}")
    engine = sa.create_engine(conn_str)
    yield engine
    engine.dispose()


@pytest.fixture(scope="session")
def sales_source_csv_path():
    """Returns file path for raw source Sales CSV."""
    return SALES_CSV_PATH


# --- Shared/Legacy Fixture Aliases ---

@pytest.fixture(scope="session")
def azure_sql_engine():
    """Returns SQLAlchemy engine representing Azure SQL Source."""
    path = MANUFACTURING_DWH_PATH if os.path.exists(MANUFACTURING_DWH_PATH) else AZURE_SQL_PATH
    conn_str = os.getenv("AZURE_SQL_CONNECTION_STRING", f"sqlite:///{path}")
    engine = sa.create_engine(conn_str)
    yield engine
    engine.dispose()


@pytest.fixture(scope="session")
def snowflake_engine():
    """Returns SQLAlchemy engine representing Snowflake Target."""
    path = TEST_MANUFACTURING_PATH if os.path.exists(TEST_MANUFACTURING_PATH) else SNOWFLAKE_PATH
    conn_str = os.getenv("SNOWFLAKE_CONNECTION_STRING", f"sqlite:///{path}")
    engine = sa.create_engine(conn_str)
    yield engine
    engine.dispose()
