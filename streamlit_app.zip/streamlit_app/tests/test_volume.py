"""
Pytest Suite for Volume Reconciliation.
"""
import pytest
from config.models import ValidationConfig, SourceTargetSpec, SystemType, TestStatus
from validations.volume import VolumeValidator


def test_volume_reconciliation_exact():
    config = ValidationConfig(
        scenario_name="Test Volume Parity",
        source=SourceTargetSpec(system_type=SystemType.AZURE_SQL, object_name="fact_sales"),
        target=SourceTargetSpec(system_type=SystemType.SNOWFLAKE, object_name="fact_sales_orders"),
        business_keys=["order_id"]
    )
    validator = VolumeValidator()
    result = validator.validate(config)
    assert result.status in [TestStatus.PASS, TestStatus.FAIL]
    assert result.source_metric is not None
    assert result.target_metric is not None
