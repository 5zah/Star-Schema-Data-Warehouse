"""
Azure SQL Database Connector and Execution Engine.
Supports both remote cloud Azure SQL instances and configured local instances.
"""
import os
import sqlalchemy as sa
from sqlalchemy import text, inspect
from typing import Dict, Any, List, Optional, Tuple
import pandas as pd


class AzureSQLConnector:
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._get_default_config()
        self._engine = None

    def _get_default_config(self) -> Dict[str, Any]:
        return {
            "server":            os.getenv("AZURE_SQL_SERVER", ""),
            "database":          os.getenv("AZURE_SQL_DATABASE", ""),
            "username":          os.getenv("AZURE_SQL_USERNAME", ""),
            "password":          os.getenv("AZURE_SQL_PASSWORD", ""),
            "port":              int(os.getenv("AZURE_SQL_PORT", "1433")),
            "driver":            os.getenv("AZURE_SQL_DRIVER", "ODBC Driver 17 for SQL Server"),
            "connection_string": os.getenv("AZURE_SQL_CONNECTION_STRING", ""),
        }

    def get_connection_url(self) -> str:
        """Build a SQLAlchemy connection URL using a full ODBC connection string.

        Azure SQL requires Encrypt=yes and TrustServerCertificate=no in the
        ODBC string even when port 1433 is reachable — without these the TLS
        handshake fails and pyodbc raises error 08001 / 'database lookup' even
        though TCP connectivity is fine.
        """
        if self.config.get("connection_string"):
            return self.config["connection_string"]

        server   = self.config.get("server", "")
        database = self.config.get("database", "")
        user     = self.config.get("username", "")
        pwd      = self.config.get("password", "")
        port     = self.config.get("port", 1433)
        driver   = self.config.get("driver", "ODBC Driver 17 for SQL Server")

        if server and database:
            from urllib.parse import quote_plus
            # Use SERVER=host,port syntax (comma not colon) — required by SQL Server ODBC
            odbc_str = (
                f"DRIVER={{{driver}}};"
                f"SERVER={server},{port};"
                f"DATABASE={database};"
                f"UID={user};"
                f"PWD={pwd};"
                "Encrypt=yes;"
                "TrustServerCertificate=no;"
                "Connection Timeout=30;"
            )
            params = quote_plus(odbc_str)
            return f"mssql+pyodbc:///?odbc_connect={params}"

        # Fallback to local SQLite sample database if no credentials provided
        local_db = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "..", "data", "azure_sql_sales_dw.db")
        )
        return f"sqlite:///{local_db}"

    def get_engine(self) -> sa.engine.Engine:
        if self._engine is None:
            url = self.get_connection_url()
            self._engine = sa.create_engine(url, fast_executemany=True)
        return self._engine

    def reset_engine(self):
        """Force a fresh engine on next call (use after config changes)."""
        self._engine = None

    def test_connection(self) -> Tuple[bool, str]:
        """Tests live database connectivity without raising unhandled exceptions."""
        try:
            engine = self.get_engine()
            with engine.connect() as conn:
                conn.execute(text("SELECT 1")).fetchone()
            return True, "Connected successfully to Azure SQL Database."
        except Exception as e:
            return False, f"Connection Failed: {str(e)}"

    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """Executes a SQL query and returns results as DataFrame."""
        engine = self.get_engine()
        with engine.connect() as conn:
            return pd.read_sql(text(query), conn, params=params)

    def execute_scalar(self, query: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Executes a scalar query (e.g. COUNT, SUM) directly in database."""
        engine = self.get_engine()
        with engine.connect() as conn:
            result = conn.execute(text(query), params or {})
            return result.scalar()
