"""
Result Processor & Validation Orchestrator.
Coordinates execution of validators, aggregates metrics, persists execution into SQLite repository,
and generates HTML and Excel audit reports.
"""
import time
import datetime
import os
from pathlib import Path
from typing import Dict, Any, List, Optional
from config.models import ValidationConfig, ExecutionSummary, TestResult, TestStatus, MismatchRecord
from config.settings import REPORTS_DIR
from validations.volume import VolumeValidator
from validations.schema import SchemaValidator
from validations.nulls import NullsValidator
from validations.duplicates import DuplicatesValidator
from validations.aggregates import AggregatesValidator
from validations.reconciliation import ReconciliationValidator
from validations.business_rules import BusinessRulesValidator
from repository.sqlite_repository import SQLiteRepository
from reporting.html_report import HTMLReporter
from reporting.excel_report import ExcelReporter


class ResultProcessor:
    def __init__(self, repository: Optional[SQLiteRepository] = None):
        self.repo = repository or SQLiteRepository()
        self.vol_val = VolumeValidator()
        self.sch_val = SchemaValidator()
        self.null_val = NullsValidator()
        self.dup_val = DuplicatesValidator()
        self.agg_val = AggregatesValidator()
        self.rec_val = ReconciliationValidator()
        self.biz_val = BusinessRulesValidator()

    def execute_and_process(self, config: ValidationConfig, progress_callback=None) -> ExecutionSummary:
        """Runs all selected validation suites and returns a consolidated ExecutionSummary."""
        start_time = time.time()
        exec_id = f"EXEC-{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}"
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        all_results: List[TestResult] = []
        all_mismatches: List[MismatchRecord] = []

        total_steps = len(config.selected_tests)
        step = 0

        # 1. Volume
        if "row_count" in config.selected_tests or "volume" in config.selected_tests:
            step += 1
            if progress_callback: progress_callback(step / total_steps, "Executing Volume Reconciliation...")
            res = self.vol_val.validate(config)
            all_results.append(res)

        # 2. Schema
        if "schema" in config.selected_tests or "column_names" in config.selected_tests:
            step += 1
            if progress_callback: progress_callback(step / total_steps, "Validating Schema & Column Integrity...")
            res = self.sch_val.validate(config)
            all_results.append(res)

        # 3. Nulls
        if "null_check" in config.selected_tests or "nulls" in config.selected_tests:
            step += 1
            if progress_callback: progress_callback(step / total_steps, "Auditing Null & Mandatory Constraints...")
            res = self.null_val.validate(config)
            all_results.append(res)

        # 4. Duplicates
        if "duplicate_check" in config.selected_tests or "duplicates" in config.selected_tests:
            step += 1
            if progress_callback: progress_callback(step / total_steps, "Auditing Duplicate Business Keys...")
            res = self.dup_val.validate(config)
            all_results.append(res)

        # 5. Aggregates
        if ("aggregate" in config.selected_tests or "aggregates" in config.selected_tests) and config.aggregate_specs:
            step += 1
            if progress_callback: progress_callback(step / total_steps, "Evaluating Numeric KPI Aggregates...")
            res_list = self.agg_val.validate(config)
            all_results.extend(res_list)

        # 6. Record Reconciliation
        if "record_reconciliation" in config.selected_tests or "reconciliation" in config.selected_tests:
            step += 1
            if progress_callback: progress_callback(step / total_steps, "Reconciling Records & Cell Differences...")
            res, mismatches = self.rec_val.validate(config)
            all_results.append(res)
            all_mismatches.extend(mismatches)

        # 7. Business Rules
        if ("business_rules" in config.selected_tests or "business_rule" in config.selected_tests) and config.business_rules:
            step += 1
            if progress_callback: progress_callback(step / total_steps, "Evaluating Business & Transformation Rules...")
            res_list, mismatches = self.biz_val.validate(config)
            all_results.extend(res_list)
            all_mismatches.extend(mismatches)

        # Consolidate Totals
        total_validations = len(all_results)
        passed_count = sum(1 for r in all_results if r.status == TestStatus.PASS)
        failed_count = sum(1 for r in all_results if r.status == TestStatus.FAIL)
        warnings_count = sum(1 for r in all_results if r.status == TestStatus.WARNING)
        errors_count = sum(1 for r in all_results if r.status == TestStatus.ERROR)

        overall_status = TestStatus.PASS if (failed_count == 0 and errors_count == 0) else TestStatus.FAIL
        pass_rate_pct = round((passed_count / total_validations * 100) if total_validations > 0 else 100.0, 2)

        # Extract rows audited & cells audited from reconciliation or volume
        vol_res = next((r for r in all_results if r.category == "Volume"), None)
        rec_res = next((r for r in all_results if r.category == "Reconciliation"), None)

        total_rows_audited = int(vol_res.source_metric) if vol_res and isinstance(vol_res.source_metric, int) else 0
        total_cells_audited = rec_res.details.get("total_cells", 0) if rec_res and rec_res.details else (total_rows_audited * 10)
        mismatched_cells = rec_res.details.get("mismatched_cells", 0) if rec_res and rec_res.details else len(all_mismatches)
        
        cell_match_pct = round(((total_cells_audited - mismatched_cells) / total_cells_audited * 100) if total_cells_audited > 0 else 100.0, 4)

        duration = round(time.time() - start_time, 3)

        summary = ExecutionSummary(
            execution_id=exec_id,
            timestamp=timestamp,
            scenario_name=config.scenario_name,
            source_desc=f"{config.source.system_type.value.upper()}: {config.source.object_name}",
            target_desc=f"{config.target.system_type.value.upper()}: {config.target.object_name}",
            overall_status=overall_status,
            total_validations=total_validations,
            passed_count=passed_count,
            failed_count=failed_count,
            warnings_count=warnings_count,
            errors_count=errors_count,
            pass_rate_pct=pass_rate_pct,
            total_rows_audited=total_rows_audited,
            total_cells_audited=total_cells_audited,
            total_mismatches=len(all_mismatches),
            cell_match_pct=cell_match_pct,
            execution_duration_sec=duration,
            results=all_results,
            mismatches=all_mismatches,
            config={
                "scenario_name": config.scenario_name,
                "source": config.source.__dict__,
                "target": config.target.__dict__,
                "business_keys": config.business_keys,
                "column_mapping": config.column_mapping,
                "selected_tests": config.selected_tests
            }
        )

        # 1. Save to SQLite Repository
        self.repo.save_execution(summary)

        # 2. Generate HTML & Excel Reports
        html_path = str(REPORTS_DIR / f"{exec_id}_Reconciliation_Report.html")
        excel_path = str(REPORTS_DIR / f"{exec_id}_Reconciliation_Report.xlsx")
        
        HTMLReporter(summary).generate(html_path)
        ExcelReporter(summary).generate(excel_path)

        if progress_callback: progress_callback(1.0, "Execution Complete. Reports Generated.")

        return summary
