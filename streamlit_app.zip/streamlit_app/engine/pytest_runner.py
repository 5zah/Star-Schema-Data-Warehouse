"""
Pytest Runner and Execution Orchestrator.
Executes pytest test suites programmatically, accepts dynamic validation configurations,
captures stdout in real-time, and extracts structured test results.
"""
import sys
import subprocess
import json
import os
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Callable


class PytestRunner:
    def __init__(self, workspace_root: Optional[str] = None):
        self.workspace_root = Path(workspace_root or os.path.dirname(os.path.dirname(__file__)))

    def run_tests(
        self,
        test_path: Optional[str] = None,
        test_filter: Optional[str] = None,
        config_dict: Optional[Dict[str, Any]] = None,
        log_callback: Optional[Callable[[str], None]] = None
    ) -> Tuple[int, List[str]]:
        """
        Executes pytest as a subprocess, streams logs, and returns exit code + full log lines.
        """
        target = test_path or "tests/"
        cmd = [sys.executable, "-m", "pytest", str(target), "-v", "--tb=short"]

        if test_filter:
            cmd.extend(["-k", test_filter])

        env = os.environ.copy()
        if config_dict:
            env["VALIDATION_CONFIG_JSON"] = json.dumps(config_dict, default=str)

        logs = []
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            cwd=str(self.workspace_root),
            env=env
        )

        for line in process.stdout:
            cleaned_line = line.rstrip()
            logs.append(cleaned_line)
            if log_callback:
                log_callback(cleaned_line)

        process.wait()
        return process.returncode, logs
