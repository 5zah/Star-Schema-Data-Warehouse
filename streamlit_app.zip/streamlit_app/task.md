# Task List — Restructure Streamlit App

- [x] Create `streamlit_app` directory
- [x] Move folders: `ui`, `config`, `connections`, `engine`, `metadata`, `reporting`, `repository`, `validations`, `tests`, `database`, `reports`
- [x] Move files: `app.py`, `.env.example`, `pytest.ini`
- [x] Verify paths and imports
