"""
Data Models and Enums for ETL Validation Platform.
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum
import datetime


class SystemType(str, Enum):
    CSV = "csv"
    AZURE_SQL = "azure_sql"
    SNOWFLAKE = "snowflake"


class ObjectType(str, Enum):
    TABLE = "table"
    VIEW = "view"
    FILE = "file"


class TestStatus(str, Enum):
    __test__ = False
    PASS = "PASS"
    FAIL = "FAIL"
    WARNING = "WARNING"
    ERROR = "ERROR"
    SKIPPED = "SKIPPED"


class MetricType(str, Enum):
    SUM = "SUM"
    COUNT = "COUNT"
    AVG = "AVG"
    MIN = "MIN"
    MAX = "MAX"
    DISTINCT_COUNT = "DISTINCT_COUNT"


@dataclass
class SourceTargetSpec:
    system_type: SystemType
    object_name: str
    schema: Optional[str] = "dbo"
    database: Optional[str] = None
    object_type: ObjectType = ObjectType.TABLE
    file_path: Optional[str] = None


@dataclass
class BusinessRuleSpec:
    name: str
    expression: str  # e.g., "quantity * unit_price"
    target_column: str  # e.g., "sales_amount"
    source_columns: List[str] = field(default_factory=list)
    description: Optional[str] = ""


@dataclass
class AggregateSpec:
    metric: MetricType
    source_column: str
    target_column: str
    tolerance_type: str = "absolute"  # "absolute" or "percentage"
    tolerance_value: float = 0.01


@dataclass
class ValidationConfig:
    scenario_name: str
    source: SourceTargetSpec
    target: SourceTargetSpec
    business_keys: List[str]
    column_mapping: Dict[str, str] = field(default_factory=dict)
    selected_tests: List[str] = field(default_factory=lambda: [
        "row_count", "schema", "column_names", "data_types",
        "null_check", "duplicate_check", "aggregate", "record_reconciliation"
    ])
    aggregate_specs: List[AggregateSpec] = field(default_factory=list)
    business_rules: List[BusinessRuleSpec] = field(default_factory=list)
    sample_limit: int = 1000
    batch_size: int = 50000


@dataclass
class MismatchRecord:
    validation_test: str
    record_key: str
    source_column: str
    target_column: str
    source_value: Any
    target_value: Any
    difference: Optional[Any] = None
    status: str = "MISMATCH"


@dataclass
class TestResult:
    __test__ = False
    test_name: str
    category: str  # "Volume", "Schema", "Nulls", "Duplicates", "Aggregates", "Reconciliation", "Business Rules"
    status: TestStatus
    source_metric: Any = None
    target_metric: Any = None
    delta: Any = None
    delta_pct: Optional[float] = None
    details: Any = None
    mismatches_count: int = 0
    sample_mismatches: List[Dict[str, Any]] = field(default_factory=list)
    execution_time_sec: float = 0.0


@dataclass
class ExecutionSummary:
    execution_id: str
    timestamp: str
    scenario_name: str
    source_desc: str
    target_desc: str
    overall_status: TestStatus
    total_validations: int = 0
    passed_count: int = 0
    failed_count: int = 0
    warnings_count: int = 0
    errors_count: int = 0
    pass_rate_pct: float = 100.0
    total_rows_audited: int = 0
    total_cells_audited: int = 0
    total_mismatches: int = 0
    cell_match_pct: float = 100.0
    execution_duration_sec: float = 0.0
    results: List[TestResult] = field(default_factory=list)
    mismatches: List[MismatchRecord] = field(default_factory=list)
    config: Optional[Dict[str, Any]] = None
