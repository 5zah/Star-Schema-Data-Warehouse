"""
Application Configuration and Default Settings.
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPORTS_DIR = BASE_DIR / "reports"
DATABASE_DIR = BASE_DIR / "database"

DATA_DIR.mkdir(exist_ok=True)
REPORTS_DIR.mkdir(exist_ok=True)
DATABASE_DIR.mkdir(exist_ok=True)

# Default Repository Database Path (SQLite)
REPO_DB_PATH = os.getenv("REPO_DB_PATH", str(DATABASE_DIR / "validation_history.db"))

# Execution Defaults
DEFAULT_TOLERANCE = float(os.getenv("DEFAULT_TOLERANCE", "0.01"))
DEFAULT_BATCH_SIZE = int(os.getenv("DEFAULT_BATCH_SIZE", "50000"))
DEFAULT_SAMPLE_LIMIT = int(os.getenv("DEFAULT_SAMPLE_LIMIT", "1000"))
MAX_MISMATCHES_SAVED = int(os.getenv("MAX_MISMATCHES_SAVED", "1000"))
DB_PUSHDOWN_ENABLED = os.getenv("DB_PUSHDOWN_ENABLED", "true").lower() == "true"
