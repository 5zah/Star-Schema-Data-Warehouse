"""
Table Reference Resolver Utility.
Resolves table references appropriately for MSSQL, Snowflake, and SQLite fallback dialects.
"""
def resolve_table_name(spec, engine) -> str:
    if engine and hasattr(engine, "dialect") and engine.dialect.name == "sqlite":
        return spec.object_name
    return f"{spec.schema}.{spec.object_name}" if spec.schema else spec.object_name
