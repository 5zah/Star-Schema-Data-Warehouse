# Streamlit UI Guide — ETL Validation Platform

This document explains exactly what each page in your Streamlit application does, why it exists, and how your team can use it to run end-to-end data reconciliation tests.

## 🎯 High-Level Workflow

The application is designed to be used in this specific order:
1. **Connect** to your databases (Azure SQL & Snowflake).
2. **Discover** what tables and columns exist in those databases.
3. **Configure & Run** a validation test comparing a source table against a target table.
4. **Review** the results, drill down into mismatches, and download reports.

---

## 🧭 Page-by-Page Breakdown

### 1. Dashboard (`ui/dashboard.py`)
- **What it is:** The landing page of the application.
- **Why it's there:** To give you an immediate, high-level overview of the platform's health. It shows KPI cards (like Total Runs, Pass Rate) and a quick table of the most recent validation runs.
- **How to use it:** Start here to see if any scheduled or recent overnight tests failed. Use the quick-navigation buttons to jump straight to testing.

### 2. Connections (`ui/connections.py`)
- **What it is:** The connection manager for your databases.
- **Why it's there:** Streamlit needs to know how to connect to Azure SQL and Snowflake. This page safely accepts your credentials without hard-coding passwords into the source code.
- **How to use it:** Enter your passwords for Azure SQL and Snowflake. Click **"Test Connection"** to verify that the app can successfully reach your databases.

### 3. Data Objects (`ui/objects.py`)
- **What it is:** A dynamic data dictionary / metadata explorer.
- **Why it's there:** Instead of guessing if a table exists, this page queries the actual databases in real-time to list all available Schemas, Tables, Views, and Columns.
- **How to use it:** Select a database (e.g., Azure SQL) and a schema. The page will list all tables. Click on a table to see its columns and data types. This is purely for exploration before you run a test.

### 4. Test Configuration (`ui/configuration.py`)
- **What it is:** An alternative/legacy connection setup page.
- **Why it's there:** Originally used to configure connection parameters and save them to a local JSON file. 
- **How to use it:** It functions identically to the "Connections" page. You can use either page to test and save your database credentials.

### 5. Run Tests (`ui/execution.py`)
- **What it is:** The core validation engine orchestrator.
- **Why it's there:** This is where the actual testing happens. It allows you to map a Source (e.g., Azure SQL table) to a Target (e.g., Snowflake table) and choose exactly which tests to run.
- **How to use it:** 
  1. Enter your Source table and Target table names.
  2. Define the **Business Keys** (e.g., `order_id`) so the system knows how to join the records.
  3. Check the boxes for the tests you want (Row Count, Null Check, Duplicate Check, etc.).
  4. Click **Run Validation**. A progress bar will track the execution.

### 6. Test Results (`ui/results.py`)
- **What it is:** The summary viewer for your test executions.
- **Why it's there:** After a test runs, you need to see exactly which validations passed and which failed.
- **How to use it:** Select a recent execution ID. It will display a color-coded table showing each test (like Volume, Schema, Duplicates) and whether it Passed or Failed, along with the variance (e.g., Target has 5 missing rows).

### 7. Test History (`ui/history.py`)
- **What it is:** A searchable, filterable ledger of all past runs.
- **Why it's there:** For auditability. You can prove to stakeholders that data was tested and verified on a specific date.
- **How to use it:** Use the dropdowns to filter by "FAILED" runs, or search for a specific scenario name. 

### 8. Reports (`ui/reports.py`)
- **What it is:** The download hub for offline reporting.
- **Why it's there:** Stakeholders and business users often prefer Excel or HTML reports over logging into a Streamlit app.
- **How to use it:** Find the run you are interested in and click the download buttons to save the beautifully formatted HTML or Excel reconciliation reports to your local machine.

---

## 💡 Quick Tips for your Team
- **Security:** Tell your team *never* to hard-code their Azure SQL or Snowflake passwords into `.py` files. Always enter them directly into the **Connections** UI or use a local `.env` file.
- **Mismatches:** If a test fails in the **Run Tests** page, the system automatically saves the exact row-level mismatches to the SQLite database, which is what powers the reporting.
