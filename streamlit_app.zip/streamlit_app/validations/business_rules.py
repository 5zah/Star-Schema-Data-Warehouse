"""
Business Rule & Transformation Logic Validator.
Evaluates configuration-driven transformation expressions against target database columns
(e.g., quantity * unit_price == sales_amount) and computes compliance percentage.
"""
import time
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple
from config.models import ValidationConfig, TestResult, TestStatus, SystemType, BusinessRuleSpec, MismatchRecord
from config.utils import resolve_table_name
from connections.azure_sql import AzureSQLConnector
from connections.snowflake import SnowflakeConnector
from connections.csv_reader import CSVConnector


class BusinessRulesValidator:
    def __init__(self, azure_conn=None, snow_conn=None, csv_conn=None):
        self.azure_conn = azure_conn or AzureSQLConnector()
        self.snow_conn = snow_conn or SnowflakeConnector()
        self.csv_conn = csv_conn or CSVConnector()

    def validate(self, config: ValidationConfig) -> Tuple[List[TestResult], List[MismatchRecord]]:
        results = []
        all_mismatches = []
        if not config.business_rules:
            return results, all_mismatches

        df_tgt = self._read_target_data(config.target, limit=config.sample_limit)
        if df_tgt.empty:
            return results, all_mismatches

        for rule in config.business_rules:
            start_time = time.time()
            
            try:
                expected_series = df_tgt.eval(rule.expression)
                actual_series = df_tgt[rule.target_column] if rule.target_column in df_tgt.columns else None

                if actual_series is None:
                    continue

                if pd.api.types.is_numeric_dtype(expected_series) and pd.api.types.is_numeric_dtype(actual_series):
                    diff = (expected_series - actual_series).abs()
                    violations_mask = diff > 0.05
                else:
                    violations_mask = expected_series.astype(str) != actual_series.astype(str)

                violations = df_tgt[violations_mask]
                viol_count = len(violations)
                total_evaluated = len(df_tgt)
                compliance_pct = round(((total_evaluated - viol_count) / total_evaluated * 100) if total_evaluated > 0 else 100.0, 4)

                status = TestStatus.PASS if viol_count == 0 else TestStatus.FAIL

                sample_violations = []
                for _, row in violations.head(20).iterrows():
                    key_val = " | ".join([f"{k}={row[k]}" for k in config.business_keys if k in row]) or f"Index={row.name}"
                    exp_val = expected_series.loc[row.name]
                    act_val = actual_series.loc[row.name]
                    
                    diff_val = round(exp_val - act_val, 4) if pd.api.types.is_numeric_dtype(expected_series) else "Diff"

                    mismatch = MismatchRecord(
                        validation_test=f"Business Rule: {rule.name}",
                        record_key=key_val,
                        source_column=rule.expression,
                        target_column=rule.target_column,
                        source_value=exp_val,
                        target_value=act_val,
                        difference=diff_val,
                        status="FAIL"
                    )
                    all_mismatches.append(mismatch)
                    sample_violations.append({
                        "key": key_val,
                        "expected": str(exp_val),
                        "actual": str(act_val),
                        "diff": str(diff_val)
                    })

                results.append(TestResult(
                    test_name=f"Business Rule: {rule.name} ({rule.expression} -> {rule.target_column})",
                    category="Business Rules",
                    status=status,
                    source_metric=f"{total_evaluated:,} rows",
                    target_metric=f"{total_evaluated - viol_count:,} passed ({compliance_pct:.2f}%)",
                    delta=f"{viol_count:,} violations",
                    delta_pct=round(100.0 - compliance_pct, 4),
                    details={
                        "rule_name": rule.name,
                        "expression": rule.expression,
                        "target_column": rule.target_column,
                        "records_evaluated": total_evaluated,
                        "violations": viol_count,
                        "compliance_pct": f"{compliance_pct:.4f}%",
                        "message": "100% compliance with transformation rule." if viol_count == 0 else f"Found {viol_count} transformation rule violations."
                    },
                    mismatches_count=viol_count,
                    sample_mismatches=sample_violations,
                    execution_time_sec=round(time.time() - start_time, 4)
                ))

            except Exception as e:
                results.append(TestResult(
                    test_name=f"Business Rule: {rule.name}",
                    category="Business Rules",
                    status=TestStatus.ERROR,
                    details={"error": str(e)},
                    execution_time_sec=round(time.time() - start_time, 4)
                ))

        return results, all_mismatches

    def _read_target_data(self, spec, limit: int = 1000) -> pd.DataFrame:
        if spec.system_type == SystemType.CSV:
            return self.csv_conn.read_dataframe(spec.file_path or spec.object_name, limit=limit)
        elif spec.system_type == SystemType.AZURE_SQL:
            table_ref = resolve_table_name(spec, self.azure_conn.get_engine())
            return self.azure_conn.execute_query(f"SELECT * FROM {table_ref} LIMIT {limit}")
        elif spec.system_type == SystemType.SNOWFLAKE:
            table_ref = resolve_table_name(spec, self.snow_conn.get_engine())
            return self.snow_conn.execute_query(f"SELECT * FROM {table_ref} LIMIT {limit}")
        return pd.DataFrame()
