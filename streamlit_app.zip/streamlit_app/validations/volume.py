"""
Volume Reconciliation Validator.
Validates row counts between Source and Target systems using database pushdown where applicable.
"""
import time
from typing import Dict, Any, Tuple
from config.models import ValidationConfig, TestResult, TestStatus, SystemType
from config.utils import resolve_table_name
from connections.azure_sql import AzureSQLConnector
from connections.snowflake import SnowflakeConnector
from connections.csv_reader import CSVConnector


class VolumeValidator:
    def __init__(self, azure_conn=None, snow_conn=None, csv_conn=None):
        self.azure_conn = azure_conn or AzureSQLConnector()
        self.snow_conn = snow_conn or SnowflakeConnector()
        self.csv_conn = csv_conn or CSVConnector()

    def validate(self, config: ValidationConfig) -> TestResult:
        start_time = time.time()
        
        # 1. Fetch Source Count
        src_count = self._get_count(config.source)
        
        # 2. Fetch Target Count
        tgt_count = self._get_count(config.target)
        
        delta = tgt_count - src_count
        delta_pct = round((abs(delta) / src_count * 100) if src_count > 0 else 0.0, 4)
        
        status = TestStatus.PASS if delta == 0 else TestStatus.FAIL

        return TestResult(
            test_name=f"Volume Reconciliation: {config.source.object_name} vs {config.target.object_name}",
            category="Volume",
            status=status,
            source_metric=src_count,
            target_metric=tgt_count,
            delta=delta,
            delta_pct=delta_pct,
            details={
                "source_system": config.source.system_type.value,
                "source_object": config.source.object_name,
                "target_system": config.target.system_type.value,
                "target_object": config.target.object_name,
                "source_rows": src_count,
                "target_rows": tgt_count,
                "delta": delta,
                "delta_pct": f"{delta_pct}%",
                "message": "Volume matches exactly (0 delta)." if delta == 0 else f"Discrepancy of {delta:+d} rows ({delta_pct}%)."
            },
            execution_time_sec=round(time.time() - start_time, 4)
        )

    def _get_count(self, spec) -> int:
        if spec.system_type == SystemType.CSV:
            meta = self.csv_conn.get_metadata(spec.file_path or spec.object_name)
            return meta["row_count"]
        elif spec.system_type == SystemType.AZURE_SQL:
            table_ref = resolve_table_name(spec, self.azure_conn.get_engine())
            return int(self.azure_conn.execute_scalar(f"SELECT COUNT(*) FROM {table_ref}"))
        elif spec.system_type == SystemType.SNOWFLAKE:
            table_ref = resolve_table_name(spec, self.snow_conn.get_engine())
            return int(self.snow_conn.execute_scalar(f"SELECT COUNT(*) FROM {table_ref}"))
        return 0
