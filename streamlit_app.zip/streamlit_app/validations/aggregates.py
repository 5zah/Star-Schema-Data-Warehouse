"""
Numeric KPI & Measures Aggregate Validator.
Validates SUM, AVG, MIN, MAX, COUNT, DISTINCT COUNT between Source and Target with configurable absolute and percentage tolerances.
"""
import time
from typing import Dict, Any, List
from config.models import ValidationConfig, TestResult, TestStatus, SystemType, AggregateSpec, MetricType
from config.utils import resolve_table_name
from connections.azure_sql import AzureSQLConnector
from connections.snowflake import SnowflakeConnector
from connections.csv_reader import CSVConnector


class AggregatesValidator:
    def __init__(self, azure_conn=None, snow_conn=None, csv_conn=None):
        self.azure_conn = azure_conn or AzureSQLConnector()
        self.snow_conn = snow_conn or SnowflakeConnector()
        self.csv_conn = csv_conn or CSVConnector()

    def validate(self, config: ValidationConfig) -> List[TestResult]:
        results = []
        if not config.aggregate_specs:
            return results

        for spec in config.aggregate_specs:
            start_time = time.time()
            
            src_val = self._compute_aggregate(config.source, spec.metric, spec.source_column)
            tgt_val = self._compute_aggregate(config.target, spec.metric, spec.target_column)
            
            src_num = float(src_val or 0.0)
            tgt_num = float(tgt_val or 0.0)
            delta = tgt_num - src_num
            abs_delta = abs(delta)
            
            delta_pct = (abs_delta / abs(src_num) * 100) if src_num != 0 else (0.0 if abs_delta == 0 else 100.0)
            
            if spec.tolerance_type == "percentage":
                passed = delta_pct <= spec.tolerance_value
            else:
                passed = abs_delta <= spec.tolerance_value

            status = TestStatus.PASS if passed else TestStatus.FAIL

            results.append(TestResult(
                test_name=f"Aggregate {spec.metric.value}({spec.source_column}): {config.source.object_name} vs {config.target.object_name}",
                category="Aggregates",
                status=status,
                source_metric=f"{src_num:,.2f}",
                target_metric=f"{tgt_num:,.2f}",
                delta=f"{delta:+,.2f}",
                delta_pct=round(delta_pct, 4),
                details={
                    "metric": spec.metric.value,
                    "source_column": spec.source_column,
                    "target_column": spec.target_column,
                    "source_value": src_num,
                    "target_value": tgt_num,
                    "delta": delta,
                    "delta_pct": f"{delta_pct:.4f}%",
                    "tolerance_type": spec.tolerance_type,
                    "tolerance_threshold": spec.tolerance_value,
                    "tolerance_met": passed,
                    "message": f"Variance of {abs_delta:,.2f} ({delta_pct:.4f}%) is within tolerance." if passed else f"Variance of {abs_delta:,.2f} ({delta_pct:.4f}%) exceeds tolerance threshold {spec.tolerance_value}."
                },
                mismatches_count=0 if passed else 1,
                execution_time_sec=round(time.time() - start_time, 4)
            ))

        return results

    def _compute_aggregate(self, target_spec, metric: MetricType, column: str) -> float:
        metric_sql_map = {
            MetricType.SUM: f"SUM({column})",
            MetricType.COUNT: f"COUNT({column})",
            MetricType.AVG: f"AVG({column})",
            MetricType.MIN: f"MIN({column})",
            MetricType.MAX: f"MAX({column})",
            MetricType.DISTINCT_COUNT: f"COUNT(DISTINCT {column})"
        }
        
        sql_expr = metric_sql_map.get(metric, f"SUM({column})")

        if target_spec.system_type in [SystemType.AZURE_SQL, SystemType.SNOWFLAKE]:
            conn = self.azure_conn if target_spec.system_type == SystemType.AZURE_SQL else self.snow_conn
            table_ref = resolve_table_name(target_spec, conn.get_engine())
            try:
                val = conn.execute_scalar(f"SELECT {sql_expr} FROM {table_ref}")
                return float(val or 0.0)
            except Exception:
                return 0.0
        elif target_spec.system_type == SystemType.CSV:
            df = self.csv_conn.read_dataframe(target_spec.file_path or target_spec.object_name)
            if column in df.columns:
                if metric == MetricType.SUM: return float(df[column].sum())
                elif metric == MetricType.COUNT: return float(df[column].count())
                elif metric == MetricType.AVG: return float(df[column].mean())
                elif metric == MetricType.MIN: return float(df[column].min())
                elif metric == MetricType.MAX: return float(df[column].max())
                elif metric == MetricType.DISTINCT_COUNT: return float(df[column].nunique())
        return 0.0
