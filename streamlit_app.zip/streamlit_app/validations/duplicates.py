"""
Duplicate Business Key Validator.
Validates uniqueness of single or composite primary/business keys using database pushdown.
"""
import time
from typing import Dict, Any, List
from config.models import ValidationConfig, TestResult, TestStatus, SystemType
from config.utils import resolve_table_name
from connections.azure_sql import AzureSQLConnector
from connections.snowflake import SnowflakeConnector
from connections.csv_reader import CSVConnector


class DuplicatesValidator:
    def __init__(self, azure_conn=None, snow_conn=None, csv_conn=None):
        self.azure_conn = azure_conn or AzureSQLConnector()
        self.snow_conn = snow_conn or SnowflakeConnector()
        self.csv_conn = csv_conn or CSVConnector()

    def validate(self, config: ValidationConfig) -> TestResult:
        start_time = time.time()
        
        keys = config.business_keys
        if not keys:
            return TestResult(
                test_name=f"Duplicate Keys Check: {config.target.object_name}",
                category="Duplicates",
                status=TestStatus.SKIPPED,
                details={"message": "No business keys configured for duplicate check."}
            )

        dup_count, sample_dups = self._find_duplicates(config.target, keys)
        status = TestStatus.PASS if dup_count == 0 else TestStatus.FAIL

        return TestResult(
            test_name=f"Duplicate Keys Check on [{', '.join(keys)}]: {config.target.object_name}",
            category="Duplicates",
            status=status,
            source_metric="0 Duplicates Allowed",
            target_metric=f"{dup_count} Duplicate Keys",
            delta=dup_count,
            details={
                "target_object": config.target.object_name,
                "business_keys": keys,
                "duplicate_key_count": dup_count,
                "sample_duplicate_keys": sample_dups,
                "message": "All business keys are unique." if dup_count == 0 else f"Found {dup_count} duplicate key groups."
            },
            mismatches_count=dup_count,
            sample_mismatches=sample_dups,
            execution_time_sec=round(time.time() - start_time, 4)
        )

    def _find_duplicates(self, spec, keys: List[str]):
        key_list_str = ", ".join(keys)
        
        if spec.system_type in [SystemType.AZURE_SQL, SystemType.SNOWFLAKE]:
            conn = self.azure_conn if spec.system_type == SystemType.AZURE_SQL else self.snow_conn
            table_ref = resolve_table_name(spec, conn.get_engine())
            
            query = f"""
                SELECT {key_list_str}, COUNT(*) AS duplicate_count
                FROM {table_ref}
                GROUP BY {key_list_str}
                HAVING COUNT(*) > 1
                LIMIT 50
            """
            try:
                df = conn.execute_query(query)
                dup_count = len(df)
                sample = df.to_dict(orient="records") if dup_count > 0 else []
                return dup_count, sample
            except Exception:
                return 0, []
        elif spec.system_type == SystemType.CSV:
            df = self.csv_conn.read_dataframe(spec.file_path or spec.object_name)
            if all(k in df.columns for k in keys):
                dups = df[df.duplicated(subset=keys, keep=False)]
                dup_count = len(dups)
                sample = dups.head(20).to_dict(orient="records") if dup_count > 0 else []
                return dup_count, sample
        return 0, []
