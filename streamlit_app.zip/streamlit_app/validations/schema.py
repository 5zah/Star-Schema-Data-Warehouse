"""
Schema & Column Parity Validator.
Validates column names, column counts, and datatype compatibility between Source and Target.
"""
import time
from typing import Dict, Any, List, Set
from config.models import ValidationConfig, TestResult, TestStatus, SystemType
from metadata.azure_sql_metadata import AzureSQLMetadata
from metadata.snowflake_metadata import SnowflakeMetadata
from connections.csv_reader import CSVConnector


class SchemaValidator:
    def __init__(self, azure_meta=None, snow_meta=None, csv_conn=None):
        self.azure_meta = azure_meta or AzureSQLMetadata()
        self.snow_meta = snow_meta or SnowflakeMetadata()
        self.csv_conn = csv_conn or CSVConnector()

    def validate(self, config: ValidationConfig) -> TestResult:
        start_time = time.time()
        
        src_cols = self._get_columns(config.source)
        tgt_cols = self._get_columns(config.target)
        
        src_col_names = {c["name"].lower(): c["type"] for c in src_cols}
        tgt_col_names = {c["name"].lower(): c["type"] for c in tgt_cols}
        
        # Consider column mapping
        mapping = {k.lower(): v.lower() for k, v in config.column_mapping.items()}
        
        missing_in_target = []
        for src_c in src_col_names:
            mapped_tgt = mapping.get(src_c, src_c)
            if mapped_tgt not in tgt_col_names:
                missing_in_target.append(src_c)
                
        common_count = len(src_col_names) - len(missing_in_target)
        status = TestStatus.PASS if len(missing_in_target) == 0 else TestStatus.FAIL

        return TestResult(
            test_name=f"Schema & Column Integrity: {config.source.object_name} vs {config.target.object_name}",
            category="Schema",
            status=status,
            source_metric=f"{len(src_cols)} cols",
            target_metric=f"{len(tgt_cols)} cols",
            delta=len(missing_in_target),
            details={
                "source_columns_count": len(src_cols),
                "target_columns_count": len(tgt_cols),
                "common_mapped_columns": common_count,
                "missing_in_target": missing_in_target,
                "source_columns": [c["name"] for c in src_cols],
                "target_columns": [c["name"] for c in tgt_cols]
            },
            mismatches_count=len(missing_in_target),
            execution_time_sec=round(time.time() - start_time, 4)
        )

    def _get_columns(self, spec) -> List[Dict[str, Any]]:
        if spec.system_type == SystemType.CSV:
            meta = self.csv_conn.get_metadata(spec.file_path or spec.object_name)
            return meta["columns"]
        elif spec.system_type == SystemType.AZURE_SQL:
            return self.azure_meta.get_columns(spec.object_name, schema=spec.schema or "dbo")
        elif spec.system_type == SystemType.SNOWFLAKE:
            return self.snow_meta.get_columns(spec.object_name, schema=spec.schema or "PUBLIC")
        return []
