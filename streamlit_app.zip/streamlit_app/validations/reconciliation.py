"""
Key-Based Record & Cell-Level Attribute Reconciliation Engine.
Joins source and target datasets on business keys, identifies missing/extra keys,
and performs cell-by-cell discrepancy comparisons with drill-down extraction.
"""
import time
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Tuple
from config.models import ValidationConfig, TestResult, TestStatus, SystemType, MismatchRecord
from config.utils import resolve_table_name
from connections.azure_sql import AzureSQLConnector
from connections.snowflake import SnowflakeConnector
from connections.csv_reader import CSVConnector


class ReconciliationValidator:
    def __init__(self, azure_conn=None, snow_conn=None, csv_conn=None):
        self.azure_conn = azure_conn or AzureSQLConnector()
        self.snow_conn = snow_conn or SnowflakeConnector()
        self.csv_conn = csv_conn or CSVConnector()

    def validate(self, config: ValidationConfig) -> Tuple[TestResult, List[MismatchRecord]]:
        start_time = time.time()
        keys = config.business_keys
        
        if not keys:
            return TestResult(
                test_name=f"Record Reconciliation: {config.source.object_name} vs {config.target.object_name}",
                category="Reconciliation",
                status=TestStatus.SKIPPED,
                details={"message": "No business keys defined for reconciliation."}
            ), []

        df_src = self._read_data(config.source, limit=config.sample_limit)
        df_tgt = self._read_data(config.target, limit=config.sample_limit)

        mapping = config.column_mapping or {k: k for k in df_src.columns if k in df_tgt.columns}
        
        for k in keys:
            if k not in mapping and k in df_src.columns:
                mapping[k] = k

        src_cols = [c for c in mapping.keys() if c in df_src.columns]
        tgt_cols = [mapping[c] for c in src_cols if mapping[c] in df_tgt.columns]

        rename_map = {mapping[c]: f"{c}_tgt" for c in src_cols if c not in keys and mapping[c] in df_tgt.columns}
        df_tgt_renamed = df_tgt.rename(columns=rename_map)

        merged = pd.merge(
            df_src[src_cols],
            df_tgt_renamed,
            on=keys,
            how="outer",
            indicator=True
        )

        missing_in_target = merged[merged["_merge"] == "left_only"]
        missing_in_source = merged[merged["_merge"] == "right_only"]
        matched_rows = merged[merged["_merge"] == "both"]

        mismatches: List[MismatchRecord] = []
        mismatches_sample_dict = []

        cols_to_compare = [c for c in src_cols if c not in keys and f"{c}_tgt" in matched_rows.columns]
        
        total_cells_checked = len(matched_rows) * len(cols_to_compare)
        mismatched_cells = 0

        for col in cols_to_compare:
            src_col_name = col
            tgt_col_name = f"{col}_tgt"
            
            src_series = matched_rows[src_col_name]
            tgt_series = matched_rows[tgt_col_name]

            if pd.api.types.is_numeric_dtype(src_series) and pd.api.types.is_numeric_dtype(tgt_series):
                diff = (src_series - tgt_series).abs()
                bad_mask = diff > 0.01
            else:
                bad_mask = src_series.astype(str).str.strip() != tgt_series.astype(str).str.strip()

            bad_indices = matched_rows[bad_mask]
            mismatched_cells += len(bad_indices)

            for _, row in bad_indices.head(100).iterrows():
                key_val = " | ".join([f"{k}={row[k]}" for k in keys])
                src_val = row[src_col_name]
                tgt_val = row[tgt_col_name]
                
                diff_val = round(src_val - tgt_val, 4) if pd.api.types.is_numeric_dtype(src_series) else "Diff"

                rec = MismatchRecord(
                    validation_test="Record Reconciliation",
                    record_key=key_val,
                    source_column=src_col_name,
                    target_column=mapping.get(src_col_name, src_col_name),
                    source_value=src_val,
                    target_value=tgt_val,
                    difference=diff_val,
                    status="FAIL"
                )
                mismatches.append(rec)
                if len(mismatches_sample_dict) < 20:
                    mismatches_sample_dict.append({
                        "key": key_val,
                        "column": src_col_name,
                        "source": str(src_val),
                        "target": str(tgt_val),
                        "diff": str(diff_val)
                    })

        for _, row in missing_in_target.head(50).iterrows():
            key_val = " | ".join([f"{k}={row[k]}" for k in keys])
            mismatches.append(MismatchRecord(
                validation_test="Record Reconciliation (Missing in Target)",
                record_key=key_val,
                source_column="*",
                target_column="*",
                source_value="EXISTS",
                target_value="MISSING",
                difference="Dropped Record",
                status="MISSING_TARGET"
            ))

        cell_match_pct = round(((total_cells_checked - mismatched_cells) / total_cells_checked * 100) if total_cells_checked > 0 else 100.0, 4)
        passed = (len(missing_in_target) == 0 and len(missing_in_source) == 0 and mismatched_cells == 0)

        result = TestResult(
            test_name=f"Record & Cell Reconciliation: {config.source.object_name} vs {config.target.object_name}",
            category="Reconciliation",
            status=TestStatus.PASS if passed else TestStatus.FAIL,
            source_metric=f"{len(df_src):,} rows",
            target_metric=f"{len(df_tgt):,} rows",
            delta=f"{mismatched_cells:,} mismatched cells",
            delta_pct=round(100.0 - cell_match_pct, 4),
            details={
                "rows_compared": len(matched_rows),
                "columns_checked": len(cols_to_compare),
                "total_cells": total_cells_checked,
                "mismatched_cells": mismatched_cells,
                "cell_match_pct": f"{cell_match_pct:.4f}%",
                "missing_in_target_count": len(missing_in_target),
                "missing_in_source_count": len(missing_in_source),
                "sample_limit": config.sample_limit
            },
            mismatches_count=mismatched_cells + len(missing_in_target) + len(missing_in_source),
            sample_mismatches=mismatches_sample_dict,
            execution_time_sec=round(time.time() - start_time, 4)
        )

        return result, mismatches

    def _read_data(self, spec, limit: int = 1000) -> pd.DataFrame:
        if spec.system_type == SystemType.CSV:
            return self.csv_conn.read_dataframe(spec.file_path or spec.object_name, limit=limit)
        elif spec.system_type == SystemType.AZURE_SQL:
            table_ref = resolve_table_name(spec, self.azure_conn.get_engine())
            return self.azure_conn.execute_query(f"SELECT * FROM {table_ref} LIMIT {limit}")
        elif spec.system_type == SystemType.SNOWFLAKE:
            table_ref = resolve_table_name(spec, self.snow_conn.get_engine())
            return self.snow_conn.execute_query(f"SELECT * FROM {table_ref} LIMIT {limit}")
        return pd.DataFrame()
