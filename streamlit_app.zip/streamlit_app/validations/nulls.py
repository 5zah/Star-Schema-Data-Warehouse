"""
Null Value & Mandatory Column Constraint Validator.
Validates that mandatory primary keys, foreign keys, and measures contain zero NULL values using DB pushdown.
"""
import time
from typing import Dict, Any, List
from config.models import ValidationConfig, TestResult, TestStatus, SystemType
from config.utils import resolve_table_name
from connections.azure_sql import AzureSQLConnector
from connections.snowflake import SnowflakeConnector
from connections.csv_reader import CSVConnector


class NullsValidator:
    def __init__(self, azure_conn=None, snow_conn=None, csv_conn=None):
        self.azure_conn = azure_conn or AzureSQLConnector()
        self.snow_conn = snow_conn or SnowflakeConnector()
        self.csv_conn = csv_conn or CSVConnector()

    def validate(self, config: ValidationConfig) -> TestResult:
        start_time = time.time()
        
        cols_to_check = list(set(config.business_keys + list(config.column_mapping.values())))
        if not cols_to_check:
            cols_to_check = config.business_keys or ["order_id"]

        null_counts = self._get_null_counts(config.target, cols_to_check)
        
        total_nulls = sum(null_counts.values())
        failed_columns = {k: v for k, v in null_counts.items() if v > 0}
        
        status = TestStatus.PASS if total_nulls == 0 else TestStatus.FAIL

        return TestResult(
            test_name=f"Null Constraints Check: {config.target.object_name}",
            category="Nulls",
            status=status,
            source_metric="0 Nulls Allowed",
            target_metric=f"{total_nulls} Nulls Found",
            delta=total_nulls,
            details={
                "target_object": config.target.object_name,
                "columns_audited": cols_to_check,
                "null_counts_per_column": null_counts,
                "failed_columns": failed_columns,
                "message": "Zero NULL violations detected across mandatory columns." if total_nulls == 0 else f"Found {total_nulls} NULL values in mandatory columns."
            },
            mismatches_count=total_nulls,
            execution_time_sec=round(time.time() - start_time, 4)
        )

    def _get_null_counts(self, spec, columns: List[str]) -> Dict[str, int]:
        results = {}
        if not columns:
            return results

        if spec.system_type in [SystemType.AZURE_SQL, SystemType.SNOWFLAKE]:
            conn = self.azure_conn if spec.system_type == SystemType.AZURE_SQL else self.snow_conn
            table_ref = resolve_table_name(spec, conn.get_engine())
            
            clauses = [f"SUM(CASE WHEN {col} IS NULL THEN 1 ELSE 0 END) AS null_{i}" for i, col in enumerate(columns)]
            query = f"SELECT {', '.join(clauses)} FROM {table_ref}"
            try:
                df = conn.execute_query(query)
                if not df.empty:
                    row = df.iloc[0]
                    for i, col in enumerate(columns):
                        results[col] = int(row.get(f"null_{i}", 0) or 0)
            except Exception:
                for col in columns:
                    try:
                        c = conn.execute_scalar(f"SELECT COUNT(*) FROM {table_ref} WHERE {col} IS NULL")
                        results[col] = int(c or 0)
                    except Exception:
                        pass
        elif spec.system_type == SystemType.CSV:
            df = self.csv_conn.read_dataframe(spec.file_path or spec.object_name)
            for col in columns:
                if col in df.columns:
                    results[col] = int(df[col].isnull().sum())
        return results
