"""
Dynamic Metadata Discovery for Azure SQL.
Retrieves schemas, tables, views, columns, and data types directly from the database metadata.
"""
from typing import Dict, Any, List, Optional
import sqlalchemy as sa
from sqlalchemy import inspect, text
from connections.azure_sql import AzureSQLConnector


class AzureSQLMetadata:
    def __init__(self, connector: Optional[AzureSQLConnector] = None):
        self.connector = connector or AzureSQLConnector()

    def get_schemas(self) -> List[str]:
        """Returns all database schemas."""
        try:
            engine = self.connector.get_engine()
            inspector = inspect(engine)
            schemas = inspector.get_schema_names()
            return schemas if schemas else ["dbo"]
        except Exception:
            return ["dbo"]

    def get_tables(self, schema: str = "dbo") -> List[str]:
        """Returns all table names in the given schema."""
        try:
            engine = self.connector.get_engine()
            inspector = inspect(engine)
            return inspector.get_table_names(schema=schema)
        except Exception:
            return []

    def get_views(self, schema: str = "dbo") -> List[str]:
        """Returns all view names in the given schema."""
        try:
            engine = self.connector.get_engine()
            inspector = inspect(engine)
            return inspector.get_view_names(schema=schema)
        except Exception:
            return []

    def get_columns(self, object_name: str, schema: str = "dbo") -> List[Dict[str, Any]]:
        """Returns column details (name, type, nullable, primary_key) for table or view."""
        try:
            engine = self.connector.get_engine()
            inspector = inspect(engine)
            columns = inspector.get_columns(object_name, schema=schema)
            return [
                {
                    "name": col["name"],
                    "type": str(col["type"]),
                    "nullable": col.get("nullable", True),
                    "primary_key": col.get("primary_key", False)
                }
                for col in columns
            ]
        except Exception as e:
            # Fallback for views or complex types
            try:
                df = self.connector.execute_query(f"SELECT * FROM {object_name} LIMIT 0")
                return [{"name": c, "type": str(t), "nullable": True, "primary_key": False} for c, t in df.dtypes.items()]
            except Exception:
                return []
