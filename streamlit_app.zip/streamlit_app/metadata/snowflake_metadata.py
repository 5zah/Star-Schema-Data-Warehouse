"""
Dynamic Metadata Discovery for Snowflake Data Warehouse.
Retrieves databases, schemas, tables, views, columns, and data types.
"""
from typing import Dict, Any, List, Optional
import sqlalchemy as sa
from sqlalchemy import inspect, text
from connections.snowflake import SnowflakeConnector


class SnowflakeMetadata:
    def __init__(self, connector: Optional[SnowflakeConnector] = None):
        self.connector = connector or SnowflakeConnector()

    def get_schemas(self, database: Optional[str] = None) -> List[str]:
        """Returns all schemas in the database."""
        try:
            engine = self.connector.get_engine()
            inspector = inspect(engine)
            schemas = inspector.get_schema_names()
            return schemas if schemas else ["PUBLIC"]
        except Exception:
            return ["PUBLIC"]

    def get_tables(self, schema: str = "PUBLIC") -> List[str]:
        """Returns all table names in the given schema."""
        try:
            engine = self.connector.get_engine()
            inspector = inspect(engine)
            return inspector.get_table_names(schema=schema)
        except Exception:
            return []

    def get_views(self, schema: str = "PUBLIC") -> List[str]:
        """Returns all view names in the given schema."""
        try:
            engine = self.connector.get_engine()
            inspector = inspect(engine)
            return inspector.get_view_names(schema=schema)
        except Exception:
            return []

    def get_columns(self, object_name: str, schema: str = "PUBLIC") -> List[Dict[str, Any]]:
        """Returns column details (name, type, nullable) for a table or view."""
        try:
            engine = self.connector.get_engine()
            inspector = inspect(engine)
            columns = inspector.get_columns(object_name, schema=schema)
            return [
                {
                    "name": col["name"],
                    "type": str(col["type"]),
                    "nullable": col.get("nullable", True),
                    "primary_key": col.get("primary_key", False)
                }
                for col in columns
            ]
        except Exception:
            try:
                df = self.connector.execute_query(f"SELECT * FROM {object_name} LIMIT 0")
                return [{"name": c, "type": str(t), "nullable": True, "primary_key": False} for c, t in df.dtypes.items()]
            except Exception:
                return []
