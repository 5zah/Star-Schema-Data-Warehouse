# Project Directory Map

This document outlines the locations of all critical files and directories for the ETL Validation Platform. 

> [!NOTE]
> All paths listed below are relative to the **new** root project directory: `c:\Users\faiza\Downloads\Testing Profile\ETL testing\streamlit_app\`

## 1. Application Entry Points
- **[`app.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/app.py)** — The main Streamlit application entry point. Run `streamlit run app.py` from the `streamlit_app` folder to start the UI.
- **[`.env.example`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/.env.example)** — The template for database credentials. Copy this to `.env` and fill in your passwords securely.

## 2. Streamlit UI Pages (`ui/`)
This folder contains the isolated code for each page in the Streamlit sidebar.
- **[`ui/dashboard.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/dashboard.py)** — Renders the landing page and KPI cards.
- **[`ui/connections.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/connections.py)** — Handles the UI for entering and testing database credentials.
- **[`ui/objects.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/objects.py)** — Renders the dynamic schema and table explorer.
- **[`ui/configuration.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/configuration.py)** — An alternative/legacy page for connection setups.
- **[`ui/execution.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/execution.py)** — Renders the test selection interface and triggers the validation engine.
- **[`ui/results.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/results.py)** — Displays the pass/fail summaries for test runs.
- **[`ui/mismatches.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/mismatches.py)** — Displays the row-by-row data discrepancies.
- **[`ui/history.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/history.py)** — Displays the searchable ledger of past test runs.
- **[`ui/reports.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/reports.py)** — Renders the download links for HTML and Excel reports.
- **[`ui/settings.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/ui/settings.py)** — Manages global execution thresholds (e.g. tolerances, sample limits).

## 3. Database Connectors (`connections/`)
Handles the low-level connection logic to external data sources.
- **[`connections/azure_sql.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/connections/azure_sql.py)** — Azure SQL Server connection class.
- **[`connections/snowflake.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/connections/snowflake.py)** — Snowflake data warehouse connection class.
- **[`connections/csv_reader.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/connections/csv_reader.py)** — File-based CSV connection logic.

## 4. Metadata Discovery (`metadata/`)
Contains the logic for querying the databases to find what tables and columns exist.
- **[`metadata/azure_sql_metadata.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/metadata/azure_sql_metadata.py)** 
- **[`metadata/snowflake_metadata.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/metadata/snowflake_metadata.py)** 

## 5. Core Validation Engine (`engine/` & `validations/`)
The heavy lifting of comparing data.
- **[`engine/result_processor.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/engine/result_processor.py)** — The central orchestrator that runs the tests and compiles the final report.
- **[`validations/volume.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/validations/volume.py)** — Row count comparison logic.
- **[`validations/schema.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/validations/schema.py)** — Column structure comparison logic.
- **[`validations/nulls.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/validations/nulls.py)** — Null constraint validation logic.
- **[`validations/duplicates.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/validations/duplicates.py)** — Business key uniqueness logic.
- **[`validations/aggregates.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/validations/aggregates.py)** — Numeric KPI comparison logic (e.g. sums, averages).
- **[`validations/reconciliation.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/validations/reconciliation.py)** — Row-by-row attribute comparison logic.

## 6. Data Storage & Reporting (`repository/` & `reporting/`)
- **[`repository/sqlite_repository.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/repository/sqlite_repository.py)** — Saves test results, mismatches, and execution history into a local SQLite database (`database/runs.db`).
- **[`reporting/html_report.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/reporting/html_report.py)** — Generates the styled HTML reports.
- **[`reporting/excel_report.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/streamlit_app/reporting/excel_report.py)** — Generates the downloadable `.xlsx` files.
