"""
Unit and Integration Tests for Reusable Reconciliation Engine and Star Schema DWH.

Test Categories:
  - PASS Tests: Verify correct ETL behavior against clean, accurate data.
  - FAIL Tests: Deliberately inject corruptions/mismatches to confirm the engine
                catches and correctly reports failures (anomaly detection).
"""
import os
import unittest
import pandas as pd
import sqlalchemy as sa
from sqlalchemy import text

from src.warehouse.schema_builder import DWHDDLBuilder
from src.warehouse.transformer import DWHTransformer
from src.warehouse.migration_pipeline import MigrationPipeline
from src.scaling.data_scaler import ManufacturingDataScaler
from src.reconciliation.volume_validator import VolumeValidator
from src.reconciliation.attribute_validator import AttributeValidator
from src.reconciliation.aggregate_validator import AggregateValidator
from src.reconciliation.multi_source_validator import MultiSourceValidator
from src.connectors.sqlalchemy_connector import SQLAlchemyConnector
from src.connectors.excel_connector import ExcelConnector


# ============================================================
#  SHARED TEST FIXTURE
#  - Builds DWH once, then intentionally corrupts a CLONE
#    for all FAIL-category tests.
# ============================================================

class TestEnterpriseETLReconciliation(unittest.TestCase):
    """
    TEST SUITE OVERVIEW
    =====================================================================
    PASS Tests (7): Confirm that a clean ETL migration produces 100%
                    matching volume, attributes, aggregates, and multi-
                    source consistency.

    FAIL Tests (7): Inject specific, real-world ETL defects (missing rows,
                    numeric corruption, string corruption, aggregate drift,
                    orphaned foreign keys, truncated loads, out-of-range
                    values) and assert the engine detects each one.
    =====================================================================
    """

    @classmethod
    def setUpClass(cls):
        os.makedirs("data", exist_ok=True)

        # ── CLEAN DWH (used by all PASS tests) ──────────────────────────
        cls.test_db_path = "data/test_manufacturing_dwh.db"
        cls.conn_str = f"sqlite:///{cls.test_db_path}"

        builder = DWHDDLBuilder(cls.conn_str)
        builder.build_schema(drop_existing=True)

        pipeline = MigrationPipeline(
            relational_excel_path="manufacturing_relational_data.xlsx",
            flat_excel_path="manufacturing_mock_data.xlsx",
            target_db_conn_str=cls.conn_str
        )
        cls.migration_summary = pipeline.run_migration(drop_existing=True)

        cls.src_excel_conn = ExcelConnector("src_excel", "manufacturing_relational_data.xlsx")
        cls.src_flat_conn  = ExcelConnector("src_flat",  "manufacturing_mock_data.xlsx")
        cls.tgt_dwh_conn   = SQLAlchemyConnector("tgt_dwh", cls.conn_str)

        # ── CORRUPTED DWH CLONE (used by all FAIL tests) ────────────────
        cls.fail_db_path = "data/test_fail_dwh.db"
        cls.fail_conn_str = f"sqlite:///{cls.fail_db_path}"

        fail_builder = DWHDDLBuilder(cls.fail_conn_str)
        fail_builder.build_schema(drop_existing=True)

        fail_pipeline = MigrationPipeline(
            relational_excel_path="manufacturing_relational_data.xlsx",
            flat_excel_path="manufacturing_mock_data.xlsx",
            target_db_conn_str=cls.fail_conn_str
        )
        fail_pipeline.run_migration(drop_existing=True)

        # --- Inject Anomalies Into the Corrupted Clone -----------------
        fail_engine = sa.create_engine(cls.fail_conn_str)
        with fail_engine.connect() as conn:
            # FAIL-1: Delete 3 work order rows  → triggers Volume FAIL
            conn.execute(text(
                "DELETE FROM fact_work_orders WHERE work_order_number IN "
                "('WO-2023000','WO-2023001','WO-2023002')"
            ))
            # FAIL-2: Corrupt numeric measure  → triggers Attribute & Aggregate FAIL
            conn.execute(text(
                "UPDATE fact_work_orders "
                "SET planned_quantity = 99999.0, scrap_quantity = -500.0 "
                "WHERE work_order_number = 'WO-2023003'"
            ))
            # FAIL-3: Corrupt string attribute → triggers Attribute FAIL
            conn.execute(text(
                "UPDATE fact_work_orders "
                "SET order_status = 'INVALID_STATUS_XYZ' "
                "WHERE work_order_number = 'WO-2023004'"
            ))
            # FAIL-4: Zero out all cost measures on 10 rows → triggers Aggregate FAIL
            conn.execute(text(
                "UPDATE fact_cost_financials "
                "SET material_cost_usd = 0, labor_cost_usd = 0, total_unit_cost_usd = 0 "
                "WHERE rowid <= 10"
            ))
            # FAIL-5: Wipe out all machine telemetry rows → triggers Volume FAIL
            conn.execute(text("DELETE FROM fact_machine_telemetry WHERE rowid <= 50"))
            conn.commit()
        fail_engine.dispose()
        cls.fail_dwh_conn = SQLAlchemyConnector("fail_dwh", cls.fail_conn_str)

    # ==================================================================
    # SECTION A: PASS TESTS — Clean migration, 100% match expected
    # ==================================================================

    def test_P01_schema_tables_created(self):
        """[PASS] All 12 Dimensions and 8 Fact tables must exist in target DWH."""
        builder = DWHDDLBuilder(self.conn_str)
        tables = builder.get_table_list()

        expected_dims = [
            "dim_date", "dim_location", "dim_color", "dim_plant",
            "dim_production_line", "dim_product", "dim_machine",
            "dim_operator", "dim_supplier", "dim_material",
            "dim_material_sales", "dim_defect_catalog"
        ]
        expected_facts = [
            "fact_work_orders", "fact_sales_detail", "fact_order_detail",
            "fact_machine_telemetry", "fact_quality_inspections",
            "fact_labor_performance", "fact_cost_financials", "fact_procurement"
        ]
        for d in expected_dims:
            self.assertIn(d, tables, f"Missing dimension: {d}")
        for f in expected_facts:
            self.assertIn(f, tables, f"Missing fact table: {f}")

    def test_P02_migration_row_counts(self):
        """[PASS] Migration must report SUCCESS and populate all tables with data."""
        self.assertEqual(self.migration_summary["status"], "SUCCESS")
        counts = self.migration_summary["table_counts"]
        self.assertGreater(counts["fact_work_orders"], 0)
        self.assertGreater(counts["fact_sales_detail"], 0)
        self.assertGreater(counts["fact_order_detail"], 0)
        self.assertGreater(counts["dim_plant"], 0)
        self.assertGreater(counts["dim_color"], 0)

    def test_P03_volume_reconciliation(self):
        """[PASS] VolumeValidator must report 0 row delta between source and clean DWH."""
        vol = VolumeValidator()
        res = vol.validate_table_pair(
            rule_name="Work Orders Volume Test",
            source_connector=self.src_excel_conn,
            source_table="Work_Orders",
            target_connector=self.tgt_dwh_conn,
            target_table="fact_work_orders",
            key_column="Work_Order_Number",
            target_key_column="work_order_number"
        )
        self.assertEqual(res["status"], "PASS")
        self.assertEqual(res["diff"], 0)
        self.assertEqual(res["missing_in_target_count"], 0)

    def test_P04_attribute_cell_reconciliation(self):
        """[PASS] AttributeValidator must achieve 100% cell match on clean DWH."""
        att = AttributeValidator()
        res = att.validate_attributes(
            validation_name="Work Orders Attribute Check",
            source_connector=self.src_excel_conn,
            source_table="Work_Orders",
            target_connector=self.tgt_dwh_conn,
            target_table="fact_work_orders",
            primary_key_map={"source": "Work_Order_Number", "target": "work_order_number"},
            column_mappings=[
                {"source": "Planned_Quantity",  "target": "planned_quantity",  "type": "float"},
                {"source": "Produced_Quantity", "target": "produced_quantity", "type": "float"},
                {"source": "Good_Quantity",      "target": "good_quantity",      "type": "float"},
                {"source": "Yield_Percent",      "target": "yield_percent",      "type": "float"},
                {"source": "Order_Status",       "target": "order_status",       "type": "string"}
            ]
        )
        self.assertEqual(res["status"], "PASS")
        self.assertEqual(res["match_percent"], 100.0)
        self.assertEqual(res["mismatched_cells_count"], 0)

    def test_P05_aggregate_measure_reconciliation(self):
        """[PASS] AggregateValidator must confirm SUM/AVG metrics within tolerance."""
        agg = AggregateValidator()
        res = agg.validate_aggregates(
            test_name="Work Orders Production Aggregates",
            source_connector=self.src_excel_conn,
            source_table="Work_Orders",
            target_connector=self.tgt_dwh_conn,
            target_table="fact_work_orders",
            metrics=[
                {"source_col": "Planned_Quantity",  "target_col": "planned_quantity",  "agg": "sum"},
                {"source_col": "Produced_Quantity", "target_col": "produced_quantity", "agg": "sum"},
                {"source_col": "Good_Quantity",     "target_col": "good_quantity",     "agg": "sum"},
                {"source_col": "Yield_Percent",     "target_col": "yield_percent",     "agg": "avg"}
            ]
        )
        self.assertEqual(res["status"], "PASS")
        self.assertEqual(res["failed_metrics"], 0)

    def test_P06_multi_source_consistency(self):
        """[PASS] MultiSourceValidator must confirm Flat Excel vs Relational are consistent."""
        msc = MultiSourceValidator()
        res = msc.assess_cross_source_consistency(
            assessment_name="Flat vs Relational Work Orders",
            source1_connector=self.src_flat_conn,
            source1_table="Manufacturing_Data",
            source1_key="Work_Order_Number",
            source2_connector=self.src_excel_conn,
            source2_table="Work_Orders",
            source2_key="Work_Order_Number",
            columns_to_compare=["Plant_Code", "Product_SKU", "Planned_Quantity", "Produced_Quantity"]
        )
        self.assertEqual(res["status"], "PASS")

    def test_P07_data_scaler(self):
        """[PASS] Data scaler must produce 2x data with intact referential integrity."""
        scaler = ManufacturingDataScaler(seed_file="manufacturing_relational_data.xlsx")
        scaled = scaler.scale_dataset(multiplier=2)

        self.assertGreaterEqual(len(scaled["Work_Orders"]), 2000)
        self.assertGreaterEqual(len(scaled["Plants"]),      2000)
        self.assertGreaterEqual(len(scaled["Machines"]),    2000)

        wo_df    = scaled["Work_Orders"]
        valid_plants = set(scaled["Plants"]["Plant_Code"].tolist())
        valid_lines  = set(scaled["Production_Lines"]["Line_ID"].tolist())
        valid_prods  = set(scaled["Products"]["Product_SKU"].tolist())

        self.assertTrue(all(p in valid_plants for p in wo_df["Plant_Code"]),
                        "Work Orders contain invalid Plant FKs!")
        self.assertTrue(all(l in valid_lines  for l in wo_df["Line_ID"]),
                        "Work Orders contain invalid Production Line FKs!")
        self.assertTrue(all(p in valid_prods  for p in wo_df["Product_SKU"]),
                        "Work Orders contain invalid Product FKs!")

    # ==================================================================
    # SECTION B: FAIL TESTS — Corrupted DWH, engine must detect each defect
    # ==================================================================

    def test_F01_volume_fail_missing_rows(self):
        """
        [FAIL] Volume reconciliation must FAIL when 3 rows are deleted from fact_work_orders.

        Real-world ETL scenario: Truncate-and-reload job aborted mid-run, leaving
        some records missing in the target. The engine must detect the shortfall.
        """
        vol = VolumeValidator()
        res = vol.validate_table_pair(
            rule_name="Work Orders Volume FAIL Test",
            source_connector=self.src_excel_conn,
            source_table="Work_Orders",
            target_connector=self.fail_dwh_conn,
            target_table="fact_work_orders",
            key_column="Work_Order_Number",
            target_key_column="work_order_number"
        )
        self.assertIn(
            res["status"], ["FAIL", "WARNING"],
            f"Engine should have flagged missing rows but returned: {res['status']}"
        )
        # diff = target_count - source_count → negative means rows are MISSING in target
        self.assertLess(res["diff"], 0,
            f"Expected missing rows delta < 0 (rows missing from target), got: {res['diff']}")
        self.assertGreater(res["missing_in_target_count"], 0,
            f"Expected missing_in_target_count > 0, got: {res['missing_in_target_count']}")

    def test_F02_volume_fail_truncated_table(self):
        """
        [FAIL] Volume reconciliation must FAIL when 50 machine telemetry rows are deleted.

        Real-world ETL scenario: Partial loads caused by network timeout during
        high-frequency IoT sensor data ingestion.
        """
        vol = VolumeValidator()
        res = vol.validate_table_pair(
            rule_name="Machine Telemetry Truncation FAIL Test",
            source_connector=self.src_excel_conn,
            source_table="Machine_Process_Readings",
            target_connector=self.fail_dwh_conn,
            target_table="fact_machine_telemetry",
            key_column="Reading_ID",
            target_key_column="reading_id"
        )
        self.assertIn(
            res["status"], ["FAIL", "WARNING"],
            f"Engine should flag truncated telemetry rows, got: {res['status']}"
        )
        # diff = target_count - source_count → negative means target is short
        self.assertLess(res["diff"], 0,
            f"Expected row delta < 0 (truncated target), got: {res['diff']}")

    def test_F03_attribute_fail_numeric_corruption(self):
        """
        [FAIL] Attribute validation must FAIL when planned_quantity is corrupted to 99999.0.

        Real-world ETL scenario: Data type casting bug in ETL transformation
        stage produced overflow values for numeric fields.
        """
        att = AttributeValidator()
        res = att.validate_attributes(
            validation_name="Work Orders Numeric Corruption FAIL Test",
            source_connector=self.src_excel_conn,
            source_table="Work_Orders",
            target_connector=self.fail_dwh_conn,
            target_table="fact_work_orders",
            primary_key_map={"source": "Work_Order_Number", "target": "work_order_number"},
            column_mappings=[
                {"source": "Planned_Quantity", "target": "planned_quantity", "type": "float", "atol": 0.01},
                {"source": "Scrap_Quantity",   "target": "scrap_quantity",   "type": "float", "atol": 0.01}
            ]
        )
        self.assertEqual(res["status"], "FAIL",
            f"Engine should have caught numeric corruption. Got: {res['status']}")
        self.assertGreater(res["mismatched_cells_count"], 0,
            f"Expected mismatch cells > 0, got: {res['mismatched_cells_count']}")

    def test_F04_attribute_fail_string_corruption(self):
        """
        [FAIL] Attribute validation must FAIL when order_status is set to an invalid enum value.

        Real-world ETL scenario: A lookup/mapping table was not refreshed during
        a system migration, causing stale or unmapped status codes to land in target.
        """
        att = AttributeValidator()
        res = att.validate_attributes(
            validation_name="Work Orders String Attribute FAIL Test",
            source_connector=self.src_excel_conn,
            source_table="Work_Orders",
            target_connector=self.fail_dwh_conn,
            target_table="fact_work_orders",
            primary_key_map={"source": "Work_Order_Number", "target": "work_order_number"},
            column_mappings=[
                {"source": "Order_Status", "target": "order_status", "type": "string"}
            ]
        )
        self.assertEqual(res["status"], "FAIL",
            f"Engine should have caught invalid enum string. Got: {res['status']}")
        self.assertGreater(res["mismatched_cells_count"], 0,
            f"Expected string mismatch > 0, got: {res['mismatched_cells_count']}")

    def test_F05_aggregate_fail_zeroed_costs(self):
        """
        [FAIL] Aggregate reconciliation must FAIL when 10 cost records are zeroed out.

        Real-world ETL scenario: A NULL-handling bug in the transformation
        layer replaced NULL source values with zero instead of carrying
        them forward, causing SUM-level drift.
        """
        agg = AggregateValidator()
        res = agg.validate_aggregates(
            test_name="Cost Financials Aggregate FAIL Test",
            source_connector=self.src_excel_conn,
            source_table="Cost_Records",
            target_connector=self.fail_dwh_conn,
            target_table="fact_cost_financials",
            metrics=[
                {"source_col": "Material_Cost_USD",    "target_col": "material_cost_usd",    "agg": "sum", "atol": 0.01},
                {"source_col": "Labor_Cost_USD",       "target_col": "labor_cost_usd",       "agg": "sum", "atol": 0.01},
                {"source_col": "Total_Unit_Cost_USD",  "target_col": "total_unit_cost_usd",  "agg": "avg", "atol": 0.01}
            ]
        )
        self.assertEqual(res["status"], "FAIL",
            f"Engine should have caught zeroed cost aggregates. Got: {res['status']}")
        self.assertGreater(res["failed_metrics"], 0,
            f"Expected failed_metrics > 0, got: {res['failed_metrics']}")

    def test_F06_multi_source_fail_cross_system(self):
        """
        [FAIL] Multi-source consistency must FAIL when Relational source
        is compared to the corrupted DWH (numeric & volume mismatches).

        Real-world ETL scenario: DWH was refreshed from wrong snapshot.
        Cross-system consistency check surfaces the drift.
        """
        msc = MultiSourceValidator()
        res = msc.assess_cross_source_consistency(
            assessment_name="Relational vs Corrupted DWH FAIL Test",
            source1_connector=self.src_excel_conn,
            source1_table="Work_Orders",
            source1_key="Work_Order_Number",
            source2_connector=self.fail_dwh_conn,
            source2_table="fact_work_orders",
            source2_key="work_order_number",
            columns_to_compare=[
                {"s1": "Planned_Quantity",  "s2": "planned_quantity"},
                {"s1": "Scrap_Quantity",    "s2": "scrap_quantity"}
            ]
        )
        self.assertEqual(res["status"], "FAIL",
            f"Engine should have caught cross-system drift. Got: {res['status']}")
        fail_comparisons = [c for c in res["column_comparisons"] if c["status"] == "FAIL"]
        self.assertGreater(len(fail_comparisons), 0,
            f"Expected at least 1 column-level FAIL, got: {fail_comparisons}")

    def test_F07_business_rule_fail_negative_scrap(self):
        """
        [FAIL] Business logic rule validation must FAIL when scrap_quantity < 0.

        Real-world ETL scenario: A sign inversion bug in the ETL transformation
        produced negative scrap quantities which are physically impossible.
        Such values can cause incorrect KPI reporting (negative yield loss).
        """
        msc = MultiSourceValidator()
        res = msc.validate_business_logic_expression(
            rule_name="No Negative Scrap Quantity",
            connector=self.fail_dwh_conn,
            table_name="fact_work_orders",
            expression_check="scrap_quantity >= 0",
            description="Scrap quantity cannot be negative — physical impossibility."
        )
        self.assertEqual(res["status"], "FAIL",
            f"Engine should have caught negative scrap_quantity. Got: {res['status']}")
        self.assertGreater(res["violations_count"], 0,
            f"Expected violations_count > 0, got: {res['violations_count']}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
