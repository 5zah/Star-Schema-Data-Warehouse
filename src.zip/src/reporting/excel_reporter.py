"""
Multi-Tab Styled Excel Reconciliation Report Generator.
"""
import os
from typing import Any, Dict
import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


class ExcelReporter:
    """Generates formatted Excel Mismatch & Reconciliation Workbook."""

    def __init__(self, results: Dict[str, Any]):
        self.results = results

    def generate_excel(self, output_path: str = "reports/Reconciliation_Report.xlsx") -> str:
        """Generates multi-tab formatted Excel workbook."""
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

        wb = openpyxl.Workbook()
        wb.remove(wb.active)  # Remove default sheet

        # Styles
        header_fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
        header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
        pass_fill = PatternFill(start_color="D1FAE5", end_color="D1FAE5", fill_type="solid")
        pass_font = Font(name="Segoe UI", size=10, bold=True, color="065F46")
        fail_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
        fail_font = Font(name="Segoe UI", size=10, bold=True, color="991B1B")

        # Tab 1: Executive Summary
        ws_sum = wb.create_sheet(title="Executive_Summary")
        ws_sum.append(["Enterprise Reconciliation & Validation Executive Summary"])
        ws_sum.append(["Generated Timestamp", self.results.get("timestamp", "")])
        ws_sum.append(["Overall Status", self.results.get("overall_status", "")])
        ws_sum.append(["Pass Rate (%)", f"{self.results.get('pass_rate_percent', 100.0)}%"])
        ws_sum.append(["Total Validations", self.results.get("total_tests", 0)])
        ws_sum.append(["Passed Validations", self.results.get("passed_tests", 0)])
        ws_sum.append(["Failed Validations", self.results.get("failed_tests", 0)])
        ws_sum.append(["Execution Time (s)", f"{self.results.get('elapsed_seconds', 0.0)}s"])

        # Tab 2: Volume Reconciliation
        ws_vol = wb.create_sheet(title="Volume_Reconciliation")
        ws_vol.append(["Validation Suite", "Source Table", "Target Table", "Source Rows", "Target Rows", "Delta", "Delta %", "Missing Keys", "Status"])
        for v in self.results.get("volume_reconciliation", []):
            ws_vol.append([
                v["rule_name"], v["source_table"], v["target_table"],
                v["source_count"], v["target_count"], v["diff"],
                v["diff_percent"], v["missing_in_target_count"], v["status"]
            ])

        # Tab 3: Attribute Cell Validation
        ws_att = wb.create_sheet(title="Attribute_Validation")
        ws_att.append(["Validation Name", "Source Table", "Target Table", "Rows Compared", "Columns Checked", "Total Cells Checked", "Mismatched Cells", "Match %", "Status"])
        for a in self.results.get("attribute_reconciliation", []):
            ws_att.append([
                a["validation_name"], a["source_table"], a["target_table"],
                a["rows_compared"], a["columns_checked"], a["total_cells_checked"],
                a["mismatched_cells_count"], a["match_percent"], a["status"]
            ])

        # Tab 4: Aggregate Measures
        ws_agg = wb.create_sheet(title="Aggregate_Measures")
        ws_agg.append(["Test Suite", "Metric", "Source Value", "Target Value", "Delta", "Delta %", "Tolerance", "Status"])
        for suite in self.results.get("aggregate_reconciliation", []):
            for m in suite.get("results", []):
                ws_agg.append([
                    suite["test_name"], m["metric_name"], m["source_value"],
                    m["target_value"], m["diff"], m["diff_percent"],
                    m["tolerance"], m["status"]
                ])

        # Tab 5: Multi-Source Consistency
        ws_msc = wb.create_sheet(title="Multi_Source_Consistency")
        ws_msc.append(["Rule Name", "Source 1", "Source 2", "Records Audited", "Discrepancy / Violations", "Compliance %", "Status"])
        for m in self.results.get("multi_source_consistency", []):
            ws_msc.append([
                m.get("assessment_name", m.get("rule_name")),
                m.get("source1_table", "N/A"),
                m.get("source2_table", m.get("table_name", "N/A")),
                m.get("common_records_checked", m.get("total_records", 0)),
                sum(c["mismatch_count"] for c in m.get("column_comparisons", [])) if "column_comparisons" in m else m.get("violations_count", 0),
                m.get("compliance_percent", 100.0),
                m.get("status")
            ])

        # Format all sheets
        for sheet in wb.worksheets:
            if sheet.title == "Executive_Summary":
                sheet.column_dimensions["A"].width = 25
                sheet.column_dimensions["B"].width = 35
                continue

            for col_idx in range(1, sheet.max_column + 1):
                cell = sheet.cell(row=1, column=col_idx)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", vertical="center")
                sheet.row_dimensions[1].height = 24

            for row_idx in range(2, sheet.max_row + 1):
                sheet.row_dimensions[row_idx].height = 20
                for col_idx in range(1, sheet.max_column + 1):
                    c = sheet.cell(row=row_idx, column=col_idx)
                    val = str(c.value or "")
                    if val == "PASS":
                        c.fill = pass_fill
                        c.font = pass_font
                    elif val in ["FAIL", "WARNING"]:
                        c.fill = fail_fill
                        c.font = fail_font

            # Auto-fit column widths
            for col in sheet.columns:
                max_len = max(len(str(cell.value or "")) for cell in col)
                col_letter = get_column_letter(col[0].column)
                sheet.column_dimensions[col_letter].width = max(max_len + 4, 12)

        wb.save(output_path)
        print(f"📗 Formatted Multi-Tab Excel Report generated at: {output_path}")
        return output_path
