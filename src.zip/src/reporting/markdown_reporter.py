"""
Markdown Reconciliation Summary Report Generator.
"""
import os
from typing import Any, Dict


class MarkdownReporter:
    """Generates an executive markdown report suitable for CI/CD and pull requests."""

    def __init__(self, results: Dict[str, Any]):
        self.results = results

    def generate_markdown(self, output_path: str = "reports/Reconciliation_Summary.md") -> str:
        """Generates markdown file and saves to output_path."""
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

        overall_status = self.results.get("overall_status", "PASS")
        pass_rate = self.results.get("pass_rate_percent", 100.0)
        passed_tests = self.results.get("passed_tests", 0)
        failed_tests = self.results.get("failed_tests", 0)
        total_tests = self.results.get("total_tests", 0)
        elapsed_sec = self.results.get("elapsed_seconds", 0.0)
        timestamp = self.results.get("timestamp", "")

        vol_results = self.results.get("volume_reconciliation", [])
        att_results = self.results.get("attribute_reconciliation", [])
        agg_results = self.results.get("aggregate_reconciliation", [])
        msc_results = self.results.get("multi_source_consistency", [])

        md = f"""# 🏭 Enterprise ETL Reconciliation & Validation Executive Summary

> **Overall Status:** `{'✅ PASS' if overall_status == 'PASS' else '❌ FAIL'}` | **Pass Rate:** `{pass_rate}%` ({passed_tests}/{total_tests}) | **Runtime:** `{elapsed_sec}s` | **Date:** `{timestamp}`

---

## 1. 📊 Executive Scorecard

| Metric | Value | Target | Status |
| :--- | :--- | :--- | :--- |
| **Total Test Suites** | {total_tests} | 100% Executed | {'✅ PASS' if total_tests > 0 else '❌ FAIL'} |
| **Volume Suites Passed** | {sum(1 for r in vol_results if r['status'] == 'PASS')}/{len(vol_results)} | 100% | {'✅ PASS' if all(r['status'] == 'PASS' for r in vol_results) else '❌ FAIL'} |
| **Attribute Suites Passed** | {sum(1 for r in att_results if r['status'] == 'PASS')}/{len(att_results)} | 100% | {'✅ PASS' if all(r['status'] == 'PASS' for r in att_results) else '❌ FAIL'} |
| **Aggregate Measures Passed** | {sum(1 for r in agg_results if r['status'] == 'PASS')}/{len(agg_results)} | 100% | {'✅ PASS' if all(r['status'] == 'PASS' for r in agg_results) else '❌ FAIL'} |
| **Multi-Source Consistency** | {sum(1 for r in msc_results if r['status'] == 'PASS')}/{len(msc_results)} | 100% | {'✅ PASS' if all(r['status'] == 'PASS' for r in msc_results) else '❌ FAIL'} |

---

## 2. 📦 Data Volume Reconciliation

| Validation Suite | Source Table | Target Table | Source Count | Target Count | Delta | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
"""
        for v in vol_results:
            md += f"| {v['rule_name']} | `{v['source_table']}` | `{v['target_table']}` | {v['source_count']:,} | {v['target_count']:,} | {v['diff']} | `{'✅ PASS' if v['status'] == 'PASS' else '❌ FAIL'}` |\n"

        md += """
---

## 3. 🔬 Attribute-Level & Cell Reconciliation

| Validation Test | Source vs Target | Rows Checked | Columns Checked | Total Cells Checked | Mismatches | Match % | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
"""
        for a in att_results:
            md += f"| {a['validation_name']} | `{a['source_table']}` &rarr; `{a['target_table']}` | {a['rows_compared']:,} | {a['columns_checked']} | {a['total_cells_checked']:,} | {a['mismatched_cells_count']} | **{a['match_percent']}%** | `{'✅ PASS' if a['status'] == 'PASS' else '❌ FAIL'}` |\n"

        md += """
---

## 4. 📈 Aggregate Measure Reconciliation

| Test Suite | Metric | Source Value | Target Value | Delta | Delta % | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
"""
        for suite in agg_results:
            for m in suite.get("results", []):
                md += f"| {suite['test_name']} | `{m['metric_name']}` | {m['source_value']:,} | {m['target_value']:,} | {m['diff']:,} | {m['diff_percent']}% | `{'✅ PASS' if m['status'] == 'PASS' else '❌ FAIL'}` |\n"

        md += """
---

## 5. 🌐 Multi-Source Consistency Assessment

| Assessment Rule | Sources / Target | Records Audited | Discrepancies | Compliance % | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
"""
        for m in msc_results:
            violations = sum(c["mismatch_count"] for c in m.get("column_comparisons", [])) if "column_comparisons" in m else m.get("violations_count", 0)
            md += f"| {m.get('assessment_name', m.get('rule_name'))} | `{m.get('source1_table', '')}` vs `{m.get('source2_table', m.get('table_name', ''))}` | {m.get('common_records_checked', m.get('total_records', 0)):,} | {violations} | {m.get('compliance_percent', 100.0)}% | `{'✅ PASS' if m['status'] == 'PASS' else '❌ FAIL'}` |\n"

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(md)

        print(f"📝 Executive Markdown Report generated at: {output_path}")
        return output_path
