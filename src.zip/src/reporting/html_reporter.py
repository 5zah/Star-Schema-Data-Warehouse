"""
Interactive HTML Reconciliation Report Generator.
Renders an enterprise dashboard with glassmorphism styling, KPI scorecards,
interactive charts, and filterable mismatch drill-down tables.
"""
import json
import os
from typing import Any, Dict


class HTMLReporter:
    """Generates a standalone, rich HTML Reconciliation Dashboard."""

    def __init__(self, results: Dict[str, Any]):
        self.results = results

    def generate_html(self, output_path: str = "reports/Reconciliation_Report.html") -> str:
        """Renders the HTML report and writes it to output_path."""
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

        overall_status = self.results.get("overall_status", "PASS")
        pass_rate = self.results.get("pass_rate_percent", 100.0)
        passed_tests = self.results.get("passed_tests", 0)
        failed_tests = self.results.get("failed_tests", 0)
        total_tests = self.results.get("total_tests", 0)
        elapsed_sec = self.results.get("elapsed_seconds", 0.0)
        timestamp = self.results.get("timestamp", "")

        vol_results = self.results.get("volume_reconciliation", [])
        att_results = self.results.get("attribute_reconciliation", [])
        agg_results = self.results.get("aggregate_reconciliation", [])
        msc_results = self.results.get("multi_source_consistency", [])

        total_cells_checked = sum(a.get("total_cells_checked", 0) for a in att_results)
        total_cell_mismatches = sum(a.get("mismatched_cells_count", 0) for a in att_results)
        cell_match_pct = round(((total_cells_checked - total_cell_mismatches) / total_cells_checked * 100.0), 2) if total_cells_checked > 0 else 100.0

        # Collect all attribute mismatch samples
        all_mismatch_samples = []
        for a in att_results:
            for s in a.get("mismatch_sample", []):
                all_mismatch_samples.append({
                    "test": a.get("validation_name"),
                    "key": s.get("key"),
                    "source_column": s.get("source_column"),
                    "target_column": s.get("target_column"),
                    "source_value": str(s.get("source_value")),
                    "target_value": str(s.get("target_value")),
                    "diff": str(s.get("diff")),
                    "status": s.get("status", "FAIL")
                })

        status_badge_class = "badge-pass" if overall_status == "PASS" else "badge-fail"

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise ETL Reconciliation & Validation Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {{
            --bg-base: #0B0F19;
            --bg-surface: rgba(23, 32, 54, 0.75);
            --bg-surface-elevated: rgba(30, 41, 69, 0.85);
            --border-color: rgba(255, 255, 255, 0.08);
            --accent-primary: #6366F1;
            --accent-primary-hover: #4F46E5;
            --accent-cyan: #06B6D4;
            --accent-success: #10B981;
            --accent-warning: #F59E0B;
            --accent-danger: #EF4444;
            --text-main: #F9FAFB;
            --text-secondary: #9CA3AF;
            --text-muted: #6B7280;
        }}

        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }}

        body {{
            background-color: var(--bg-base);
            color: var(--text-main);
            padding: 2rem;
            min-height: 100vh;
        }}

        .container {{
            max-width: 1440px;
            margin: 0 auto;
        }}

        /* Header */
        .header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem 2rem;
            background: var(--bg-surface);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            margin-bottom: 2rem;
        }}

        .header h1 {{
            font-size: 1.75rem;
            font-weight: 800;
            background: linear-gradient(135deg, #A5B4FC, #6366F1, #06B6D4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}

        .header .meta {{
            color: var(--text-secondary);
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }}

        /* Badges */
        .badge {{
            padding: 0.4rem 1rem;
            border-radius: 9999px;
            font-weight: 700;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }}

        .badge-pass {{
            background: rgba(16, 185, 129, 0.15);
            color: #34D399;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }}

        .badge-fail {{
            background: rgba(239, 68, 68, 0.15);
            color: #F87171;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }}

        .badge-warning {{
            background: rgba(245, 158, 11, 0.15);
            color: #FBBF24;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }}

        /* KPI Grid */
        .kpi-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }}

        .kpi-card {{
            background: var(--bg-surface);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s ease, border-color 0.2s ease;
        }}

        .kpi-card:hover {{
            transform: translateY(-2px);
            border-color: rgba(99, 102, 241, 0.4);
        }}

        .kpi-card .label {{
            font-size: 0.8rem;
            color: var(--text-secondary);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
        }}

        .kpi-card .value {{
            font-size: 1.85rem;
            font-weight: 800;
            color: var(--text-main);
        }}

        .kpi-card .subtext {{
            font-size: 0.75rem;
            color: var(--text-muted);
            margin-top: 0.35rem;
        }}

        /* Navigation Tabs */
        .nav-tabs {{
            display: flex;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 0.75rem;
        }}

        .tab-btn {{
            background: transparent;
            border: none;
            color: var(--text-secondary);
            font-size: 0.95rem;
            font-weight: 600;
            padding: 0.6rem 1.2rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
        }}

        .tab-btn:hover {{
            color: var(--text-main);
            background: rgba(255, 255, 255, 0.05);
        }}

        .tab-btn.active {{
            color: #FFFFFF;
            background: var(--accent-primary);
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }}

        /* Tab Content Section */
        .tab-content {{
            display: none;
        }}

        .tab-content.active {{
            display: block;
            animation: fadeIn 0.3s ease;
        }}

        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(6px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}

        /* Cards & Tables */
        .section-card {{
            background: var(--bg-surface);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }}

        .section-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.25rem;
        }}

        .section-title {{
            font-size: 1.15rem;
            font-weight: 700;
            color: var(--text-main);
        }}

        .table-responsive {{
            overflow-x: auto;
        }}

        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 0.875rem;
        }}

        th {{
            background: rgba(255, 255, 255, 0.03);
            color: var(--text-secondary);
            font-weight: 600;
            text-align: left;
            padding: 0.85rem 1rem;
            border-bottom: 1px solid var(--border-color);
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
        }}

        td {{
            padding: 0.85rem 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.04);
            color: var(--text-main);
        }}

        tr:hover td {{
            background: rgba(255, 255, 255, 0.02);
        }}

        /* Charts Grid */
        .charts-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }}

        .chart-box {{
            background: var(--bg-surface);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            height: 320px;
        }}

        /* Search input */
        .search-input {{
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-main);
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            outline: none;
            width: 250px;
        }}

        .search-input:focus {{
            border-color: var(--accent-primary);
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div>
                <h1>🏭 Enterprise ETL Reconciliation & Validation Report</h1>
                <div class="meta">Target DWH: SQLite (Star Schema) | Generated: {timestamp} | Runtime: {elapsed_sec}s</div>
            </div>
            <div>
                <span class="badge {status_badge_class}">{overall_status}</span>
            </div>
        </div>

        <!-- KPI Summary Cards -->
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="label">Overall Pass Rate</div>
                <div class="value" style="color: {'#34D399' if pass_rate >= 99 else '#F87171'};">{pass_rate}%</div>
                <div class="subtext">{passed_tests} of {total_tests} Suites Passed</div>
            </div>
            <div class="kpi-card">
                <div class="label">Total Validations</div>
                <div class="value">{total_tests}</div>
                <div class="subtext">Across 4 Validation Pillars</div>
            </div>
            <div class="kpi-card">
                <div class="label">Cell Accuracy Rate</div>
                <div class="value" style="color: #06B6D4;">{cell_match_pct}%</div>
                <div class="subtext">{total_cells_checked:,} Cells Audited</div>
            </div>
            <div class="kpi-card">
                <div class="label">Execution Duration</div>
                <div class="value">{elapsed_sec}s</div>
                <div class="subtext">Multi-DB Engine Stream</div>
            </div>
        </div>

        <!-- Navigation Tabs -->
        <div class="nav-tabs">
            <button class="tab-btn active" onclick="switchTab('summary')">📊 Executive Summary</button>
            <button class="tab-btn" onclick="switchTab('volume')">📦 Volume Reconciliation ({len(vol_results)})</button>
            <button class="tab-btn" onclick="switchTab('attribute')">🔬 Attribute Cell Validation ({len(att_results)})</button>
            <button class="tab-btn" onclick="switchTab('aggregate')">📈 Aggregate Measures ({len(agg_results)})</button>
            <button class="tab-btn" onclick="switchTab('multisource')">🌐 Multi-Source Integrity ({len(msc_results)})</button>
            <button class="tab-btn" onclick="switchTab('mismatches')">⚠️ Mismatch Drill-Down ({len(all_mismatch_samples)})</button>
        </div>

        <!-- TAB 1: EXECUTIVE SUMMARY -->
        <div id="tab-summary" class="tab-content active">
            <div class="charts-grid">
                <div class="chart-box">
                    <div class="section-title" style="margin-bottom: 1rem;">Test Execution Distribution</div>
                    <canvas id="statusChart"></canvas>
                </div>
                <div class="chart-box">
                    <div class="section-title" style="margin-bottom: 1rem;">Validation Scope Pass Counts</div>
                    <canvas id="scopeChart"></canvas>
                </div>
            </div>

            <div class="section-card">
                <div class="section-header">
                    <div class="section-title">Data Warehouse Target Summary (Star Schema)</div>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Entity Category</th>
                                <th>Table Name</th>
                                <th>Type</th>
                                <th>Primary Key</th>
                                <th>Key Dimensions / Foreign Keys</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td>Dimension</td><td><strong>dim_date</strong></td><td>Conformed Date</td><td>date_key</td><td>Year, Quarter, Month, Week, Fiscal Period</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_location</strong></td><td>Location Hub</td><td>location_key</td><td>Country, Region, City, Coordinates, Type</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_color</strong></td><td>Finishing / RAL</td><td>color_key</td><td>Color Code, Finish Type, RAL Code</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_plant</strong></td><td>Manufacturing Plant</td><td>plant_key</td><td>Plant Code, ISO Certs, Capacity</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_production_line</strong></td><td>Line Catalog</td><td>line_key</td><td>Line ID, Automation Level, Capacity</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_product</strong></td><td>Item Master</td><td>product_key</td><td>Product SKU, BOM Version, Std Cost</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_machine</strong></td><td>Asset Master</td><td>machine_key</td><td>Machine ID, PLC Version, Criticality</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_operator</strong></td><td>Human Resources</td><td>operator_key</td><td>Operator ID, Labor Rate, Shift</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_supplier</strong></td><td>Vendor Master</td><td>supplier_key</td><td>Supplier ID, Quality Rating, Tier</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_material</strong></td><td>Inventory Items</td><td>material_key</td><td>Material ID, Unit Cost, Recycled %</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_material_sales</strong></td><td>Commercial Material</td><td>material_sales_key</td><td>Sales Code, Target Margin, Standard Price</td></tr>
                            <tr><td>Dimension</td><td><strong>dim_defect_catalog</strong></td><td>Quality Catalog</td><td>defect_key</td><td>Defect Code, Primary & Secondary Type</td></tr>
                            <tr><td>Fact Table</td><td><strong>fact_work_orders</strong></td><td>Production Runs</td><td>work_order_key</td><td>Date, Plant, Line, Product, Color FKs</td></tr>
                            <tr><td>Fact Table</td><td><strong>fact_sales_detail</strong></td><td>Commercial Sales</td><td>sales_detail_key</td><td>Date, Product, Location, Plant, Color FKs</td></tr>
                            <tr><td>Fact Table</td><td><strong>fact_order_detail</strong></td><td>Customer Fulfillment</td><td>order_detail_key</td><td>Date, Product, Line, Location, Color FKs</td></tr>
                            <tr><td>Fact Table</td><td><strong>fact_machine_telemetry</strong></td><td>IoT Readings</td><td>telemetry_key</td><td>Date, Machine, Work Order FKs</td></tr>
                            <tr><td>Fact Table</td><td><strong>fact_quality_inspections</strong></td><td>Quality QA/QC</td><td>quality_fact_key</td><td>Date, Work Order, Product, Defect, Color FKs</td></tr>
                            <tr><td>Fact Table</td><td><strong>fact_labor_performance</strong></td><td>Workforce Efficiency</td><td>labor_fact_key</td><td>Date, Operator, Work Order FKs</td></tr>
                            <tr><td>Fact Table</td><td><strong>fact_cost_financials</strong></td><td>Cost Ledger</td><td>cost_fact_key</td><td>Date, Work Order FKs</td></tr>
                            <tr><td>Fact Table</td><td><strong>fact_procurement</strong></td><td>Purchase Orders</td><td>procurement_key</td><td>Date, Supplier, Material FKs</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- TAB 2: VOLUME RECONCILIATION -->
        <div id="tab-volume" class="tab-content">
            <div class="section-card">
                <div class="section-header">
                    <div class="section-title">Data Volume Reconciliation Matrix</div>
                    <input type="text" class="search-input" placeholder="Search table..." onkeyup="filterTable(this, 'volumeTable')">
                </div>
                <div class="table-responsive">
                    <table id="volumeTable">
                        <thead>
                            <tr>
                                <th>Validation Suite</th>
                                <th>Source Table</th>
                                <th>Target Table</th>
                                <th>Source Rows</th>
                                <th>Target Rows</th>
                                <th>Delta</th>
                                <th>Delta %</th>
                                <th>Missing Keys</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {"".join([f'''
                            <tr>
                                <td><strong>{v['rule_name']}</strong></td>
                                <td>{v['source_table']}</td>
                                <td>{v['target_table']}</td>
                                <td>{v['source_count']:,}</td>
                                <td>{v['target_count']:,}</td>
                                <td>{v['diff']}</td>
                                <td>{v['diff_percent']}%</td>
                                <td>{v['missing_in_target_count']}</td>
                                <td><span class="badge {'badge-pass' if v['status'] == 'PASS' else ('badge-warning' if v['status'] == 'WARNING' else 'badge-fail')}">{v['status']}</span></td>
                            </tr>
                            ''' for v in vol_results])}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- TAB 3: ATTRIBUTE-LEVEL RECONCILIATION -->
        <div id="tab-attribute" class="tab-content">
            <div class="section-card">
                <div class="section-header">
                    <div class="section-title">Attribute-Level & Cell Reconciliation Results</div>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Test Name</th>
                                <th>Source vs Target</th>
                                <th>Rows Compared</th>
                                <th>Columns Checked</th>
                                <th>Total Cells</th>
                                <th>Mismatches</th>
                                <th>Cell Match %</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {"".join([f'''
                            <tr>
                                <td><strong>{a['validation_name']}</strong></td>
                                <td>{a['source_table']} &rarr; {a['target_table']}</td>
                                <td>{a['rows_compared']:,}</td>
                                <td>{a['columns_checked']}</td>
                                <td>{a['total_cells_checked']:,}</td>
                                <td>{a['mismatched_cells_count']}</td>
                                <td><strong>{a['match_percent']}%</strong></td>
                                <td><span class="badge {'badge-pass' if a['status'] == 'PASS' else 'badge-fail'}">{a['status']}</span></td>
                            </tr>
                            ''' for a in att_results])}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- TAB 4: AGGREGATE MEASURES -->
        <div id="tab-aggregate" class="tab-content">
            <div class="section-card">
                <div class="section-header">
                    <div class="section-title">Aggregate Measure Reconciliation</div>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Test Suite</th>
                                <th>Metric</th>
                                <th>Source Value</th>
                                <th>Target Value</th>
                                <th>Delta</th>
                                <th>Delta %</th>
                                <th>Tolerance</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {"".join([
                                "".join([f'''
                                <tr>
                                    <td>{suite['test_name']}</td>
                                    <td><strong>{m['metric_name']}</strong></td>
                                    <td>{m['source_value']:,}</td>
                                    <td>{m['target_value']:,}</td>
                                    <td>{m['diff']:,}</td>
                                    <td>{m['diff_percent']}%</td>
                                    <td>&plusmn;{m['tolerance']}</td>
                                    <td><span class="badge {'badge-pass' if m['status'] == 'PASS' else 'badge-fail'}">{m['status']}</span></td>
                                </tr>
                                ''' for m in suite['results']])
                            for suite in agg_results])}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- TAB 5: MULTI-SOURCE INTEGRITY -->
        <div id="tab-multisource" class="tab-content">
            <div class="section-card">
                <div class="section-header">
                    <div class="section-title">Multi-Source Consistency & Business Rule Validation</div>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Assessment Rule</th>
                                <th>Sources Compared / Target Table</th>
                                <th>Records Audited</th>
                                <th>Violations / Mismatches</th>
                                <th>Compliance %</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {"".join([f'''
                            <tr>
                                <td><strong>{m.get('assessment_name', m.get('rule_name'))}</strong></td>
                                <td>{m.get('source1_table', '')} vs {m.get('source2_table', m.get('table_name', ''))}</td>
                                <td>{m.get('common_records_checked', m.get('total_records', 0)):,}</td>
                                <td>{sum(c['mismatch_count'] for c in m.get('column_comparisons', [])) if 'column_comparisons' in m else m.get('violations_count', 0)}</td>
                                <td>{m.get('compliance_percent', 100.0)}%</td>
                                <td><span class="badge {'badge-pass' if m['status'] == 'PASS' else 'badge-fail'}">{m['status']}</span></td>
                            </tr>
                            ''' for m in msc_results])}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- TAB 6: MISMATCH DRILL-DOWN -->
        <div id="tab-mismatches" class="tab-content">
            <div class="section-card">
                <div class="section-header">
                    <div class="section-title">Detailed Cell Mismatch Catalog ({len(all_mismatch_samples)} Records)</div>
                    <input type="text" class="search-input" placeholder="Search mismatch..." onkeyup="filterTable(this, 'mismatchTable')">
                </div>
                <div class="table-responsive">
                    <table id="mismatchTable">
                        <thead>
                            <tr>
                                <th>Validation Test</th>
                                <th>Record Key</th>
                                <th>Source Column</th>
                                <th>Target Column</th>
                                <th>Source Value</th>
                                <th>Target Value</th>
                                <th>Discrepancy</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {"".join([f'''
                            <tr>
                                <td>{m['test']}</td>
                                <td><code>{m['key']}</code></td>
                                <td>{m['source_column']}</td>
                                <td>{m['target_column']}</td>
                                <td style="color: #F87171;">{m['source_value']}</td>
                                <td style="color: #34D399;">{m['target_value']}</td>
                                <td>{m['diff']}</td>
                                <td><span class="badge badge-fail">FAIL</span></td>
                            </tr>
                            ''' for m in all_mismatch_samples]) if all_mismatch_samples else '<tr><td colspan="8" style="text-align:center; color:#34D399; padding:2rem;">🎉 No Attribute Mismatches Detected! 100% Data Fidelity Achieved.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <script>
        function switchTab(tabId) {{
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));

            event.target.classList.add('active');
            document.getElementById('tab-' + tabId).classList.add('active');
        }}

        function filterTable(input, tableId) {{
            const filter = input.value.toLowerCase();
            const rows = document.querySelectorAll('#' + tableId + ' tbody tr');
            rows.forEach(row => {{
                const text = row.innerText.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            }});
        }}

        // Render Charts
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        new Chart(statusCtx, {{
            type: 'doughnut',
            data: {{
                labels: ['Passed Suites', 'Failed Suites'],
                datasets: [{{
                    data: [{passed_tests}, {failed_tests}],
                    backgroundColor: ['#10B981', '#EF4444'],
                    borderWidth: 0
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{ position: 'bottom', labels: {{ color: '#9CA3AF' }} }}
                }}
            }}
        }});

        const scopeCtx = document.getElementById('scopeChart').getContext('2d');
        new Chart(scopeCtx, {{
            type: 'bar',
            data: {{
                labels: ['Volume', 'Attribute', 'Aggregate', 'Multi-Source'],
                datasets: [{{
                    label: 'Passed',
                    data: [
                        {sum(1 for r in vol_results if r['status'] == 'PASS')},
                        {sum(1 for r in att_results if r['status'] == 'PASS')},
                        {sum(1 for r in agg_results if r['status'] == 'PASS')},
                        {sum(1 for r in msc_results if r['status'] == 'PASS')}
                    ],
                    backgroundColor: '#6366F1'
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{ display: false }}
                }},
                scales: {{
                    y: {{ grid: {{ color: 'rgba(255,255,255,0.05)' }}, ticks: {{ color: '#9CA3AF' }} }},
                    x: {{ grid: {{ display: false }}, ticks: {{ color: '#9CA3AF' }} }}
                }}
            }}
        }});
    </script>
</body>
</html>"""

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html_content)

        print(f"📊 Interactive HTML Report generated at: {output_path}")
        return output_path
