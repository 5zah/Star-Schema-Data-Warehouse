"""
SQLAlchemy Connector supporting multiple databases:
SQLite, PostgreSQL, MySQL, DuckDB, SQL Server, Oracle, Snowflake, etc.
"""
from typing import Any, Dict, List, Optional
import sqlalchemy as sa
from sqlalchemy import text
import pandas as pd
from .base import BaseConnector


class SQLAlchemyConnector(BaseConnector):
    """Universal SQL Database Connector using SQLAlchemy."""

    def __init__(self, name: str, connection_string: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(name, config)
        self.connection_string = connection_string
        self.engine = None
        self._connection = None

    def connect(self) -> sa.engine.Engine:
        if self.engine is None:
            self.engine = sa.create_engine(self.connection_string)
        return self.engine

    def disconnect(self) -> None:
        if self.engine:
            self.engine.dispose()
            self.engine = None

    def fetch_dataframe(
        self,
        table_or_query: str,
        columns: Optional[List[str]] = None,
        where_clause: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> pd.DataFrame:
        engine = self.connect()
        clean_target = table_or_query.strip()
        
        # Check if table_or_query is a SELECT query
        if clean_target.upper().startswith("SELECT") or " FROM " in clean_target.upper():
            query = clean_target
        else:
            cols_str = ", ".join([f'"{c}"' for c in columns]) if columns else "*"
            query = f'SELECT {cols_str} FROM "{clean_target}"'
            if where_clause:
                query += f' WHERE {where_clause}'
            if limit:
                query += f' LIMIT {limit}'
        
        with engine.connect() as conn:
            return pd.read_sql(text(query), conn)

    def get_row_count(
        self,
        table_name: str,
        where_clause: Optional[str] = None
    ) -> int:
        engine = self.connect()
        query = f'SELECT COUNT(*) AS cnt FROM "{table_name}"'
        if where_clause:
            query += f' WHERE {where_clause}'
        with engine.connect() as conn:
            result = conn.execute(text(query)).fetchone()
            return int(result[0]) if result else 0

    def get_partition_counts(
        self,
        table_name: str,
        partition_col: str,
        where_clause: Optional[str] = None
    ) -> pd.DataFrame:
        engine = self.connect()
        query = f'SELECT "{partition_col}" AS partition_key, COUNT(*) AS row_count FROM "{table_name}"'
        if where_clause:
            query += f' WHERE {where_clause}'
        query += f' GROUP BY "{partition_col}" ORDER BY "{partition_col}"'
        
        with engine.connect() as conn:
            return pd.read_sql(text(query), conn)

    def get_aggregates(
        self,
        table_name: str,
        metric_configs: List[Dict[str, str]],
        group_by_cols: Optional[List[str]] = None,
        where_clause: Optional[str] = None
    ) -> pd.DataFrame:
        engine = self.connect()
        agg_exprs = []
        for m in metric_configs:
            col = m.get("col") or m.get("source_col") or m.get("target_col")
            agg = m.get("agg", "sum").upper()
            alias = m.get("alias", f"{agg.lower()}_{col}")
            if agg == "AVG":
                agg_exprs.append(f'AVG(CAST("{col}" AS REAL)) AS "{alias}"')
            elif agg == "SUM":
                agg_exprs.append(f'SUM(CAST("{col}" AS REAL)) AS "{alias}"')
            elif agg == "COUNT":
                agg_exprs.append(f'COUNT("{col}") AS "{alias}"')
            elif agg == "MIN":
                agg_exprs.append(f'MIN("{col}") AS "{alias}"')
            elif agg == "MAX":
                agg_exprs.append(f'MAX("{col}") AS "{alias}"')
            else:
                agg_exprs.append(f'{agg}("{col}") AS "{alias}"')

        agg_str = ", ".join(agg_exprs)
        if group_by_cols:
            grp_cols_str = ", ".join([f'"{c}"' for c in group_by_cols])
            query = f'SELECT {grp_cols_str}, {agg_str} FROM "{table_name}"'
        else:
            query = f'SELECT {agg_str} FROM "{table_name}"'

        if where_clause:
            query += f' WHERE {where_clause}'

        if group_by_cols:
            query += f' GROUP BY {grp_cols_str}'

        with engine.connect() as conn:
            return pd.read_sql(text(query), conn)

    def get_column_names(self, table_name: str) -> List[str]:
        engine = self.connect()
        inspector = sa.inspect(engine)
        cols = inspector.get_columns(table_name)
        return [c["name"] for c in cols]

    def get_distinct_values(self, table_name: str, column_name: str) -> List[Any]:
        engine = self.connect()
        query = f'SELECT DISTINCT "{column_name}" FROM "{table_name}" WHERE "{column_name}" IS NOT NULL'
        with engine.connect() as conn:
            df = pd.read_sql(text(query), conn)
            return df[column_name].tolist()

    def execute_sql(self, sql_script: str) -> None:
        """Execute raw SQL statements / DDL."""
        engine = self.connect()
        statements = [s.strip() for s in sql_script.split(";") if s.strip()]
        with engine.begin() as conn:
            for stmt in statements:
                conn.execute(text(stmt))

    def write_dataframe(
        self,
        df: pd.DataFrame,
        table_name: str,
        if_exists: str = "append",
        index: bool = False
    ) -> int:
        """Bulk write DataFrame into database table."""
        engine = self.connect()
        df.to_sql(table_name, con=engine, if_exists=if_exists, index=index, chunksize=1000)
        return len(df)
