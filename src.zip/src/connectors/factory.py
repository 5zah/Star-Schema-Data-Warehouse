"""
Connector Factory to dynamically instantiate the right connector based on configuration.
"""
from typing import Any, Dict
from .base import BaseConnector
from .sqlalchemy_connector import SQLAlchemyConnector
from .excel_connector import ExcelConnector
from .csv_connector import CSVConnector


class ConnectorFactory:
    """Factory class for creating database and file connectors."""

    @staticmethod
    def create_connector(name: str, config: Dict[str, Any]) -> BaseConnector:
        conn_type = config.get("type", "").lower()
        
        if conn_type in ["sqlalchemy", "sql", "sqlite", "postgres", "postgresql", "mysql", "duckdb", "snowflake", "oracle"]:
            conn_str = config.get("connection_string") or config.get("url") or config.get("uri")
            if not conn_str:
                if conn_type == "sqlite":
                    path = config.get("filepath", ":memory:")
                    conn_str = f"sqlite:///{path}"
                else:
                    raise ValueError(f"Missing 'connection_string' for SQLAlchemy connector '{name}'")
            return SQLAlchemyConnector(name=name, connection_string=conn_str, config=config)
            
        elif conn_type in ["excel", "xlsx", "xls"]:
            filepath = config.get("filepath")
            if not filepath:
                raise ValueError(f"Missing 'filepath' for Excel connector '{name}'")
            return ExcelConnector(name=name, filepath=filepath, config=config)
            
        elif conn_type in ["csv", "file", "parquet", "tsv"]:
            base_path = config.get("filepath") or config.get("base_path")
            if not base_path:
                raise ValueError(f"Missing 'filepath' for CSV connector '{name}'")
            return CSVConnector(name=name, base_path=base_path, config=config)
            
        else:
            raise ValueError(f"Unsupported connector type '{conn_type}' for connector '{name}'")
