"""
Abstract Base Connector for multi-source/multi-target database access.
Provides a unified interface across SQLite, PostgreSQL, MySQL, DuckDB, Snowflake, Excel, CSV, etc.
"""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union
import pandas as pd


class BaseConnector(ABC):
    """Abstract Base Class for all data source and target connectors."""

    def __init__(self, name: str, config: Optional[Dict[str, Any]] = None):
        self.name = name
        self.config = config or {}

    @abstractmethod
    def connect(self) -> Any:
        """Establish connection to data store."""
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Close connection to data store."""
        pass

    @abstractmethod
    def fetch_dataframe(
        self,
        table_or_query: str,
        columns: Optional[List[str]] = None,
        where_clause: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> pd.DataFrame:
        """
        Fetch data as a pandas DataFrame.
        table_or_query can be a table name, sheet name, or a raw SQL query.
        """
        pass

    @abstractmethod
    def get_row_count(
        self,
        table_name: str,
        where_clause: Optional[str] = None
    ) -> int:
        """Return total row count for a given table or query."""
        pass

    @abstractmethod
    def get_partition_counts(
        self,
        table_name: str,
        partition_col: str,
        where_clause: Optional[str] = None
    ) -> pd.DataFrame:
        """Return row counts grouped by partition_col."""
        pass

    @abstractmethod
    def get_aggregates(
        self,
        table_name: str,
        metric_configs: List[Dict[str, str]],
        group_by_cols: Optional[List[str]] = None,
        where_clause: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Compute aggregates (SUM, AVG, MIN, MAX, STDDEV, COUNT) on columns.
        metric_configs format: [{"col": "Quantity", "agg": "sum", "alias": "total_qty"}]
        """
        pass

    @abstractmethod
    def get_column_names(self, table_name: str) -> List[str]:
        """Return list of column names in the table."""
        pass

    @abstractmethod
    def get_distinct_values(self, table_name: str, column_name: str) -> List[Any]:
        """Return list of distinct values for a given column."""
        pass

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()
