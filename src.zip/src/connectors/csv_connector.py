"""
CSV / File connector for tabular flat files.
"""
import os
from typing import Any, Dict, List, Optional
import pandas as pd
from .base import BaseConnector


class CSVConnector(BaseConnector):
    """Connector for CSV / TSV / Parquet files in a directory or direct file."""

    def __init__(self, name: str, base_path: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(name, config)
        self.base_path = base_path
        self._cache: Dict[str, pd.DataFrame] = {}

    def connect(self) -> None:
        if not os.path.exists(self.base_path):
            raise FileNotFoundError(f"Path not found: {self.base_path}")

    def disconnect(self) -> None:
        self._cache.clear()

    def _resolve_file(self, table_name: str) -> str:
        if os.path.isfile(self.base_path):
            return self.base_path
        for ext in [".csv", ".tsv", ".parquet"]:
            candidate = os.path.join(self.base_path, f"{table_name}{ext}")
            if os.path.exists(candidate):
                return candidate
        raise FileNotFoundError(f"Could not find file for table '{table_name}' in {self.base_path}")

    def _load_data(self, table_name: str) -> pd.DataFrame:
        if table_name not in self._cache:
            file_path = self._resolve_file(table_name)
            if file_path.endswith(".csv"):
                df = pd.read_csv(file_path)
            elif file_path.endswith(".tsv"):
                df = pd.read_csv(file_path, sep="\t")
            elif file_path.endswith(".parquet"):
                df = pd.read_parquet(file_path)
            else:
                df = pd.read_csv(file_path)
            self._cache[table_name] = df
        return self._cache[table_name]

    def fetch_dataframe(
        self,
        table_or_query: str,
        columns: Optional[List[str]] = None,
        where_clause: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> pd.DataFrame:
        df = self._load_data(table_or_query)
        if columns:
            existing_cols = [c for c in columns if c in df.columns]
            df = df[existing_cols].copy()
        else:
            df = df.copy()

        if where_clause:
            try:
                df = df.query(where_clause)
            except Exception:
                pass

        if limit:
            df = df.head(limit)

        return df

    def get_row_count(self, table_name: str, where_clause: Optional[str] = None) -> int:
        df = self.fetch_dataframe(table_name, where_clause=where_clause)
        return len(df)

    def get_partition_counts(self, table_name: str, partition_col: str, where_clause: Optional[str] = None) -> pd.DataFrame:
        df = self.fetch_dataframe(table_name, columns=[partition_col], where_clause=where_clause)
        counts = df.groupby(partition_col).size().reset_index(name='row_count')
        counts = counts.rename(columns={partition_col: 'partition_key'})
        return counts.sort_values(by='partition_key')

    def get_aggregates(
        self,
        table_name: str,
        metric_configs: List[Dict[str, str]],
        group_by_cols: Optional[List[str]] = None,
        where_clause: Optional[str] = None
    ) -> pd.DataFrame:
        df = self.fetch_dataframe(table_name, where_clause=where_clause)
        result_dict: Dict[str, Any] = {}
        for m in metric_configs:
            col = m.get("col") or m.get("source_col") or m.get("target_col")
            agg = m.get("agg", "sum").lower()
            alias = m.get("alias", f"{agg}_{col}")
            if col not in df.columns:
                continue
            series = pd.to_numeric(df[col], errors='coerce')
            if agg == "sum":
                result_dict[alias] = float(series.sum())
            elif agg in ["avg", "mean"]:
                result_dict[alias] = float(series.mean())
            elif agg == "min":
                result_dict[alias] = float(series.min())
            elif agg == "max":
                result_dict[alias] = float(series.max())
            elif agg in ["std", "stddev"]:
                result_dict[alias] = float(series.std())
            elif agg == "count":
                result_dict[alias] = int(series.count())
        return pd.DataFrame([result_dict])

    def get_column_names(self, table_name: str) -> List[str]:
        df = self._load_data(table_name)
        return list(df.columns)

    def get_distinct_values(self, table_name: str, column_name: str) -> List[Any]:
        df = self._load_data(table_name)
        if column_name in df.columns:
            return df[column_name].dropna().unique().tolist()
        return []
