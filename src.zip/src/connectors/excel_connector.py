"""
Excel Connector supporting workbook inspection, sheet-as-table abstraction,
caching, row counts, partition counts, and pandas aggregations.
"""
import os
from typing import Any, Dict, List, Optional
import pandas as pd
import openpyxl
from .base import BaseConnector


class ExcelConnector(BaseConnector):
    """Connector for Excel files (.xlsx, .xls) treating sheets as relational tables."""

    def __init__(self, name: str, filepath: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(name, config)
        self.filepath = filepath
        self._cache: Dict[str, pd.DataFrame] = {}
        self._sheet_names: Optional[List[str]] = None

    def connect(self) -> None:
        if not os.path.exists(self.filepath):
            raise FileNotFoundError(f"Excel file not found: {self.filepath}")

    def disconnect(self) -> None:
        self._cache.clear()

    def get_sheet_names(self) -> List[str]:
        if self._sheet_names is None:
            wb = openpyxl.load_workbook(self.filepath, read_only=True)
            self._sheet_names = wb.sheetnames
            wb.close()
        return self._sheet_names

    def _load_sheet(self, sheet_name: str) -> pd.DataFrame:
        if sheet_name not in self._cache:
            df = pd.read_excel(self.filepath, sheet_name=sheet_name)
            self._cache[sheet_name] = df
        return self._cache[sheet_name]

    def fetch_dataframe(
        self,
        table_or_query: str,
        columns: Optional[List[str]] = None,
        where_clause: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> pd.DataFrame:
        sheet_name = table_or_query
        df = self._load_sheet(sheet_name)
        
        # Apply columns filter
        if columns:
            existing_cols = [c for c in columns if c in df.columns]
            df = df[existing_cols].copy()
        else:
            df = df.copy()

        # Apply where_clause query if provided
        if where_clause:
            try:
                df = df.query(where_clause)
            except Exception:
                # If pandas query fails on complex SQL syntax, pass
                pass

        if limit:
            df = df.head(limit)

        return df

    def get_row_count(
        self,
        table_name: str,
        where_clause: Optional[str] = None
    ) -> int:
        df = self.fetch_dataframe(table_name, where_clause=where_clause)
        return len(df)

    def get_partition_counts(
        self,
        table_name: str,
        partition_col: str,
        where_clause: Optional[str] = None
    ) -> pd.DataFrame:
        df = self.fetch_dataframe(table_name, columns=[partition_col], where_clause=where_clause)
        counts = df.groupby(partition_col).size().reset_index(name='row_count')
        counts = counts.rename(columns={partition_col: 'partition_key'})
        return counts.sort_values(by='partition_key')

    def get_aggregates(
        self,
        table_name: str,
        metric_configs: List[Dict[str, str]],
        group_by_cols: Optional[List[str]] = None,
        where_clause: Optional[str] = None
    ) -> pd.DataFrame:
        df = self.fetch_dataframe(table_name, where_clause=where_clause)
        
        result_dict: Dict[str, Any] = {}
        for m in metric_configs:
            col = m.get("col") or m.get("source_col") or m.get("target_col")
            agg = m.get("agg", "sum").lower()
            alias = m.get("alias", f"{agg}_{col}")
            
            if col not in df.columns:
                continue
                
            series = pd.to_numeric(df[col], errors='coerce')
            if agg == "sum":
                result_dict[alias] = float(series.sum())
            elif agg in ["avg", "mean"]:
                result_dict[alias] = float(series.mean())
            elif agg == "min":
                result_dict[alias] = float(series.min())
            elif agg == "max":
                result_dict[alias] = float(series.max())
            elif agg in ["std", "stddev"]:
                result_dict[alias] = float(series.std())
            elif agg == "count":
                result_dict[alias] = int(series.count())

        return pd.DataFrame([result_dict])

    def get_column_names(self, table_name: str) -> List[str]:
        df = self._load_sheet(table_name)
        return list(df.columns)

    def get_distinct_values(self, table_name: str, column_name: str) -> List[Any]:
        df = self._load_sheet(table_name)
        if column_name in df.columns:
            return df[column_name].dropna().unique().tolist()
        return []
