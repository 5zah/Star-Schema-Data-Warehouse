"""
Module 2: Data Reconciliation & Attribute-Level Validator.
Performs 100% cell-by-cell validation with configurable float tolerances,
string normalization, date parsing, and comprehensive mismatch record extraction.
"""
from typing import Any, Dict, List, Optional, Tuple
import math
import pandas as pd
import numpy as np
from .mapper import DynamicMapper
from ..connectors.base import BaseConnector


class AttributeValidator:
    """Validates cell-level data accuracy and attribute fidelity between source and target."""

    def __init__(self, global_config: Optional[Dict[str, Any]] = None):
        self.config = global_config or {}
        self.default_atol = self.config.get("default_float_atol", 0.01)
        self.default_rtol = self.config.get("default_float_rtol", 0.001)
        self.max_display = self.config.get("max_mismatch_display", 50)
        self.ignore_case = self.config.get("ignore_case_strings", True)
        self.trim_strings = self.config.get("trim_strings", True)

    def validate_attributes(
        self,
        validation_name: str,
        source_connector: BaseConnector,
        source_table: str,
        target_connector: BaseConnector,
        target_table: str,
        primary_key_map: Dict[str, str],     # {"source": "Work_Order_Number", "target": "work_order_number"}
        column_mappings: Optional[List[Dict[str, Any]]] = None,
        sample_limit: Optional[int] = None,
        where_clause: Optional[str] = None
    ) -> Dict[str, Any]:
        """Runs cell-by-cell comparison on mapped columns."""
        src_pk = primary_key_map["source"]
        tgt_pk = primary_key_map["target"]

        # If column mappings not provided, auto-infer from schema
        if not column_mappings:
            src_cols = source_connector.get_column_names(source_table)
            tgt_cols = target_connector.get_column_names(target_table)
            column_mappings = DynamicMapper.auto_infer_mappings(src_cols, tgt_cols)

        # Build fetch column lists
        src_fetch_cols = list({src_pk} | {m["source"] for m in column_mappings})
        tgt_fetch_cols = list({tgt_pk} | {m["target"] for m in column_mappings})

        # Fetch DataFrames
        df_src = source_connector.fetch_dataframe(source_table, columns=src_fetch_cols, where_clause=where_clause, limit=sample_limit)
        df_tgt = target_connector.fetch_dataframe(target_table, columns=tgt_fetch_cols, where_clause=where_clause, limit=sample_limit)

        # Cast PKs to string for safe join
        df_src["_join_pk"] = df_src[src_pk].astype(str).str.strip()
        df_tgt["_join_pk"] = df_tgt[tgt_pk].astype(str).str.strip()

        # Inner join to compare common records
        merged = pd.merge(df_src, df_tgt, on="_join_pk", suffixes=("_src", "_tgt"), how="inner")

        total_rows_compared = len(merged)
        total_columns_compared = len(column_mappings)
        total_cells_checked = total_rows_compared * total_columns_compared

        mismatches: List[Dict[str, Any]] = []
        column_summaries: Dict[str, Dict[str, Any]] = {}

        for mapping in column_mappings:
            s_col = mapping["source"]
            t_col = mapping["target"]
            d_type = mapping.get("type", "auto").lower()
            atol = mapping.get("atol", self.default_atol)
            rtol = mapping.get("rtol", self.default_rtol)

            # Extract joined columns
            s_series_name = f"{s_col}_src" if s_col in df_src.columns and f"{s_col}_src" in merged.columns else s_col
            t_series_name = f"{t_col}_tgt" if t_col in df_tgt.columns and f"{t_col}_tgt" in merged.columns else t_col

            if s_series_name not in merged.columns or t_series_name not in merged.columns:
                continue

            col_mismatch_count = 0

            for _, row in merged.iterrows():
                pk_val = row["_join_pk"]
                s_val = row[s_series_name]
                t_val = row[t_series_name]

                # Check null match
                s_is_null = pd.isnull(s_val) or s_val is None
                t_is_null = pd.isnull(t_val) or t_val is None

                if s_is_null and t_is_null:
                    continue

                if s_is_null != t_is_null:
                    col_mismatch_count += 1
                    if len(mismatches) < self.max_display:
                        mismatches.append({
                            "key": pk_val,
                            "source_column": s_col,
                            "target_column": t_col,
                            "source_value": "NULL" if s_is_null else str(s_val),
                            "target_value": "NULL" if t_is_null else str(t_val),
                            "diff": "Null Mismatch",
                            "status": "FAIL"
                        })
                    continue

                # Auto-detect float vs string
                is_numeric_check = False
                if d_type in ["float", "numeric", "real", "double", "int", "integer"] or (
                    d_type == "auto" and isinstance(s_val, (int, float, np.number)) and isinstance(t_val, (int, float, np.number))
                ):
                    is_numeric_check = True

                if is_numeric_check:
                    try:
                        s_num = float(s_val)
                        t_num = float(t_val)
                        abs_diff = abs(s_num - t_num)
                        
                        # Check against atol and rtol
                        tolerance = atol + (rtol * abs(s_num))
                        if abs_diff > tolerance:
                            col_mismatch_count += 1
                            if len(mismatches) < self.max_display:
                                diff_pct = round((abs_diff / abs(s_num) * 100.0), 4) if s_num != 0 else 100.0
                                mismatches.append({
                                    "key": pk_val,
                                    "source_column": s_col,
                                    "target_column": t_col,
                                    "source_value": s_num,
                                    "target_value": t_num,
                                    "diff": round(abs_diff, 4),
                                    "diff_percent": diff_pct,
                                    "status": "FAIL"
                                })
                    except (ValueError, TypeError):
                        # Fallback to string
                        s_clean = DynamicMapper.cast_and_clean_value(s_val, "string", self.trim_strings, self.ignore_case)
                        t_clean = DynamicMapper.cast_and_clean_value(t_val, "string", self.trim_strings, self.ignore_case)
                        if s_clean != t_clean:
                            col_mismatch_count += 1
                            if len(mismatches) < self.max_display:
                                mismatches.append({
                                    "key": pk_val,
                                    "source_column": s_col,
                                    "target_column": t_col,
                                    "source_value": str(s_val),
                                    "target_value": str(t_val),
                                    "diff": "String Diff",
                                    "status": "FAIL"
                                })
                else:
                    # String or Date Comparison
                    s_clean = DynamicMapper.cast_and_clean_value(s_val, d_type, self.trim_strings, self.ignore_case)
                    t_clean = DynamicMapper.cast_and_clean_value(t_val, d_type, self.trim_strings, self.ignore_case)
                    if s_clean != t_clean:
                        col_mismatch_count += 1
                        if len(mismatches) < self.max_display:
                            mismatches.append({
                                "key": pk_val,
                                "source_column": s_col,
                                "target_column": t_col,
                                "source_value": str(s_val),
                                "target_value": str(t_val),
                                "diff": "Value Diff",
                                "status": "FAIL"
                            })

            col_match_pct = round(((total_rows_compared - col_mismatch_count) / total_rows_compared * 100.0), 2) if total_rows_compared > 0 else 100.0
            column_summaries[s_col] = {
                "source_col": s_col,
                "target_col": t_col,
                "type": d_type,
                "mismatch_count": col_mismatch_count,
                "match_percent": col_match_pct,
                "status": "PASS" if col_mismatch_count == 0 else "FAIL"
            }

        total_mismatched_cells = sum(c["mismatch_count"] for c in column_summaries.values())
        overall_match_pct = round(((total_cells_checked - total_mismatched_cells) / total_cells_checked * 100.0), 2) if total_cells_checked > 0 else 100.0
        status = "PASS" if total_mismatched_cells == 0 else "FAIL"

        return {
            "validation_name": validation_name,
            "source_table": source_table,
            "target_table": target_table,
            "rows_compared": total_rows_compared,
            "columns_checked": total_columns_compared,
            "total_cells_checked": total_cells_checked,
            "mismatched_cells_count": total_mismatched_cells,
            "match_percent": overall_match_pct,
            "status": status,
            "column_summaries": list(column_summaries.values()),
            "mismatch_sample": mismatches
        }
