"""
Module 3: Aggregate Measure Reconciliation Validator.
Compares mathematical aggregations (SUM, AVG, MIN, MAX, STDDEV, COUNT)
across numeric measures, optionally grouped by dimensional business keys.
"""
from typing import Any, Dict, List, Optional
import math
import pandas as pd
from ..connectors.base import BaseConnector


class AggregateValidator:
    """Validates high-level and dimensional aggregated metrics between source and target."""

    def __init__(self, global_config: Optional[Dict[str, Any]] = None):
        self.config = global_config or {}
        self.default_atol = self.config.get("default_float_atol", 0.01)
        self.default_rtol = self.config.get("default_float_rtol", 0.001)

    def validate_aggregates(
        self,
        test_name: str,
        source_connector: BaseConnector,
        source_table: str,
        target_connector: BaseConnector,
        target_table: str,
        metrics: List[Dict[str, Any]],
        group_by_cols: Optional[Dict[str, str]] = None,  # {"source": "Plant_Code", "target": "plant_key"}
        where_clause: Optional[str] = None
    ) -> Dict[str, Any]:
        """Runs aggregate comparison for list of configured metrics."""
        metric_results = []
        overall_status = "PASS"

        # Prepare metric configs for connectors
        src_metric_configs = [{"col": m["source_col"], "agg": m.get("agg", "sum"), "alias": f"{m.get('agg','sum')}_{m['source_col']}"} for m in metrics]
        tgt_metric_configs = [{"col": m["target_col"], "agg": m.get("agg", "sum"), "alias": f"{m.get('agg','sum')}_{m['target_col']}"} for m in metrics]

        # Fetch aggregates from source & target
        src_agg_df = source_connector.get_aggregates(source_table, src_metric_configs, where_clause=where_clause)
        tgt_agg_df = target_connector.get_aggregates(target_table, tgt_metric_configs, where_clause=where_clause)

        for m in metrics:
            s_col = m["source_col"]
            t_col = m["target_col"]
            agg = m.get("agg", "sum").lower()
            atol = m.get("atol", self.default_atol)
            rtol = m.get("rtol", self.default_rtol)

            s_alias = f"{agg}_{s_col}"
            t_alias = f"{agg}_{t_col}"

            s_val = float(src_agg_df[s_alias].iloc[0]) if s_alias in src_agg_df.columns and not src_agg_df.empty and pd.notnull(src_agg_df[s_alias].iloc[0]) else 0.0
            t_val = float(tgt_agg_df[t_alias].iloc[0]) if t_alias in tgt_agg_df.columns and not tgt_agg_df.empty and pd.notnull(tgt_agg_df[t_alias].iloc[0]) else 0.0

            abs_diff = abs(t_val - s_val)
            tolerance = atol + (rtol * abs(s_val))
            diff_pct = round((abs_diff / abs(s_val) * 100.0), 4) if s_val != 0 else (0.0 if t_val == 0 else 100.0)

            metric_status = "PASS" if abs_diff <= tolerance else "FAIL"
            if metric_status == "FAIL":
                overall_status = "FAIL"

            metric_results.append({
                "metric_name": f"{agg.upper()}({s_col})",
                "source_column": s_col,
                "target_column": t_col,
                "aggregation": agg.upper(),
                "source_value": round(s_val, 4),
                "target_value": round(t_val, 4),
                "diff": round(abs_diff, 4),
                "diff_percent": diff_pct,
                "tolerance": round(tolerance, 4),
                "status": metric_status
            })

        return {
            "test_name": test_name,
            "source_table": source_table,
            "target_table": target_table,
            "status": overall_status,
            "metrics_count": len(metric_results),
            "passed_metrics": sum(1 for m in metric_results if m["status"] == "PASS"),
            "failed_metrics": sum(1 for m in metric_results if m["status"] == "FAIL"),
            "results": metric_results
        }
