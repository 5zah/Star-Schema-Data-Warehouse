"""
Enterprise Reconciliation Engine Orchestrator:
Coordinates multi-database connections, executes test suites across all 4 validation scopes,
and compiles comprehensive reconciliation results for automated reporting.
"""
import os
import time
from typing import Any, Dict, List, Optional
import yaml
from ..connectors.factory import ConnectorFactory
from ..connectors.base import BaseConnector
from .volume_validator import VolumeValidator
from .attribute_validator import AttributeValidator
from .aggregate_validator import AggregateValidator
from .multi_source_validator import MultiSourceValidator


class ReconciliationEngine:
    """Master reconciliation orchestrator supporting any source, any target, and dynamic mappings."""

    def __init__(self, config_path: str = "config/reconciliation_config.yaml"):
        self.config_path = config_path
        self.config: Dict[str, Any] = {}
        self.connectors: Dict[str, BaseConnector] = {}
        self.load_config()

    def load_config(self) -> None:
        """Loads reconciliation configuration from YAML file."""
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
        with open(self.config_path, "r", encoding="utf-8") as f:
            self.config = yaml.safe_load(f)

        # Initialize connectors
        db_configs = self.config.get("databases", {})
        for name, cfg in db_configs.items():
            self.connectors[name] = ConnectorFactory.create_connector(name, cfg)

    def get_connector(self, name: str) -> BaseConnector:
        """Retrieves or creates connector by name."""
        if name not in self.connectors:
            raise KeyError(f"Database connector '{name}' not defined in configuration.")
        return self.connectors[name]

    def run_all_validations(self) -> Dict[str, Any]:
        """Runs the entire reconciliation suite across all 4 validation scopes."""
        start_time = time.time()
        print("====================================================================")
        print("[RECONCILE] RUNNING ENTERPRISE RECONCILIATION & VALIDATION ENGINE")
        print("====================================================================")

        global_cfg = self.config.get("global_settings", {})
        
        # 1. Volume Reconciliation
        print("\n[SCOPE 1/4] Running Data Volume Reconciliation...")
        vol_validator = VolumeValidator(global_cfg)
        vol_results = []
        vol_suite = self.config.get("volume_reconciliation", {}).get("table_pairs", [])
        for pair in vol_suite:
            src_conn = self.get_connector(pair["source_db"])
            tgt_conn = self.get_connector(pair["target_db"])
            res = vol_validator.validate_table_pair(
                rule_name=pair["name"],
                source_connector=src_conn,
                source_table=pair["source_table"],
                target_connector=tgt_conn,
                target_table=pair["target_table"],
                key_column=pair["key_column"],
                target_key_column=pair.get("target_key_column"),
                partition_by=pair.get("partition_by"),
                target_partition_by=pair.get("target_partition_by")
            )
            vol_results.append(res)
            status_tag = f"[{res['status']}]"
            print(f"    {status_tag:<8} {res['rule_name']:<35} | Src: {res['source_count']:>5} | Tgt: {res['target_count']:>5}")

        # 2. Attribute-Level Validation
        print("\n[SCOPE 2/4] Running Attribute-Level & Cell Reconciliation...")
        att_validator = AttributeValidator(global_cfg)
        att_results = []
        att_suite = self.config.get("attribute_reconciliation", {}).get("validations", [])
        for v in att_suite:
            src_conn = self.get_connector(v["source_db"])
            tgt_conn = self.get_connector(v["target_db"])
            res = att_validator.validate_attributes(
                validation_name=v["name"],
                source_connector=src_conn,
                source_table=v["source_table"],
                target_connector=tgt_conn,
                target_table=v["target_table"],
                primary_key_map=v["primary_key"],
                column_mappings=v.get("column_mappings")
            )
            att_results.append(res)
            status_tag = f"[{res['status']}]"
            print(f"    {status_tag:<8} {res['validation_name']:<35} | Cells: {res['total_cells_checked']:>6} | Match: {res['match_percent']:>6.2f}%")

        # 3. Aggregate Measure Reconciliation
        print("\n[SCOPE 3/4] Running Aggregate Measure Reconciliation...")
        agg_validator = AggregateValidator(global_cfg)
        agg_results = []
        agg_suite = self.config.get("aggregate_reconciliation", {}).get("tests", [])
        for t in agg_suite:
            src_conn = self.get_connector(t["source_db"])
            tgt_conn = self.get_connector(t["target_db"])
            res = agg_validator.validate_aggregates(
                test_name=t["name"],
                source_connector=src_conn,
                source_table=t["source_table"],
                target_connector=tgt_conn,
                target_table=t["target_table"],
                metrics=t["metrics"]
            )
            agg_results.append(res)
            status_tag = f"[{res['status']}]"
            print(f"    {status_tag:<8} {res['test_name']:<35} | Passed: {res['passed_metrics']}/{res['metrics_count']}")

        # 4. Multi-Source Consistency Assessment
        print("\n[SCOPE 4/4] Running Multi-Source Consistency Assessment...")
        msc_validator = MultiSourceValidator(global_cfg)
        msc_results = []
        msc_suite = self.config.get("multi_source_consistency", {}).get("assessments", [])
        for a in msc_suite:
            if "columns_to_compare" in a:
                src1_conn = self.get_connector(a["source1_db"])
                src2_conn = self.get_connector(a["source2_db"])
                res = msc_validator.assess_cross_source_consistency(
                    assessment_name=a["name"],
                    source1_connector=src1_conn,
                    source1_table=a["source1_table"],
                    source1_key=a["source1_key"],
                    source2_connector=src2_conn,
                    source2_table=a["source2_table"],
                    source2_key=a["source2_key"],
                    columns_to_compare=a["columns_to_compare"]
                )
            elif "expression_check" in a:
                db_conn = self.get_connector(a["db"])
                res = msc_validator.validate_business_logic_expression(
                    rule_name=a["name"],
                    connector=db_conn,
                    table_name=a["table"],
                    expression_check=a["expression_check"],
                    description=a["description"]
                )
            msc_results.append(res)
            status_tag = f"[{res['status']}]"
            title = res.get('assessment_name', res.get('rule_name'))
            print(f"    {status_tag:<8} {title:<45}")

        elapsed_sec = round(time.time() - start_time, 2)

        # Summary KPIs
        total_tests = len(vol_results) + len(att_results) + len(agg_results) + len(msc_results)
        passed_tests = (
            sum(1 for r in vol_results if r["status"] == "PASS") +
            sum(1 for r in att_results if r["status"] == "PASS") +
            sum(1 for r in agg_results if r["status"] == "PASS") +
            sum(1 for r in msc_results if r["status"] == "PASS")
        )
        failed_tests = total_tests - passed_tests
        pass_rate_pct = round((passed_tests / total_tests * 100.0), 2) if total_tests > 0 else 100.0
        overall_status = "PASS" if failed_tests == 0 else "FAIL"

        print("--------------------------------------------------------------------")
        print(f"[SUMMARY] RECONCILIATION: {overall_status} ({passed_tests}/{total_tests} Passed, {pass_rate_pct}%) in {elapsed_sec}s")
        print("====================================================================\n")

        return {
            "overall_status": overall_status,
            "total_tests": total_tests,
            "passed_tests": passed_tests,
            "failed_tests": failed_tests,
            "pass_rate_percent": pass_rate_pct,
            "elapsed_seconds": elapsed_sec,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "volume_reconciliation": vol_results,
            "attribute_reconciliation": att_results,
            "aggregate_reconciliation": agg_results,
            "multi_source_consistency": msc_results
        }
