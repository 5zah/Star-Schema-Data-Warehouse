"""
Module 4: Multi-Source Consistency Assessment Validator.
Performs cross-system reconciliation across Flat Denormalized files,
Normalized Relational databases, and Star Schema Data Warehouses.
"""
from typing import Any, Dict, List, Optional
import numpy as np
import pandas as pd
from ..connectors.base import BaseConnector


class MultiSourceValidator:
    """Validates data consistency across multiple heterogeneous sources and logical constraints."""

    def __init__(self, global_config: Optional[Dict[str, Any]] = None):
        self.config = global_config or {}
        self.atol = self.config.get("default_float_atol", 0.01)
        self.rtol = self.config.get("default_float_rtol", 0.001)

    def assess_cross_source_consistency(
        self,
        assessment_name: str,
        source1_connector: BaseConnector,
        source1_table: str,
        source1_key: str,
        source2_connector: BaseConnector,
        source2_table: str,
        source2_key: str,
        columns_to_compare: List[Any]  # list of strings or {"s1": col1, "s2": col2}
    ) -> Dict[str, Any]:
        """Cross-checks records between two distinct sources (e.g. Flat file vs Relational or DWH)."""
        s1_cols = [source1_key]
        s2_cols = [source2_key]
        normalized_pairs = []

        for c in columns_to_compare:
            if isinstance(c, dict):
                s1_cols.append(c["s1"])
                s2_cols.append(c["s2"])
                normalized_pairs.append((c["s1"], c["s2"]))
            else:
                s1_cols.append(c)
                s2_cols.append(c)
                normalized_pairs.append((c, c))

        df1 = source1_connector.fetch_dataframe(source1_table, columns=list(set(s1_cols)))
        df2 = source2_connector.fetch_dataframe(source2_table, columns=list(set(s2_cols)))

        # Rename columns to avoid collisions
        df1_renamed = df1.rename(columns={source1_key: "_pk"})
        df2_renamed = df2.rename(columns={source2_key: "_pk"})

        df1_renamed["_pk"] = df1_renamed["_pk"].astype(str).str.strip()
        df2_renamed["_pk"] = df2_renamed["_pk"].astype(str).str.strip()

        # Append source tags to distinct column names
        rename_s1 = {c1: f"{c1}_s1" for c1, _ in normalized_pairs if c1 in df1_renamed.columns}
        rename_s2 = {c2: f"{c2}_s2" for _, c2 in normalized_pairs if c2 in df2_renamed.columns}

        df1_clean = df1_renamed.rename(columns=rename_s1)
        df2_clean = df2_renamed.rename(columns=rename_s2)

        merged = pd.merge(df1_clean, df2_clean, on="_pk", how="inner")
        total_common_records = len(merged)

        discrepancies = []
        for c1, c2 in normalized_pairs:
            col1_name = f"{c1}_s1"
            col2_name = f"{c2}_s2"

            if col1_name not in merged.columns or col2_name not in merged.columns:
                continue

            s1_vals = merged[col1_name]
            s2_vals = merged[col2_name]

            # Try numeric comparison
            is_numeric = False
            try:
                s1_num = pd.to_numeric(s1_vals, errors='raise')
                s2_num = pd.to_numeric(s2_vals, errors='raise')
                is_numeric = True
            except Exception:
                is_numeric = False

            if is_numeric:
                diffs = (s1_num - s2_num).abs()
                tolerance = self.atol + (self.rtol * s1_num.abs())
                mismatch_mask = diffs > tolerance
            else:
                mismatch_mask = s1_vals.astype(str).str.strip().str.lower() != s2_vals.astype(str).str.strip().str.lower()

            mismatch_count = int(mismatch_mask.sum())

            discrepancies.append({
                "source1_col": c1,
                "source2_col": c2,
                "mismatch_count": mismatch_count,
                "match_percent": round(((total_common_records - mismatch_count) / total_common_records * 100.0), 2) if total_common_records > 0 else 100.0,
                "status": "PASS" if mismatch_count == 0 else "FAIL"
            })

        total_fails = sum(1 for d in discrepancies if d["status"] == "FAIL")
        status = "PASS" if total_fails == 0 else "FAIL"

        return {
            "assessment_name": assessment_name,
            "source1_table": source1_table,
            "source2_table": source2_table,
            "common_records_checked": total_common_records,
            "columns_compared_count": len(normalized_pairs),
            "status": status,
            "column_comparisons": discrepancies
        }

    def validate_business_logic_expression(
        self,
        rule_name: str,
        connector: BaseConnector,
        table_name: str,
        expression_check: str,
        description: str
    ) -> Dict[str, Any]:
        """Validates mathematical/business integrity constraints on a target table."""
        df = connector.fetch_dataframe(table_name)
        total_rows = len(df)

        try:
            passed_mask = df.eval(expression_check)
            violations_count = int((~passed_mask).sum())
            status = "PASS" if violations_count == 0 else "FAIL"
        except Exception as e:
            violations_count = 0
            status = f"ERROR: {str(e)}"

        return {
            "rule_name": rule_name,
            "table_name": table_name,
            "expression": expression_check,
            "description": description,
            "total_records": total_rows,
            "violations_count": violations_count,
            "compliance_percent": round(((total_rows - violations_count) / total_rows * 100.0), 2) if total_rows > 0 else 100.0,
            "status": status
        }
