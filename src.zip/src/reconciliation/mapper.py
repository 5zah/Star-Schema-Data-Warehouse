"""
Dynamic Schema & Column Mapper for Reconciliation.
Supports explicit column mappings, transformations, type normalization, and auto-mapping.
"""
import re
from typing import Any, Dict, List, Optional, Tuple
import pandas as pd


class DynamicMapper:
    """Handles dynamic mapping rules and auto-inference between source and target datasets."""

    @staticmethod
    def normalize_column_name(col_name: str) -> str:
        """Converts column name to lowercase snake_case standard."""
        s = re.sub(r'[_\s]+', '_', col_name.strip())
        s = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s)
        return s.lower()

    @classmethod
    def auto_infer_mappings(
        cls,
        source_cols: List[str],
        target_cols: List[str]
    ) -> List[Dict[str, Any]]:
        """
        Automatically infers matching columns between source and target
        based on exact match, case-insensitive match, and snake_case match.
        """
        mappings = []
        target_norm_map = {cls.normalize_column_name(c): c for c in target_cols}

        for s_col in source_cols:
            s_norm = cls.normalize_column_name(s_col)
            if s_col in target_cols:
                mappings.append({"source": s_col, "target": s_col, "type": "auto"})
            elif s_norm in target_norm_map:
                mappings.append({"source": s_col, "target": target_norm_map[s_norm], "type": "auto"})

        return mappings

    @staticmethod
    def cast_and_clean_value(val: Any, data_type: str, trim_strings: bool = True, ignore_case: bool = True) -> Any:
        """Standardizes a value according to target data type for reliable comparison."""
        if pd.isnull(val) or val is None:
            return None

        data_type = data_type.lower()
        if data_type in ["float", "numeric", "real", "double"]:
            try:
                return round(float(val), 6)
            except (ValueError, TypeError):
                return str(val)

        elif data_type in ["int", "integer", "bigint"]:
            try:
                return int(round(float(val)))
            except (ValueError, TypeError):
                return str(val)

        elif data_type in ["string", "str", "varchar", "text"]:
            s = str(val)
            if trim_strings:
                s = s.strip()
            if ignore_case:
                s = s.lower()
            return s

        elif data_type in ["date", "datetime", "timestamp"]:
            try:
                dt = pd.to_datetime(val)
                return dt.strftime("%Y-%m-%d")
            except Exception:
                return str(val)

        elif data_type in ["bool", "boolean"]:
            s = str(val).strip().lower()
            if s in ["1", "true", "yes", "y"]:
                return True
            if s in ["0", "false", "no", "n"]:
                return False
            return bool(val)

        # Fallback string
        s = str(val)
        return s.strip() if trim_strings else s
