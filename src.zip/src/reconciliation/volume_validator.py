"""
Module 1: Data Volume Reconciliation Validator.
Validates table row counts, partition-level distributions, and missing business keys.
"""
from typing import Any, Dict, List, Optional
import pandas as pd
from ..connectors.base import BaseConnector


class VolumeValidator:
    """Validates data volume and partition distributions across source and target."""

    def __init__(self, global_config: Optional[Dict[str, Any]] = None):
        self.config = global_config or {}
        self.threshold_warning = self.config.get("threshold_pct_warning", 0.0)
        self.threshold_critical = self.config.get("threshold_pct_critical", 1.0)

    def validate_table_pair(
        self,
        rule_name: str,
        source_connector: BaseConnector,
        source_table: str,
        target_connector: BaseConnector,
        target_table: str,
        key_column: str,
        target_key_column: Optional[str] = None,
        partition_by: Optional[str] = None,
        target_partition_by: Optional[str] = None,
        where_clause: Optional[str] = None
    ) -> Dict[str, Any]:
        """Runs total count, partition breakdown, and missing key analysis."""
        target_key_column = target_key_column or key_column
        
        # 1. Total Row Counts
        src_count = source_connector.get_row_count(source_table, where_clause)
        tgt_count = target_connector.get_row_count(target_table, where_clause)

        diff = tgt_count - src_count
        diff_pct = abs(diff / src_count * 100.0) if src_count > 0 else (0.0 if tgt_count == 0 else 100.0)

        status = "PASS"
        if diff != 0:
            if diff_pct > self.threshold_critical:
                status = "FAIL"
            else:
                status = "WARNING"

        # 2. Key Presence / Missing Key Checks
        src_keys_df = source_connector.fetch_dataframe(source_table, columns=[key_column], where_clause=where_clause)
        tgt_keys_df = target_connector.fetch_dataframe(target_table, columns=[target_key_column], where_clause=where_clause)

        src_keys = set(src_keys_df[key_column].dropna().astype(str).tolist())
        tgt_keys = set(tgt_keys_df[target_key_column].dropna().astype(str).tolist())

        missing_in_target = list(src_keys - tgt_keys)
        orphan_in_target = list(tgt_keys - src_keys)

        # 3. Partition Breakdown
        partition_results = []
        if partition_by:
            tgt_part_col = target_partition_by or partition_by
            try:
                src_part_df = source_connector.get_partition_counts(source_table, partition_by, where_clause)
                tgt_part_df = target_connector.get_partition_counts(target_table, tgt_part_col, where_clause)
                
                merged_parts = pd.merge(
                    src_part_df, tgt_part_df, on="partition_key", how="outer", suffixes=("_src", "_tgt")
                ).fillna(0)
                
                for _, r in merged_parts.iterrows():
                    p_key = str(r["partition_key"])
                    s_c = int(r.get("row_count_src", 0))
                    t_c = int(r.get("row_count_tgt", 0))
                    p_diff = t_c - s_c
                    p_status = "PASS" if p_diff == 0 else "FAIL"
                    partition_results.append({
                        "partition_key": p_key,
                        "source_count": s_c,
                        "target_count": t_c,
                        "diff": p_diff,
                        "status": p_status
                    })
            except Exception as e:
                partition_results.append({"error": f"Partition validation error: {str(e)}"})

        return {
            "rule_name": rule_name,
            "source_table": source_table,
            "target_table": target_table,
            "source_count": src_count,
            "target_count": tgt_count,
            "diff": diff,
            "diff_percent": round(diff_pct, 4),
            "status": status,
            "missing_in_target_count": len(missing_in_target),
            "missing_in_target_sample": missing_in_target[:10],
            "orphan_in_target_count": len(orphan_in_target),
            "orphan_in_target_sample": orphan_in_target[:10],
            "partition_breakdown": partition_results
        }
