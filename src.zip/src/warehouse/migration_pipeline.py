"""
Warehouse Migration Pipeline: Orchestrates Extract, Transform, and Load into Target Data Warehouse.
"""
import time
import os
import sys
from typing import Dict, Any, Optional
import pandas as pd
import openpyxl
import sqlalchemy as sa
from .schema_builder import DWHDDLBuilder
from .transformer import DWHTransformer
from ..connectors.factory import ConnectorFactory
from ..connectors.sqlalchemy_connector import SQLAlchemyConnector


class MigrationPipeline:
    """Orchestrates end-to-end Data Warehouse Migration."""

    def __init__(
        self,
        relational_excel_path: str = "manufacturing_relational_data.xlsx",
        flat_excel_path: Optional[str] = "manufacturing_mock_data.xlsx",
        target_db_conn_str: str = "sqlite:///data/manufacturing_dwh.db",
        ddl_path: Optional[str] = None
    ):
        self.relational_excel_path = relational_excel_path
        self.flat_excel_path = flat_excel_path
        self.target_db_conn_str = target_db_conn_str
        self.ddl_path = ddl_path
        self.target_connector = SQLAlchemyConnector("target_dwh", target_db_conn_str)

    def run_migration(self, drop_existing: bool = True) -> Dict[str, Any]:
        """Runs the entire migration pipeline and returns summary metrics."""
        start_time = time.time()
        print("====================================================================")
        print("[MIGRATE] STARTING MANUFACTURING DATA WAREHOUSE MIGRATION PIPELINE")
        print("====================================================================")

        # 1. Initialize DWH Schema
        print(f"[*] Step 1: Initializing Star Schema DDL at: {self.target_db_conn_str}")
        builder = DWHDDLBuilder(self.target_db_conn_str, self.ddl_path)
        builder.build_schema(drop_existing=drop_existing)
        print("    [OK] Dimensions, Facts, and Indexes created successfully.")

        # 2. Extract Data
        print(f"[*] Step 2: Extracting source tables from {self.relational_excel_path}...")
        sheets_dict: Dict[str, pd.DataFrame] = {}
        wb = openpyxl.load_workbook(self.relational_excel_path, read_only=True)
        for s in wb.sheetnames:
            if s != "Manufacturing_Data":
                print(f"    - Reading sheet: {s}")
                sheets_dict[s] = pd.read_excel(self.relational_excel_path, sheet_name=s)
        wb.close()

        flat_df = None
        if self.flat_excel_path and os.path.exists(self.flat_excel_path):
            print(f"    - Reading flat mock sheet: {self.flat_excel_path}")
            flat_df = pd.read_excel(self.flat_excel_path, sheet_name=0)

        # 3. Transform to Star Schema
        print("[*] Step 3: Transforming source records into Star Schema Dimensions & Facts...")
        transformer = DWHTransformer(sheets_dict, flat_df)
        dwh_tables = transformer.transform_all()

        # 4. Load Data into Target DWH
        print("[*] Step 4: Loading clean Dimensions and Facts into Target Data Warehouse...")
        load_summary = {}
        target_engine = self.target_connector.connect()

        # Load Dimensions first
        dim_order = [
            "dim_date", "dim_location", "dim_color", "dim_plant",
            "dim_production_line", "dim_product", "dim_machine",
            "dim_operator", "dim_supplier", "dim_material",
            "dim_material_sales", "dim_defect_catalog"
        ]

        for dim in dim_order:
            if dim in dwh_tables:
                df = dwh_tables[dim]
                df.to_sql(dim, con=target_engine, if_exists="append", index=False, chunksize=1000)
                load_summary[dim] = len(df)
                print(f"    [LOADED] Dimension: {dim:<25} ({len(df):>6} rows)")

        # Load Fact Tables
        fact_order = [
            "fact_work_orders", "fact_sales_detail", "fact_order_detail",
            "fact_machine_telemetry", "fact_quality_inspections",
            "fact_labor_performance", "fact_cost_financials", "fact_procurement"
        ]

        for fact in fact_order:
            if fact in dwh_tables:
                df = dwh_tables[fact]
                df.to_sql(fact, con=target_engine, if_exists="append", index=False, chunksize=1000)
                load_summary[fact] = len(df)
                print(f"    [LOADED] Fact Table: {fact:<25} ({len(df):>6} rows)")

        elapsed_sec = round(time.time() - start_time, 2)
        total_rows = sum(load_summary.values())
        print("--------------------------------------------------------------------")
        print(f"[SUCCESS] MIGRATION COMPLETED in {elapsed_sec}s! Total Loaded Rows: {total_rows}")
        print("====================================================================\n")

        return {
            "status": "SUCCESS",
            "elapsed_seconds": elapsed_sec,
            "total_rows": total_rows,
            "table_counts": load_summary
        }
