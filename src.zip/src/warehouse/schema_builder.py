"""
Schema Builder: Reads Star Schema DDL and sets up tables, constraints, and indexes in Target DWH.
"""
import os
from typing import Optional
import sqlalchemy as sa
from sqlalchemy import text


class DWHDDLBuilder:
    """Builds and initializes Star Schema Data Warehouse tables in Target Database."""

    def __init__(self, connection_string: str, ddl_path: Optional[str] = None):
        self.connection_string = connection_string
        self.ddl_path = ddl_path or os.path.join(
            os.path.dirname(__file__), "..", "..", "config", "dwh_schema.sql"
        )
        self.engine = sa.create_engine(connection_string)

    def build_schema(self, drop_existing: bool = False) -> None:
        """Executes the DDL file to build dimensions, facts, and indexes."""
        # Ensure parent directory exists for SQLite
        if "sqlite:///" in self.connection_string:
            db_file = self.connection_string.replace("sqlite:///", "")
            if db_file and db_file != ":memory:":
                os.makedirs(os.path.dirname(os.path.abspath(db_file)), exist_ok=True)

        if not os.path.exists(self.ddl_path):
            raise FileNotFoundError(f"DDL file not found at: {self.ddl_path}")

        with open(self.ddl_path, "r", encoding="utf-8") as f:
            ddl_content = f.read()

        statements = [s.strip() for s in ddl_content.split(";") if s.strip()]

        with self.engine.begin() as conn:
            if drop_existing:
                # Drop facts then dimensions to respect FKs
                tables_to_drop = [
                    "fact_work_orders", "fact_sales_detail", "fact_order_detail",
                    "fact_machine_telemetry", "fact_quality_inspections",
                    "fact_labor_performance", "fact_cost_financials", "fact_procurement",
                    "dim_material_sales", "dim_defect_catalog", "dim_material",
                    "dim_supplier", "dim_operator", "dim_machine", "dim_color",
                    "dim_product", "dim_production_line", "dim_plant", "dim_location", "dim_date"
                ]
                for tbl in tables_to_drop:
                    conn.execute(text(f'DROP TABLE IF EXISTS "{tbl}"'))

            for stmt in statements:
                conn.execute(text(stmt))

    def get_table_list(self) -> list:
        """Returns list of created tables in the DWH."""
        inspector = sa.inspect(self.engine)
        return inspector.get_table_names()
