"""
Star Schema Transformer: Extracts from Source Sheets, assigns Surrogate Keys,
performs dimensional lookups, and prepares clean Fact and Dimension DataFrames.
"""
import datetime
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
import pandas as pd


class DWHTransformer:
    """Transforms raw / relational manufacturing datasets into Star Schema Dimensions & Facts."""

    def __init__(self, relational_sheets: Dict[str, pd.DataFrame], flat_df: Optional[pd.DataFrame] = None):
        self.sheets = relational_sheets
        self.flat_df = flat_df
        
        # Dimension lookup dictionaries: Business Key -> Surrogate Key
        self.dim_date_df = pd.DataFrame()
        self.dim_location_df = pd.DataFrame()
        self.dim_color_df = pd.DataFrame()
        self.dim_plant_df = pd.DataFrame()
        self.dim_line_df = pd.DataFrame()
        self.dim_product_df = pd.DataFrame()
        self.dim_machine_df = pd.DataFrame()
        self.dim_operator_df = pd.DataFrame()
        self.dim_supplier_df = pd.DataFrame()
        self.dim_material_df = pd.DataFrame()
        self.dim_material_sales_df = pd.DataFrame()
        self.dim_defect_df = pd.DataFrame()

        self.sk_lookups: Dict[str, Dict[Any, int]] = {
            "date": {},
            "location": {},
            "color": {},
            "plant": {},
            "line": {},
            "product": {},
            "machine": {},
            "operator": {},
            "supplier": {},
            "material": {},
            "material_sales": {},
            "defect": {},
            "work_order": {}
        }

    @staticmethod
    def _to_date_key(dt_val) -> int:
        """Converts datetime or string to YYYYMMDD integer."""
        if pd.isnull(dt_val):
            return 19000101
        try:
            dt = pd.to_datetime(dt_val)
            return int(dt.strftime("%Y%m%d"))
        except Exception:
            return 19000101

    def build_dim_date(self, start_year: int = 2022, end_year: int = 2028) -> pd.DataFrame:
        """Generates comprehensive calendar and fiscal date dimension."""
        start_dt = datetime.date(start_year, 1, 1)
        end_dt = datetime.date(end_year, 12, 31)
        dates = pd.date_range(start_dt, end_dt, freq='D')
        
        records = []
        # Include default unknown date row
        records.append({
            "date_key": 19000101,
            "full_date": "1900-01-01",
            "calendar_year": 1900,
            "calendar_quarter": 1,
            "calendar_month": 1,
            "month_name": "January",
            "month_short_name": "Jan",
            "calendar_week": 1,
            "day_of_month": 1,
            "day_of_week": 1,
            "day_name": "Monday",
            "is_weekend": 0,
            "fiscal_period": "1900-Q1",
            "fiscal_year": 1900,
            "fiscal_quarter": 1
        })

        for d in dates:
            d_key = int(d.strftime("%Y%m%d"))
            q = (d.month - 1) // 3 + 1
            records.append({
                "date_key": d_key,
                "full_date": d.strftime("%Y-%m-%d"),
                "calendar_year": d.year,
                "calendar_quarter": q,
                "calendar_month": d.month,
                "month_name": d.strftime("%B"),
                "month_short_name": d.strftime("%b"),
                "calendar_week": int(d.strftime("%U")),
                "day_of_month": d.day,
                "day_of_week": d.weekday() + 1,
                "day_name": d.strftime("%A"),
                "is_weekend": 1 if d.weekday() >= 5 else 0,
                "fiscal_period": f"{d.year}-Q{q}",
                "fiscal_year": d.year,
                "fiscal_quarter": q
            })
            
        self.dim_date_df = pd.DataFrame(records)
        self.sk_lookups["date"] = {r["date_key"]: r["date_key"] for r in records}
        return self.dim_date_df

    def build_dim_location(self) -> pd.DataFrame:
        """Extracts unified locations across Plants, Warehouses, Customer Destinations, and Suppliers."""
        locations = []
        loc_keys_seen = set()

        # 1. Plants
        if "Plants" in self.sheets:
            plants_df = self.sheets["Plants"]
            for _, r in plants_df.iterrows():
                code = f"LOC-PLANT-{r.get('Plant_Code')}"
                if code not in loc_keys_seen:
                    loc_keys_seen.add(code)
                    locations.append({
                        "location_code": str(r.get("Plant_Code")),
                        "location_type": "Plant",
                        "country": str(r.get("Country", "Unknown")),
                        "region": str(r.get("Region", "Unknown")),
                        "city": str(r.get("City", "Unknown")),
                        "address_line1": str(r.get("Address_Line1", "")),
                        "postal_code": str(r.get("Postal_Code", "")),
                        "timezone": str(r.get("Timezone", "UTC")),
                        "latitude": float(r.get("Latitude")) if pd.notnull(r.get("Latitude")) else None,
                        "longitude": float(r.get("Longitude")) if pd.notnull(r.get("Longitude")) else None,
                        "is_active": 1
                    })

        # 2. Warehouses from Materials
        if "Materials" in self.sheets:
            mats_df = self.sheets["Materials"]
            for wh in mats_df["Warehouse_Location"].dropna().unique():
                code = str(wh)
                if code not in loc_keys_seen:
                    loc_keys_seen.add(code)
                    locations.append({
                        "location_code": code,
                        "location_type": "Warehouse",
                        "country": "USA",
                        "region": "Domestic Storage",
                        "city": code,
                        "address_line1": f"Warehouse Facility {code}",
                        "postal_code": "00000",
                        "timezone": "UTC",
                        "latitude": None,
                        "longitude": None,
                        "is_active": 1
                    })

        # 3. Customer Destinations from Flat Data
        if self.flat_df is not None and "Destination_Country" in self.flat_df.columns:
            dest_df = self.flat_df[["Destination_Country", "Destination_City"]].dropna().drop_duplicates()
            for _, r in dest_df.iterrows():
                code = f"CUST-LOC-{r['Destination_Country']}-{r['Destination_City']}"
                if code not in loc_keys_seen:
                    loc_keys_seen.add(code)
                    locations.append({
                        "location_code": code,
                        "location_type": "Customer_Destination",
                        "country": str(r["Destination_Country"]),
                        "region": "Commercial Hub",
                        "city": str(r["Destination_City"]),
                        "address_line1": f"Customer Receiving Depot, {r['Destination_City']}",
                        "postal_code": "N/A",
                        "timezone": "UTC",
                        "latitude": None,
                        "longitude": None,
                        "is_active": 1
                    })

        # 4. Unknown fallback
        if "LOC-UNKNOWN" not in loc_keys_seen:
            locations.insert(0, {
                "location_code": "LOC-UNKNOWN",
                "location_type": "Unknown",
                "country": "Unknown",
                "region": "Unknown",
                "city": "Unknown",
                "address_line1": "Unknown",
                "postal_code": "Unknown",
                "timezone": "UTC",
                "latitude": 0.0,
                "longitude": 0.0,
                "is_active": 1
            })

        df = pd.DataFrame(locations)
        df["location_key"] = range(1, len(df) + 1)
        self.dim_location_df = df
        
        # Build lookup map for both exact code and country-city pair
        for _, r in df.iterrows():
            self.sk_lookups["location"][r["location_code"]] = int(r["location_key"])
            if r["location_type"] == "Customer_Destination":
                key_pair = f"{r['country']}_{r['city']}"
                self.sk_lookups["location"][key_pair] = int(r["location_key"])

        return self.dim_location_df

    def build_dim_color(self) -> pd.DataFrame:
        """Builds industrial standard coating, RAL, and finishing colors dimension."""
        colors = [
            {"color_code": "CLR-000", "color_name": "Standard Uncoated / Raw", "hex_code": "#A0A0A0", "finish_type": "Raw/Brushed", "ral_code": "RAL 9006", "pantone_reference": "N/A"},
            {"color_code": "CLR-001", "color_name": "Anthracite Industrial Grey", "hex_code": "#293133", "finish_type": "Powder Coated", "ral_code": "RAL 7016", "pantone_reference": "Cool Gray 11C"},
            {"color_code": "CLR-002", "color_name": "Jet Matt Black", "hex_code": "#0A0A0A", "finish_type": "Matte", "ral_code": "RAL 9005", "pantone_reference": "Black 6C"},
            {"color_code": "CLR-003", "color_name": "Signal Pure White", "hex_code": "#F4F4F4", "finish_type": "Gloss", "ral_code": "RAL 9003", "pantone_reference": "Bright White"},
            {"color_code": "CLR-004", "color_name": "High Precision Blue", "hex_code": "#1B5583", "finish_type": "Anodized", "ral_code": "RAL 5005", "pantone_reference": "Process Blue C"},
            {"color_code": "CLR-005", "color_name": "Titanium Metallic Silver", "hex_code": "#8C92AC", "finish_type": "Anodized", "ral_code": "RAL 9007", "pantone_reference": "877 C"},
            {"color_code": "CLR-006", "color_name": "Safety Flame Red", "hex_code": "#AF2B1E", "finish_type": "Gloss", "ral_code": "RAL 3000", "pantone_reference": "485 C"},
            {"color_code": "CLR-007", "color_name": "Emerald Industrial Green", "hex_code": "#1B4D3E", "finish_type": "Powder Coated", "ral_code": "RAL 6001", "pantone_reference": "349 C"},
            {"color_code": "CLR-008", "color_name": "Champagne Anodized Gold", "hex_code": "#B59E5F", "finish_type": "Anodized", "ral_code": "RAL 1036", "pantone_reference": "8640 C"},
            {"color_code": "CLR-009", "color_name": "Carbon Weave Coat", "hex_code": "#1C1C1C", "finish_type": "Matte", "ral_code": "RAL 7021", "pantone_reference": "Black 7C"}
        ]
        df = pd.DataFrame(colors)
        df["color_key"] = range(1, len(df) + 1)
        self.dim_color_df = df
        for _, r in df.iterrows():
            self.sk_lookups["color"][r["color_code"]] = int(r["color_key"])
        return self.dim_color_df

    def build_dim_plant(self) -> pd.DataFrame:
        """Transforms Plants table into dim_plant with location foreign key."""
        df = self.sheets["Plants"].copy()
        df["location_key"] = df["Plant_Code"].apply(lambda c: self.sk_lookups["location"].get(str(c), 1))
        
        col_map = {
            "Plant_Code": "plant_code",
            "Plant_Name": "plant_name",
            "Plant_Type": "plant_type",
            "Square_Footage": "square_footage",
            "Number_Of_Employees": "number_of_employees",
            "Established_Year": "established_year",
            "ISO_9001_Certified": "iso_9001_certified",
            "ISO_14001_Certified": "iso_14001_certified",
            "IATF_16949_Certified": "iatf_16949_certified",
            "Plant_Manager": "plant_manager",
            "Energy_Source_Primary": "energy_source_primary",
            "Annual_Capacity_Units": "annual_capacity_units",
            "Shift_Pattern": "shift_pattern",
            "Union_Site_Flag": "union_site_flag",
            "ERP_System": "erp_system"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["location_key"] = df["location_key"]
        renamed["plant_key"] = range(1, len(renamed) + 1)
        
        self.dim_plant_df = renamed
        for _, r in renamed.iterrows():
            self.sk_lookups["plant"][str(r["plant_code"])] = int(r["plant_key"])
        return self.dim_plant_df

    def build_dim_production_line(self) -> pd.DataFrame:
        """Transforms Production_Lines into dim_production_line with plant foreign key."""
        df = self.sheets["Production_Lines"].copy()
        df["plant_key"] = df["Plant_Code"].apply(lambda c: self.sk_lookups["plant"].get(str(c), 1))

        col_map = {
            "Line_ID": "line_id",
            "Line_Name": "line_name",
            "Line_Type": "line_type",
            "Automation_Level": "automation_level",
            "Installed_Date": "installed_date",
            "Number_Of_Stations": "number_of_stations",
            "Number_Of_Machines": "number_of_machines",
            "Design_Capacity_Units_Per_Hour": "design_capacity_units_per_hour",
            "Safety_Rating": "safety_rating",
            "Line_Layout_Type": "line_layout_type",
            "Product_Family_Assigned": "product_family_assigned",
            "Digital_Twin_Enabled": "digital_twin_enabled"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["plant_key"] = df["plant_key"]
        renamed["line_key"] = range(1, len(renamed) + 1)

        self.dim_line_df = renamed
        for _, r in renamed.iterrows():
            self.sk_lookups["line"][str(r["line_id"])] = int(r["line_key"])
        return self.dim_line_df

    def build_dim_product(self) -> pd.DataFrame:
        """Transforms Products into dim_product."""
        df = self.sheets["Products"].copy()
        col_map = {
            "Product_SKU": "product_sku",
            "Product_Family": "product_family",
            "Product_Name": "product_name",
            "Product_Revision": "product_revision",
            "BOM_Version": "bom_version",
            "Product_Category": "product_category",
            "Unit_Of_Measure": "unit_of_measure",
            "Standard_Weight_g": "standard_weight_g",
            "Standard_Cost_USD": "standard_cost_usd",
            "List_Price_USD": "list_price_usd",
            "Product_Status": "product_status",
            "Material_Primary": "material_primary",
            "Target_Cpk": "target_cpk",
            "Shelf_Life_Days": "shelf_life_days",
            "Country_Of_Origin": "country_of_origin",
            "RoHS_Compliant": "rohs_compliant",
            "REACH_Compliant": "reach_compliant"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["product_key"] = range(1, len(renamed) + 1)

        self.dim_product_df = renamed
        for _, r in renamed.iterrows():
            self.sk_lookups["product"][str(r["product_sku"])] = int(r["product_key"])
        return self.dim_product_df

    def build_dim_machine(self) -> pd.DataFrame:
        """Transforms Machines into dim_machine with line foreign key."""
        df = self.sheets["Machines"].copy()
        df["line_key"] = df["Line_ID"].apply(lambda l: self.sk_lookups["line"].get(str(l), 1))

        col_map = {
            "Machine_ID": "machine_id",
            "Machine_Type": "machine_type",
            "Machine_Manufacturer": "machine_manufacturer",
            "Machine_Model_Year": "machine_model_year",
            "Machine_Serial_Number": "machine_serial_number",
            "Useful_Life_Years": "useful_life_years",
            "Depreciation_Method": "depreciation_method",
            "PLC_Firmware_Version": "plc_firmware_version",
            "IoT_Sensor_Enabled": "iot_sensor_enabled",
            "Predictive_Maintenance_Enabled": "predictive_maintenance_enabled",
            "Criticality_Rank": "criticality_rank"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["line_key"] = df["line_key"]
        renamed["machine_key"] = range(1, len(renamed) + 1)

        self.dim_machine_df = renamed
        for _, r in renamed.iterrows():
            self.sk_lookups["machine"][str(r["machine_id"])] = int(r["machine_key"])
        return self.dim_machine_df

    def build_dim_operator(self) -> pd.DataFrame:
        """Transforms Operators into dim_operator."""
        df = self.sheets["Operators"].copy()
        col_map = {
            "Operator_ID": "operator_id",
            "Operator_Name": "operator_name",
            "Department": "department",
            "Job_Title": "job_title",
            "Hire_Date": "hire_date",
            "Years_Of_Experience": "years_of_experience",
            "Operator_Certification_Level": "operator_certification_level",
            "Shift_Assignment": "shift_assignment",
            "Labor_Rate_USD_per_hr": "labor_rate_usd_per_hr",
            "Union_Member_Flag": "union_member_flag",
            "Active_Flag": "active_flag",
            "Supervisor_Name": "supervisor_name"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["operator_key"] = range(1, len(renamed) + 1)

        self.dim_operator_df = renamed
        for _, r in renamed.iterrows():
            self.sk_lookups["operator"][str(r["operator_id"])] = int(r["operator_key"])
        return self.dim_operator_df

    def build_dim_supplier(self) -> pd.DataFrame:
        """Transforms Suppliers into dim_supplier."""
        df = self.sheets["Suppliers"].copy()
        col_map = {
            "Supplier_ID": "supplier_id",
            "Supplier_Name": "supplier_name",
            "Supplier_Country": "supplier_country",
            "Supplier_Tier": "supplier_tier",
            "Relationship_Start_Date": "relationship_start_date",
            "Preferred_Supplier_Flag": "preferred_supplier_flag",
            "Supplier_Quality_Rating": "supplier_quality_rating",
            "On_Time_Delivery_Rate_Percent": "on_time_delivery_rate_percent",
            "Defect_PPM": "defect_ppm",
            "ISO_9001_Certified": "iso_9001_certified",
            "IATF_16949_Certified": "iatf_16949_certified",
            "Approved_Status": "approved_status"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["supplier_key"] = range(1, len(renamed) + 1)

        self.dim_supplier_df = renamed
        for _, r in renamed.iterrows():
            self.sk_lookups["supplier"][str(r["supplier_id"])] = int(r["supplier_key"])
        return self.dim_supplier_df

    def build_dim_material(self) -> pd.DataFrame:
        """Transforms Materials into dim_material with supplier foreign key."""
        df = self.sheets["Materials"].copy()
        df["supplier_key"] = df["Supplier_ID"].apply(lambda s: self.sk_lookups["supplier"].get(str(s), 1))

        col_map = {
            "Material_ID": "material_id",
            "Raw_Material_Type": "raw_material_type",
            "Material_Lot_Number": "material_lot_number",
            "Material_Batch_Number": "material_batch_number",
            "Material_Unit_Cost_USD": "material_unit_cost_usd",
            "ABC_Classification": "abc_classification",
            "Hazardous_Material_Flag": "hazardous_material_flag",
            "Country_Of_Origin": "country_of_origin",
            "Storage_Condition_Required": "storage_condition_required",
            "Recycled_Content_Percent": "recycled_content_percent"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["supplier_key"] = df["supplier_key"]
        renamed["material_key"] = range(1, len(renamed) + 1)

        self.dim_material_df = renamed
        for _, r in renamed.iterrows():
            self.sk_lookups["material"][str(r["material_id"])] = int(r["material_key"])
        return self.dim_material_df

    def build_dim_material_sales(self) -> pd.DataFrame:
        """Builds dim_material_sales catalog referencing dim_material."""
        categories = ["Direct Material", "Fabricated Stock", "Secondary Recycled", "Export Surplus"]
        records = []
        for idx, r in self.dim_material_df.iterrows():
            cat = categories[idx % len(categories)]
            unit_cost = float(r.get("material_unit_cost_usd", 35.0))
            margin = 0.25 + (idx % 15) * 0.01
            sales_price = round(unit_cost * (1 + margin), 2)
            code = f"MS-{r['material_id']}"
            records.append({
                "material_sales_code": code,
                "material_key": int(r["material_key"]),
                "sales_category": cat,
                "material_grade": f"Grade-{chr(65 + (idx % 6))}",
                "standard_sales_price_usd": sales_price,
                "min_order_quantity_kg": 100.0 * ((idx % 10) + 1),
                "target_margin_percent": round(margin * 100, 2),
                "tax_classification_code": f"TX-MAT-{(idx % 5) + 1}"
            })
        df = pd.DataFrame(records)
        df["material_sales_key"] = range(1, len(df) + 1)
        self.dim_material_sales_df = df
        for _, r in df.iterrows():
            self.sk_lookups["material_sales"][r["material_sales_code"]] = int(r["material_sales_key"])
        return self.dim_material_sales_df

    def build_dim_defect_catalog(self) -> pd.DataFrame:
        """Builds distinct Defect Catalog dimension from Quality Inspections."""
        df = self.sheets.get("Quality_Inspections")
        if df is not None:
            defects = df[["Primary_Defect_Type", "Secondary_Defect_Type", "Critical_Defect_Flag"]].dropna().drop_duplicates()
        else:
            defects = pd.DataFrame([{"Primary_Defect_Type": "None", "Secondary_Defect_Type": "None", "Critical_Defect_Flag": "No"}])

        records = []
        records.append({
            "defect_code": "DEF-NONE",
            "primary_defect_type": "No Defect",
            "secondary_defect_type": "Pass / Conforming",
            "critical_defect_flag": "No",
            "severity_level": "None"
        })

        for i, (_, r) in enumerate(defects.iterrows(), start=1):
            is_crit = str(r.get("Critical_Defect_Flag", "No")).strip().lower() in ["yes", "y", "true", "1"]
            records.append({
                "defect_code": f"DEF-{i:04d}",
                "primary_defect_type": str(r.get("Primary_Defect_Type", "Dimensional")),
                "secondary_defect_type": str(r.get("Secondary_Defect_Type", "Tolerance Drift")),
                "critical_defect_flag": "Yes" if is_crit else "No",
                "severity_level": "Critical" if is_crit else ("High" if i % 3 == 0 else "Medium")
            })

        catalog_df = pd.DataFrame(records)
        catalog_df["defect_key"] = range(1, len(catalog_df) + 1)
        self.dim_defect_df = catalog_df

        for _, r in catalog_df.iterrows():
            key_str = f"{r['primary_defect_type']}_{r['secondary_defect_type']}"
            self.sk_lookups["defect"][key_str] = int(r["defect_key"])
            self.sk_lookups["defect"][r["primary_defect_type"]] = int(r["defect_key"])
            self.sk_lookups["defect"][r["defect_code"]] = int(r["defect_key"])

        return self.dim_defect_df

    # ----------------------------------------------------------------
    # FACT TABLE BUILDERS
    # ----------------------------------------------------------------

    def build_fact_work_orders(self) -> pd.DataFrame:
        """Transforms Work_Orders sheet into fact_work_orders with surrogate foreign keys."""
        df = self.sheets["Work_Orders"].copy()
        
        total_colors = len(self.dim_color_df) if not self.dim_color_df.empty else 1
        
        df["order_date_key"] = df["Order_Date"].apply(self._to_date_key)
        df["plant_key"] = df["Plant_Code"].apply(lambda p: self.sk_lookups["plant"].get(str(p), 1))
        df["line_key"] = df["Line_ID"].apply(lambda l: self.sk_lookups["line"].get(str(l), 1))
        df["product_key"] = df["Product_SKU"].apply(lambda p: self.sk_lookups["product"].get(str(p), 1))
        df["color_key"] = df.index.map(lambda i: (i % total_colors) + 1)

        col_map = {
            "Work_Order_Number": "work_order_number",
            "Production_Order_Type": "production_order_type",
            "Shift": "shift",
            "Order_Status": "order_status",
            "Planned_Quantity": "planned_quantity",
            "Produced_Quantity": "produced_quantity",
            "Good_Quantity": "good_quantity",
            "Scrap_Quantity": "scrap_quantity",
            "Rework_Quantity": "rework_quantity",
            "Yield_Percent": "yield_percent",
            "Scrap_Rate_Percent": "scrap_rate_percent",
            "Cycle_Time_Sec": "cycle_time_sec",
            "Takt_Time_Sec": "takt_time_sec",
            "Setup_Time_Min": "setup_time_min",
            "Total_Runtime_Hours": "total_runtime_hours",
            "Total_Downtime_Hours": "total_downtime_hours",
            "OEE_Percent": "oee_percent",
            "Availability_Percent": "availability_percent",
            "Performance_Percent": "performance_percent",
            "Quality_Rate_Percent": "quality_rate_percent",
            "Customer_Order_Number": "customer_order_number",
            "Customer_Name": "customer_name"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["order_date_key"] = df["order_date_key"]
        renamed["plant_key"] = df["plant_key"]
        renamed["line_key"] = df["line_key"]
        renamed["product_key"] = df["product_key"]
        renamed["color_key"] = df["color_key"]
        renamed["work_order_key"] = range(1, len(renamed) + 1)

        # Populate work_order lookup
        for _, r in renamed.iterrows():
            self.sk_lookups["work_order"][str(r["work_order_number"])] = int(r["work_order_key"])

        return renamed

    def build_fact_sales_detail(self) -> pd.DataFrame:
        """Transforms sales data from Flat sheet or Work Orders into fact_sales_detail."""
        source_df = self.flat_df if self.flat_df is not None else self.sheets["Work_Orders"]
        df = source_df.copy()
        
        total_colors = len(self.dim_color_df) if not self.dim_color_df.empty else 1
        total_mat_sales = len(self.dim_material_sales_df) if not self.dim_material_sales_df.empty else 1
        
        records = []
        for i, (_, r) in enumerate(df.iterrows(), start=1):
            inv_no = str(r.get("Invoice_Number", f"INV-{i:06d}"))
            order_dt = r.get("Order_Date", datetime.date(2024, 1, 1))
            ship_dt = r.get("Ship_Date", r.get("Actual_End_Timestamp", order_dt))
            
            prod_sku = str(r.get("Product_SKU", "SKU-001"))
            plant_code = str(r.get("Plant_Code", "PLANT-01"))
            
            dest_country = str(r.get("Destination_Country", "USA"))
            dest_city = str(r.get("Destination_City", "Austin"))
            loc_key = self.sk_lookups["location"].get(f"{dest_country}_{dest_city}", 
                      self.sk_lookups["location"].get(plant_code, 1))
            
            qty = float(r.get("Produced_Quantity", r.get("Planned_Quantity", 100.0)))
            unit_price = float(r.get("Selling_Price_USD", 500.0))
            gross_amount = round(qty * unit_price, 2)
            discount = round(gross_amount * (0.05 if i % 4 == 0 else 0.0), 2)
            net_amount = round(gross_amount - discount, 2)
            
            unit_cost = float(r.get("Total_Unit_Cost_USD", unit_price * 0.65))
            cogs = round(qty * unit_cost, 2)
            gross_profit = round(net_amount - cogs, 2)
            margin_pct = float(r.get("Gross_Margin_Percent", round((gross_profit / net_amount) * 100, 2) if net_amount > 0 else 0.0))

            records.append({
                "sales_detail_key": i,
                "sales_invoice_number": inv_no,
                "invoice_line_number": 1,
                "sale_date_key": self._to_date_key(order_dt),
                "ship_date_key": self._to_date_key(ship_dt),
                "product_key": self.sk_lookups["product"].get(prod_sku, 1),
                "color_key": (i % total_colors) + 1,
                "location_key": loc_key,
                "plant_key": self.sk_lookups["plant"].get(plant_code, 1),
                "material_sales_key": (i % total_mat_sales) + 1,
                "customer_order_number": str(r.get("Customer_Order_Number", f"CO-{i:06d}")),
                "customer_name": str(r.get("Customer_Name", f"Customer-{i:03d}")),
                "customer_po_number": str(r.get("Customer_PO_Number", f"CPO-{i:05d}")),
                "sales_quantity": qty,
                "unit_selling_price_usd": unit_price,
                "gross_sales_amount_usd": gross_amount,
                "discount_amount_usd": discount,
                "net_sales_amount_usd": net_amount,
                "cost_of_goods_sold_usd": cogs,
                "gross_profit_usd": gross_profit,
                "gross_margin_percent": margin_pct,
                "tax_amount_usd": round(net_amount * 0.08, 2),
                "freight_charge_usd": float(r.get("Freight_Cost_USD", 150.0)),
                "carrier": str(r.get("Carrier", "FedEx Freight")),
                "tracking_number": str(r.get("Tracking_Number", f"TRK-{i:08d}")),
                "on_time_delivery_flag": str(r.get("On_Time_Delivery_Flag", "Yes")),
                "return_flag": str(r.get("Return_Flag", "No"))
            })

        sales_df = pd.DataFrame(records)
        sales_df["invoice_line_number"] = sales_df.groupby("sales_invoice_number").cumcount() + 1
        return sales_df

    def build_fact_order_detail(self) -> pd.DataFrame:
        """Transforms customer and production order records into fact_order_detail."""
        source_df = self.flat_df if self.flat_df is not None else self.sheets["Work_Orders"]
        df = source_df.copy()
        
        total_colors = len(self.dim_color_df) if not self.dim_color_df.empty else 1
        total_mats = len(self.dim_material_df) if not self.dim_material_df.empty else 1

        records = []
        for i, (_, r) in enumerate(df.iterrows(), start=1):
            co_no = str(r.get("Customer_Order_Number", f"CO-{i:06d}"))
            order_dt = r.get("Order_Date", datetime.date(2024, 1, 1))
            planned_end = r.get("Planned_End_Date", r.get("Actual_End_Timestamp", order_dt))
            
            prod_sku = str(r.get("Product_SKU", "SKU-001"))
            plant_code = str(r.get("Plant_Code", "PLANT-01"))
            line_id = str(r.get("Production_Line", r.get("Line_ID", "LINE-01")))
            
            loc_key = self.sk_lookups["location"].get(plant_code, 1)
            planned_qty = float(r.get("Planned_Quantity", 100.0))
            good_qty = float(r.get("Good_Quantity", planned_qty * 0.95))
            backorder_qty = max(0.0, planned_qty - good_qty)
            unit_price = float(r.get("Selling_Price_USD", 500.0))
            line_total = round(planned_qty * unit_price, 2)

            records.append({
                "order_detail_key": i,
                "order_number": co_no,
                "order_line_item": 1,
                "order_date_key": self._to_date_key(order_dt),
                "requested_date_key": self._to_date_key(planned_end),
                "product_key": self.sk_lookups["product"].get(prod_sku, 1),
                "color_key": (i % total_colors) + 1,
                "location_key": loc_key,
                "line_key": self.sk_lookups["line"].get(line_id, 1),
                "material_key": (i % total_mats) + 1,
                "order_type": str(r.get("Production_Order_Type", "Standard")),
                "order_quantity": planned_qty,
                "fulfilled_quantity": good_qty,
                "backorder_quantity": backorder_qty,
                "unit_price_usd": unit_price,
                "line_total_usd": line_total,
                "lead_time_days": float(r.get("Lead_Time_Days", 14.0)),
                "order_status": str(r.get("Order_Status", "Completed")),
                "on_time_delivery_flag": str(r.get("On_Time_Delivery_Flag", "Yes"))
            })

        order_df = pd.DataFrame(records)
        order_df["order_line_item"] = order_df.groupby("order_number").cumcount() + 1
        return order_df

    def build_fact_machine_telemetry(self) -> pd.DataFrame:
        """Transforms Machine_Process_Readings into fact_machine_telemetry."""
        df = self.sheets["Machine_Process_Readings"].copy()

        df["reading_date_key"] = df["Reading_Timestamp"].apply(self._to_date_key)
        df["machine_key"] = df["Machine_ID"].apply(lambda m: self.sk_lookups["machine"].get(str(m), 1))
        df["work_order_key"] = df["Work_Order_Number"].apply(lambda w: self.sk_lookups["work_order"].get(str(w), 1))

        col_map = {
            "Reading_ID": "reading_id",
            "Reading_Timestamp": "reading_timestamp",
            "Spindle_Speed_RPM": "spindle_speed_rpm",
            "Feed_Rate_mm_min": "feed_rate_mm_min",
            "Tool_Wear_Percent": "tool_wear_percent",
            "Tool_Changes_Count": "tool_changes_count",
            "Coolant_Flow_L_min": "coolant_flow_l_min",
            "Hydraulic_Pressure_Bar": "hydraulic_pressure_bar",
            "Pneumatic_Pressure_Bar": "pneumatic_pressure_bar",
            "Motor_Temperature_C": "motor_temperature_c",
            "Ambient_Temperature_C": "ambient_temperature_c",
            "Ambient_Humidity_Percent": "ambient_humidity_percent",
            "Vibration_mm_s": "vibration_mm_s",
            "Noise_Level_dB": "noise_level_db",
            "Power_Consumption_kWh": "power_consumption_kwh",
            "Voltage_V": "voltage_v",
            "Current_A": "current_a",
            "Robot_Cycle_Count": "robot_cycle_count",
            "Robot_Error_Count": "robot_error_count",
            "Data_Quality_Score": "data_quality_score"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["reading_date_key"] = df["reading_date_key"]
        renamed["machine_key"] = df["machine_key"]
        renamed["work_order_key"] = df["work_order_key"]
        renamed["telemetry_key"] = range(1, len(renamed) + 1)
        return renamed

    def build_fact_quality_inspections(self) -> pd.DataFrame:
        """Transforms Quality_Inspections and Quality_Measurements into fact_quality_inspections."""
        qi_df = self.sheets["Quality_Inspections"].copy()
        qm_df = self.sheets.get("Quality_Measurements", pd.DataFrame()).copy()

        # Merge on Inspection_ID
        if not qm_df.empty:
            merged = pd.merge(qi_df, qm_df, on=["Inspection_ID", "Work_Order_Number"], how="left")
        else:
            merged = qi_df

        total_colors = len(self.dim_color_df) if not self.dim_color_df.empty else 1

        merged["inspection_date_key"] = merged["Inspection_Timestamp"].apply(self._to_date_key)
        merged["work_order_key"] = merged["Work_Order_Number"].apply(lambda w: self.sk_lookups["work_order"].get(str(w), 1))
        merged["product_key"] = merged["Product_SKU"].apply(lambda p: self.sk_lookups["product"].get(str(p), 1))
        merged["defect_key"] = merged["Primary_Defect_Type"].apply(lambda d: self.sk_lookups["defect"].get(str(d), 1))
        merged["color_key"] = merged.index.map(lambda i: (i % total_colors) + 1)

        col_map = {
            "Inspection_ID": "inspection_id",
            "QC_Result": "qc_result",
            "Defect_Count": "defect_count",
            "Sample_Size": "sample_size",
            "Dimension_1_Nominal_mm": "dimension_1_nominal_mm",
            "Dimension_1_Actual_mm": "dimension_1_actual_mm",
            "Dimension_1_Tolerance_mm": "dimension_1_tolerance_mm",
            "Dimension_2_Nominal_mm": "dimension_2_nominal_mm",
            "Dimension_2_Actual_mm": "dimension_2_actual_mm",
            "Dimension_2_Tolerance_mm": "dimension_2_tolerance_mm",
            "Weight_Nominal_g": "weight_nominal_g",
            "Weight_Actual_g": "weight_actual_g",
            "Hardness_HRC": "hardness_hrc",
            "Tensile_Strength_MPa": "tensile_strength_mpa",
            "SPC_Cpk": "spc_cpk",
            "SPC_Ppk": "spc_ppk",
            "Inspection_Duration_Min": "inspection_duration_min"
        }
        renamed = merged[[c for c in col_map.keys() if c in merged.columns]].rename(columns=col_map)
        renamed["inspection_date_key"] = merged["inspection_date_key"]
        renamed["work_order_key"] = merged["work_order_key"]
        renamed["product_key"] = merged["product_key"]
        renamed["defect_key"] = merged["defect_key"]
        renamed["color_key"] = merged["color_key"]
        renamed["quality_fact_key"] = range(1, len(renamed) + 1)
        return renamed

    def build_fact_labor_performance(self) -> pd.DataFrame:
        """Transforms Labor_Records into fact_labor_performance."""
        df = self.sheets["Labor_Records"].copy()

        df["work_date_key"] = 20240811  # Standard batch reference or derived
        df["operator_key"] = df["Operator_ID"].apply(lambda o: self.sk_lookups["operator"].get(str(o), 1))
        df["work_order_key"] = df["Work_Order_Number"].apply(lambda w: self.sk_lookups["work_order"].get(str(w), 1))

        # Compute total labor cost
        hours = df["Hours_Worked"].fillna(8.0)
        ot = df["Overtime_Hours"].fillna(0.0)
        rate = df["Labor_Rate_USD_per_hr"].fillna(35.0)
        df["total_labor_cost_usd"] = (hours * rate) + (ot * rate * 1.5)

        col_map = {
            "Labor_ID": "labor_id",
            "Hours_Worked": "hours_worked",
            "Overtime_Hours": "overtime_hours",
            "Labor_Rate_USD_per_hr": "labor_rate_usd_per_hr",
            "total_labor_cost_usd": "total_labor_cost_usd",
            "PPE_Compliance_Percent": "ppe_compliance_percent",
            "Standard_Labor_Hours": "standard_labor_hours",
            "Labor_Efficiency_Percent": "labor_efficiency_percent",
            "Safety_Incident_Flag": "safety_incident_flag",
            "Near_Miss_Flag": "near_miss_flag",
            "Absenteeism_Flag": "absenteeism_flag"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["work_date_key"] = df["work_date_key"]
        renamed["operator_key"] = df["operator_key"]
        renamed["work_order_key"] = df["work_order_key"]
        renamed["labor_fact_key"] = range(1, len(renamed) + 1)
        return renamed

    def build_fact_cost_financials(self) -> pd.DataFrame:
        """Transforms Cost_Records into fact_cost_financials."""
        df = self.sheets["Cost_Records"].copy()

        df["fiscal_date_key"] = 20240811
        df["work_order_key"] = df["Work_Order_Number"].apply(lambda w: self.sk_lookups["work_order"].get(str(w), 1))

        col_map = {
            "Cost_ID": "cost_id",
            "Material_Cost_USD": "material_cost_usd",
            "Labor_Cost_USD": "labor_cost_usd",
            "Overhead_Cost_USD": "overhead_cost_usd",
            "Tooling_Cost_USD": "tooling_cost_usd",
            "Energy_Cost_USD": "energy_cost_usd",
            "Total_Unit_Cost_USD": "total_unit_cost_usd",
            "Standard_Cost_USD": "standard_cost_usd",
            "Cost_Variance_USD": "cost_variance_usd",
            "Scrap_Cost_USD": "scrap_cost_usd",
            "Selling_Price_USD": "selling_price_usd",
            "Gross_Margin_Percent": "gross_margin_percent",
            "Budget_Variance_Percent": "budget_variance_percent",
            "Freight_Cost_USD": "freight_cost_usd",
            "Customs_Duty_USD": "customs_duty_usd",
            "Warranty_Cost_USD": "warranty_cost_usd",
            "ROI_Percent": "roi_percent"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["fiscal_date_key"] = df["fiscal_date_key"]
        renamed["work_order_key"] = df["work_order_key"]
        renamed["cost_fact_key"] = range(1, len(renamed) + 1)
        return renamed

    def build_fact_procurement(self) -> pd.DataFrame:
        """Transforms Purchase_Orders into fact_procurement."""
        df = self.sheets["Purchase_Orders"].copy()

        df["order_date_key"] = df["Order_Date"].apply(self._to_date_key)
        df["delivery_date_key"] = df["Actual_Delivery_Date"].apply(self._to_date_key)
        df["supplier_key"] = df["Supplier_ID"].apply(lambda s: self.sk_lookups["supplier"].get(str(s), 1))
        df["material_key"] = df["Material_ID"].apply(lambda m: self.sk_lookups["material"].get(str(m), 1))

        col_map = {
            "PO_Number": "po_number",
            "PO_Line_Item": "po_line_item",
            "Order_Quantity_kg": "order_quantity_kg",
            "Unit_Price_USD": "unit_price_usd",
            "Total_PO_Value_USD": "total_po_value_usd",
            "Lead_Time_Days": "lead_time_days",
            "Freight_Cost_USD": "freight_cost_usd",
            "Customs_Duty_USD": "customs_duty_usd",
            "On_Time_Delivery_Flag": "on_time_delivery_flag"
        }
        renamed = df[[c for c in col_map.keys() if c in df.columns]].rename(columns=col_map)
        renamed["order_date_key"] = df["order_date_key"]
        renamed["delivery_date_key"] = df["delivery_date_key"]
        renamed["supplier_key"] = df["supplier_key"]
        renamed["material_key"] = df["material_key"]
        renamed["po_line_item"] = renamed.groupby("po_number").cumcount() + 1
        renamed["procurement_key"] = range(1, len(renamed) + 1)
        return renamed

    def transform_all(self) -> Dict[str, pd.DataFrame]:
        """Executes full star schema transformation pipeline and returns all table DataFrames."""
        tables: Dict[str, pd.DataFrame] = {}

        # 1. Build Dimensions (Order matters for surrogate key lookups)
        tables["dim_date"] = self.build_dim_date()
        tables["dim_location"] = self.build_dim_location()
        tables["dim_color"] = self.build_dim_color()
        tables["dim_plant"] = self.build_dim_plant()
        tables["dim_production_line"] = self.build_dim_production_line()
        tables["dim_product"] = self.build_dim_product()
        tables["dim_machine"] = self.build_dim_machine()
        tables["dim_operator"] = self.build_dim_operator()
        tables["dim_supplier"] = self.build_dim_supplier()
        tables["dim_material"] = self.build_dim_material()
        tables["dim_material_sales"] = self.build_dim_material_sales()
        tables["dim_defect_catalog"] = self.build_dim_defect_catalog()

        # 2. Build Fact Tables
        tables["fact_work_orders"] = self.build_fact_work_orders()
        tables["fact_sales_detail"] = self.build_fact_sales_detail()
        tables["fact_order_detail"] = self.build_fact_order_detail()
        tables["fact_machine_telemetry"] = self.build_fact_machine_telemetry()
        tables["fact_quality_inspections"] = self.build_fact_quality_inspections()
        tables["fact_labor_performance"] = self.build_fact_labor_performance()
        tables["fact_cost_financials"] = self.build_fact_cost_financials()
        tables["fact_procurement"] = self.build_fact_procurement()

        return tables
