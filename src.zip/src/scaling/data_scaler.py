"""
Manufacturing Data Scaling Engine:
Synthesizes and scales relational manufacturing data by Nx factor while preserving
strict referential integrity, primary keys, foreign key constraints, and distributions.
"""
import copy
import datetime
import os
import random
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
import pandas as pd
import openpyxl
import sqlalchemy as sa


class ManufacturingDataScaler:
    """Scales relational manufacturing tables with full referential integrity."""

    def __init__(self, seed_file: str = "manufacturing_relational_data.xlsx"):
        self.seed_file = seed_file
        self.seed_sheets: Dict[str, pd.DataFrame] = {}

    def load_seed(self) -> None:
        """Loads all sheets from the seed Excel workbook."""
        wb = openpyxl.load_workbook(self.seed_file, read_only=True)
        for s in wb.sheetnames:
            if s != "Manufacturing_Data":
                self.seed_sheets[s] = pd.read_excel(self.seed_file, sheet_name=s)
        wb.close()

    def scale_dataset(self, multiplier: int = 5) -> Dict[str, pd.DataFrame]:
        """
        Scales the relational dataset by multiplier factor.
        Example: multiplier=5 scales 1,000 work orders to 5,000 work orders.
        """
        if not self.seed_sheets:
            self.load_seed()

        scaled: Dict[str, pd.DataFrame] = {}
        print(f"[SCALE] Scaling manufacturing dataset by {multiplier}x multiplier...")

        # 1. Scale Plants (expand by multiplier or copy with new IDs)
        plants_df = self.seed_sheets["Plants"].copy()
        new_plants = [plants_df]
        for m in range(1, multiplier):
            df_copy = plants_df.copy()
            df_copy["Plant_Code"] = df_copy["Plant_Code"].apply(lambda p: f"{p}_X{m}")
            df_copy["Plant_Name"] = df_copy["Plant_Name"].apply(lambda n: f"{n} - Campus {m+1}")
            new_plants.append(df_copy)
        scaled_plants = pd.concat(new_plants, ignore_index=True)
        scaled["Plants"] = scaled_plants
        plant_codes = scaled_plants["Plant_Code"].tolist()

        # 2. Scale Production Lines (link to valid scaled plants)
        lines_df = self.seed_sheets["Production_Lines"].copy()
        new_lines = []
        line_counter = 0
        for p_code in plant_codes:
            num_lines = random.randint(2, 4)
            for _ in range(num_lines):
                base_line = lines_df.iloc[line_counter % len(lines_df)].to_dict()
                base_line["Line_ID"] = f"LINE-{line_counter:06d}"
                base_line["Plant_Code"] = p_code
                new_lines.append(base_line)
                line_counter += 1
        scaled_lines = pd.DataFrame(new_lines)
        scaled["Production_Lines"] = scaled_lines
        line_ids = scaled_lines["Line_ID"].tolist()
        line_to_plant = dict(zip(scaled_lines["Line_ID"], scaled_lines["Plant_Code"]))

        # 3. Scale Products
        prods_df = self.seed_sheets["Products"].copy()
        new_prods = [prods_df]
        for m in range(1, multiplier):
            df_copy = prods_df.copy()
            df_copy["Product_SKU"] = df_copy["Product_SKU"].apply(lambda s: f"{s}-V{m}")
            df_copy["Product_Name"] = df_copy["Product_Name"].apply(lambda n: f"{n} Gen-{m+1}")
            new_prods.append(df_copy)
        scaled_prods = pd.concat(new_prods, ignore_index=True)
        scaled["Products"] = scaled_prods
        prod_skus = scaled_prods["Product_SKU"].tolist()

        # 4. Scale Machines (link to valid scaled lines)
        mch_df = self.seed_sheets["Machines"].copy()
        new_mchs = []
        mch_counter = 0
        for l_id in line_ids:
            num_mchs = random.randint(2, 5)
            for _ in range(num_mchs):
                base_mch = mch_df.iloc[mch_counter % len(mch_df)].to_dict()
                base_mch["Machine_ID"] = f"MCH-{mch_counter:06d}"
                base_mch["Line_ID"] = l_id
                new_mchs.append(base_mch)
                mch_counter += 1
        scaled_mchs = pd.DataFrame(new_mchs)
        scaled["Machines"] = scaled_mchs
        mch_ids = scaled_mchs["Machine_ID"].tolist()
        line_to_machines: Dict[str, List[str]] = {}
        for _, r in scaled_mchs.iterrows():
            line_to_machines.setdefault(r["Line_ID"], []).append(r["Machine_ID"])

        # 5. Scale Operators
        opr_df = self.seed_sheets["Operators"].copy()
        new_oprs = [opr_df]
        for m in range(1, multiplier):
            df_copy = opr_df.copy()
            df_copy["Operator_ID"] = df_copy["Operator_ID"].apply(lambda o: f"{o}-X{m}")
            new_oprs.append(df_copy)
        scaled_oprs = pd.concat(new_oprs, ignore_index=True)
        scaled["Operators"] = scaled_oprs
        opr_ids = scaled_oprs["Operator_ID"].tolist()

        # 6. Scale Suppliers
        sup_df = self.seed_sheets["Suppliers"].copy()
        new_sups = [sup_df]
        for m in range(1, multiplier):
            df_copy = sup_df.copy()
            df_copy["Supplier_ID"] = df_copy["Supplier_ID"].apply(lambda s: f"{s}-X{m}")
            new_sups.append(df_copy)
        scaled_sups = pd.concat(new_sups, ignore_index=True)
        scaled["Suppliers"] = scaled_sups
        sup_ids = scaled_sups["Supplier_ID"].tolist()

        # 7. Scale Materials (link to valid suppliers)
        mat_df = self.seed_sheets["Materials"].copy()
        new_mats = []
        mat_counter = 0
        for s_id in sup_ids:
            for _ in range(random.randint(1, 3)):
                base_mat = mat_df.iloc[mat_counter % len(mat_df)].to_dict()
                base_mat["Material_ID"] = f"MAT-{mat_counter:06d}"
                base_mat["Supplier_ID"] = s_id
                new_mats.append(base_mat)
                mat_counter += 1
        scaled_mats = pd.DataFrame(new_mats)
        scaled["Materials"] = scaled_mats
        mat_ids = scaled_mats["Material_ID"].tolist()

        # 8. Scale Work Orders (Main Operational Fact Grain)
        wo_df = self.seed_sheets["Work_Orders"].copy()
        target_wo_count = len(wo_df) * multiplier
        new_wos = []
        
        base_date = datetime.date(2024, 1, 1)
        for i in range(target_wo_count):
            base_wo = wo_df.iloc[i % len(wo_df)].to_dict()
            wo_num = f"WO-{2024000 + i:07d}"
            base_wo["Work_Order_Number"] = wo_num
            
            chosen_line = random.choice(line_ids)
            base_wo["Line_ID"] = chosen_line
            base_wo["Plant_Code"] = line_to_plant[chosen_line]
            base_wo["Product_SKU"] = random.choice(prod_skus)
            
            order_dt = base_date + datetime.timedelta(days=int(i * (365 * 2) / target_wo_count))
            base_wo["Order_Date"] = order_dt
            
            planned = float(random.randint(50, 500))
            good = float(int(planned * random.uniform(0.90, 0.99)))
            scrap = float(int(planned * random.uniform(0.01, 0.08)))
            rework = max(0.0, planned - good - scrap)
            produced = good + scrap + rework
            
            base_wo["Planned_Quantity"] = planned
            base_wo["Produced_Quantity"] = produced
            base_wo["Good_Quantity"] = good
            base_wo["Scrap_Quantity"] = scrap
            base_wo["Rework_Quantity"] = rework
            base_wo["Yield_Percent"] = round((good / produced) * 100, 2) if produced > 0 else 100.0
            base_wo["Scrap_Rate_Percent"] = round((scrap / produced) * 100, 2) if produced > 0 else 0.0

            new_wos.append(base_wo)

        scaled_wos = pd.DataFrame(new_wos)
        scaled["Work_Orders"] = scaled_wos
        wo_numbers = scaled_wos["Work_Order_Number"].tolist()

        # 9. Scale Machine Process Readings
        readings_df = self.seed_sheets["Machine_Process_Readings"].copy()
        new_readings = []
        for i, wo_r in enumerate(new_wos):
            base_rd = readings_df.iloc[i % len(readings_df)].to_dict()
            base_rd["Reading_ID"] = f"RD-{800000 + i:07d}"
            base_rd["Work_Order_Number"] = wo_r["Work_Order_Number"]
            line = wo_r["Line_ID"]
            mchs_for_line = line_to_machines.get(line, mch_ids)
            base_rd["Machine_ID"] = random.choice(mchs_for_line)
            base_rd["Reading_Timestamp"] = str(wo_r["Order_Date"])
            new_readings.append(base_rd)
        scaled["Machine_Process_Readings"] = pd.DataFrame(new_readings)

        # 10. Scale Maintenance Records
        maint_df = self.seed_sheets["Maintenance_Records"].copy()
        new_maint = []
        for i, wo_r in enumerate(new_wos):
            if i % 3 == 0:
                base_mt = maint_df.iloc[len(new_maint) % len(maint_df)].to_dict()
                base_mt["Maintenance_ID"] = f"MR-{900000 + len(new_maint):07d}"
                base_mt["Work_Order_Number"] = wo_r["Work_Order_Number"]
                base_mt["Machine_ID"] = random.choice(mch_ids)
                new_maint.append(base_mt)
        scaled["Maintenance_Records"] = pd.DataFrame(new_maint)

        # 11. Scale Quality Inspections & Measurements
        qi_df = self.seed_sheets["Quality_Inspections"].copy()
        qm_df = self.seed_sheets.get("Quality_Measurements", pd.DataFrame()).copy()
        new_qi = []
        new_qm = []
        for i, wo_r in enumerate(new_wos):
            insp_id = f"QI-{100000 + i:07d}"
            base_qi = qi_df.iloc[i % len(qi_df)].to_dict()
            base_qi["Inspection_ID"] = insp_id
            base_qi["Work_Order_Number"] = wo_r["Work_Order_Number"]
            base_qi["Product_SKU"] = wo_r["Product_SKU"]
            new_qi.append(base_qi)

            if not qm_df.empty:
                base_qm = qm_df.iloc[i % len(qm_df)].to_dict()
                base_qm["Measurement_ID"] = f"QM-{200000 + i:07d}"
                base_qm["Inspection_ID"] = insp_id
                base_qm["Work_Order_Number"] = wo_r["Work_Order_Number"]
                new_qm.append(base_qm)

        scaled["Quality_Inspections"] = pd.DataFrame(new_qi)
        scaled["Quality_Measurements"] = pd.DataFrame(new_qm)

        # 12. Scale Labor Records
        labor_df = self.seed_sheets["Labor_Records"].copy()
        new_labor = []
        for i, wo_r in enumerate(new_wos):
            base_lb = labor_df.iloc[i % len(labor_df)].to_dict()
            base_lb["Labor_ID"] = f"LB-{300000 + i:07d}"
            base_lb["Work_Order_Number"] = wo_r["Work_Order_Number"]
            base_lb["Operator_ID"] = random.choice(opr_ids)
            new_labor.append(base_lb)
        scaled["Labor_Records"] = pd.DataFrame(new_labor)

        # 13. Scale Cost Records
        cost_df = self.seed_sheets["Cost_Records"].copy()
        new_costs = []
        for i, wo_r in enumerate(new_wos):
            base_cr = cost_df.iloc[i % len(cost_df)].to_dict()
            base_cr["Cost_ID"] = f"CR-{400000 + i:07d}"
            base_cr["Work_Order_Number"] = wo_r["Work_Order_Number"]
            new_costs.append(base_cr)
        scaled["Cost_Records"] = pd.DataFrame(new_costs)

        # 14. Scale Purchase Orders
        po_df = self.seed_sheets["Purchase_Orders"].copy()
        new_pos = []
        for i in range(len(po_df) * multiplier):
            base_po = po_df.iloc[i % len(po_df)].to_dict()
            base_po["PO_Number"] = f"PO-{700000 + i:07d}"
            base_po["Supplier_ID"] = random.choice(sup_ids)
            base_po["Material_ID"] = random.choice(mat_ids)
            new_pos.append(base_po)
        scaled["Purchase_Orders"] = pd.DataFrame(new_pos)

        print("[OK] Scaled tables generated:")
        for name, df_s in scaled.items():
            print(f"    - {name:<25}: {len(df_s):>6} rows")

        return scaled

    def save_scaled_database(self, scaled_sheets: Dict[str, pd.DataFrame], db_path: str = "data/scaled_manufacturing_relational.db") -> None:
        """Saves scaled relational data to SQLite database."""
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        engine = sa.create_engine(f"sqlite:///{db_path}")
        with engine.begin() as conn:
            for name, df in scaled_sheets.items():
                df.to_sql(name, con=conn, if_exists="replace", index=False, chunksize=1000)
        print(f"[SAVED] Scaled relational database saved to: {db_path}")
