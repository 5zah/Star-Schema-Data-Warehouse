"""
Enterprise ETL Testing, Data Warehouse Migration & Multi-Database Reconciliation Engine
"""
__version__ = "2.0.0"
