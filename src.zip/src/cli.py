"""
Unified CLI Entry Point for ETL Migration, Data Scaling, Reconciliation, and Testing.
"""
import argparse
import json
import os
import sys
from typing import Optional

# Ensure UTF-8 output
if sys.stdout and hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

from .warehouse.migration_pipeline import MigrationPipeline
from .scaling.data_scaler import ManufacturingDataScaler
from .reconciliation.engine import ReconciliationEngine
from .reporting.html_reporter import HTMLReporter
from .reporting.excel_reporter import ExcelReporter
from .reporting.markdown_reporter import MarkdownReporter


def run_migration_action(args: argparse.Namespace) -> None:
    pipeline = MigrationPipeline(
        relational_excel_path=args.relational_excel,
        flat_excel_path=args.flat_excel,
        target_db_conn_str=args.target_db
    )
    pipeline.run_migration(drop_existing=True)


def run_scaling_action(args: argparse.Namespace) -> None:
    scaler = ManufacturingDataScaler(seed_file=args.relational_excel)
    scaled_sheets = scaler.scale_dataset(multiplier=args.multiplier)
    scaler.save_scaled_database(scaled_sheets, db_path=args.scale_output_db)


def run_reconciliation_action(args: argparse.Namespace) -> dict:
    engine = ReconciliationEngine(config_path=args.config)
    results = engine.run_all_validations()

    # Generate Reports
    os.makedirs(args.reports_dir, exist_ok=True)
    html_path = os.path.join(args.reports_dir, "Reconciliation_Report.html")
    excel_path = os.path.join(args.reports_dir, "Reconciliation_Report.xlsx")
    md_path = os.path.join(args.reports_dir, "Reconciliation_Summary.md")
    json_path = os.path.join(args.reports_dir, "reconciliation_results.json")

    HTMLReporter(results).generate_html(html_path)
    ExcelReporter(results).generate_excel(excel_path)
    MarkdownReporter(results).generate_markdown(md_path)

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=str)
    print(f"[REPORT] JSON Machine-Readable Results saved at: {json_path}")

    return results


def run_anomaly_test_action(args: argparse.Namespace) -> None:
    """Deliberately introduces controlled anomalies in a cloned test database to verify detection."""
    import sqlalchemy as sa
    from sqlalchemy import text

    print("====================================================================")
    print("[TEST] RUNNING CONTROLLED ANOMALY INJECTION & DETECTION TEST")
    print("====================================================================")

    # 1. First ensure DWH is migrated
    print("Step 1: Preparing clean baseline DWH...")
    pipeline = MigrationPipeline(
        relational_excel_path=args.relational_excel,
        flat_excel_path=args.flat_excel,
        target_db_conn_str="sqlite:///data/anomaly_test_dwh.db"
    )
    pipeline.run_migration(drop_existing=True)

    # 2. Inject anomalies into anomaly_test_dwh.db
    print("\nStep 2: Injecting controlled anomalies into test DWH:")
    engine = sa.create_engine("sqlite:///data/anomaly_test_dwh.db")
    with engine.begin() as conn:
        # Anomaly 1: Cell attribute mismatch (corrupt planned quantity on WO-2023000)
        conn.execute(text("UPDATE fact_work_orders SET planned_quantity = 99999.0 WHERE work_order_number = 'WO-2023000'"))
        print("   [WARN] Injected Anomaly 1: Corrupted planned_quantity on WO-2023000 to 99999.0")

        # Anomaly 2: Cell attribute string mismatch (corrupt order_status on WO-2023005)
        conn.execute(text("UPDATE fact_work_orders SET order_status = 'CORRUPTED_STATUS' WHERE work_order_number = 'WO-2023005'"))
        print("   [WARN] Injected Anomaly 2: Corrupted order_status on WO-2023005 to 'CORRUPTED_STATUS'")

        # Anomaly 3: Volume drop anomaly (delete 2 rows)
        conn.execute(text("DELETE FROM fact_work_orders WHERE work_order_number IN ('WO-2023010', 'WO-2023011')"))
        print("   [WARN] Injected Anomaly 3: Deleted 2 work order records to trigger volume delta")

    # 3. Create temporary reconciliation config targeting anomaly DB
    temp_config_path = "config/anomaly_test_config.yaml"
    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml_load(f.read())
    
    cfg["databases"]["target_dwh"]["connection_string"] = "sqlite:///data/anomaly_test_dwh.db"
    with open(temp_config_path, "w", encoding="utf-8") as f:
        import yaml
        yaml.dump(cfg, f)

    # 4. Run reconciliation engine
    print("\nStep 3: Executing Reconciliation Engine against Anomalous Target...")
    rec_engine = ReconciliationEngine(config_path=temp_config_path)
    results = rec_engine.run_all_validations()

    # 5. Check if all 3 anomalies were caught
    print("\nStep 4: Verifying Anomaly Detection Results:")
    vol_caught = any(v["rule_name"] == "Work Orders Fact Volume" and v["diff"] == -2 for v in results["volume_reconciliation"])
    att_test = next((a for a in results["attribute_reconciliation"] if a["validation_name"] == "Work Orders Attribute Validation"), None)
    
    mismatches = att_test.get("mismatch_sample", []) if att_test else []
    caught_wo0 = any(m.get("key") == "WO-2023000" for m in mismatches)
    caught_wo5 = any(m.get("key") == "WO-2023005" for m in mismatches)

    print(f"   {'[PASS]' if vol_caught else '[FAIL]'} Volume Anomaly Caught (2 dropped records): {vol_caught}")
    print(f"   {'[PASS]' if caught_wo0 else '[FAIL]'} Attribute Numeric Anomaly Caught (WO-2023000): {caught_wo0}")
    print(f"   {'[PASS]' if caught_wo5 else '[FAIL]'} Attribute String Anomaly Caught (WO-2023005): {caught_wo5}")

    if vol_caught and caught_wo0 and caught_wo5:
        print("\n[SUCCESS] ANOMALY DETECTION TEST PASSED: 100% of injected discrepancies accurately detected!")
    else:
        print("\n[FAILED] Anomaly test failed to catch some injected discrepancies.")


def yaml_load(text_str: str) -> dict:
    import yaml
    return yaml.safe_load(text_str)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Enterprise ETL Migration, Scaling & Reconciliation Framework")
    parser.add_argument(
        "--action",
        choices=["migrate", "scale", "reconcile", "test-anomaly", "all"],
        default="all",
        help="Action to execute"
    )
    parser.add_argument(
        "--relational-excel",
        default="manufacturing_relational_data.xlsx",
        help="Path to relational source excel file"
    )
    parser.add_argument(
        "--flat-excel",
        default="manufacturing_mock_data.xlsx",
        help="Path to flat source excel file"
    )
    parser.add_argument(
        "--target-db",
        default="sqlite:///data/manufacturing_dwh.db",
        help="Connection string for Target Data Warehouse"
    )
    parser.add_argument(
        "--config",
        default="config/reconciliation_config.yaml",
        help="Path to reconciliation config YAML"
    )
    parser.add_argument(
        "--multiplier",
        type=int,
        default=5,
        help="Data scaling multiplier (e.g. 5 = 5x data)"
    )
    parser.add_argument(
        "--scale-output-db",
        default="data/scaled_manufacturing_relational.db",
        help="Output SQLite file for scaled dataset"
    )
    parser.add_argument(
        "--reports-dir",
        default="reports",
        help="Output directory for generated reports"
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.action == "migrate":
        run_migration_action(args)
    elif args.action == "scale":
        run_scaling_action(args)
    elif args.action == "reconcile":
        run_reconciliation_action(args)
    elif args.action == "test-anomaly":
        run_anomaly_test_action(args)
    elif args.action == "all":
        print("[START] Executing Full End-to-End Pipeline...\n")
        run_migration_action(args)
        run_scaling_action(args)
        results = run_reconciliation_action(args)
        run_anomaly_test_action(args)
        print("\n[COMPLETE] ALL PIPELINE PHASES COMPLETED SUCCESSFULLY!")


if __name__ == "__main__":
    main()
