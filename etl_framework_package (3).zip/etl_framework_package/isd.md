# Integration Specification Document (ISD)
## Enterprise ETL Testing Framework & Multi-Database Reconciliation Architecture

This document serves as the **Integration Specification Document (ISD)** and walkthrough guide. It outlines the data flow, architecture, manual-to-automated validation mapping, and deployment patterns across local, Azure, and AWS environments.

---

## 1. 🏗️ High-Level System Architecture & Component Mapping

The framework is structured as a modular Python package that abstracts database connections, data transformations, scaling, and test execution.

```
                  ┌──────────────────────────────────────────────┐
                  │          INPUT LAYER (Raw Source Data)       │
                  │  - Local Excel/CSV   - Azure SQL   - AWS S3  │
                  └──────────────────────┬───────────────────────┘
                                         │
                                         ▼
                  ┌──────────────────────────────────────────────┐
                  │            CONNECTOR FACTORY LAYER           │
                  │  - SQLAlchemy   - Excel   - CSV/Parquet      │
                  └──────────────────────┬───────────────────────┘
                                         │ Load Dataframes
                                         ▼
                  ┌──────────────────────────────────────────────┐
                  │            RECONCILIATION ENGINE             │
                  │  - Volume   - Attribute  - Aggregate  - MSC  │
                  └──────────────────────┬───────────────────────┘
                                         │ Generate Metrics
                                         ▼
                  ┌──────────────────────────────────────────────┐
                  │           REPORTING & PIPELINE UI            │
                  │  - HTML   - Excel Tabular  - Web Dashboard   │
                  └──────────────────────────────────────────────┘
```

### Folder Structure & Component Purpose

| Folder / File | Role | Purpose |
| :--- | :--- | :--- |
| **`config/`** | Configuration | Contains SQL DDL scripts, mapping logic, scaling configuration, and the dynamic YAML reconciliation mapping rules. |
| **`data/`** | Databases | Storage for local target databases (`manufacturing_dwh.db`) and anomaly testing database clones. |
| **`reports/`** | Artifacts | Output directory for all automatically generated HTML, Excel, and JSON test result scorecards. |
| **`src/connectors/`** | Connectivity | Abstracts connection methods. Allows the engine to query files or relational databases (local or cloud) identically using pandas DataFrames. |
| **`src/reconciliation/`** | Validation | Contains the core validation logic for the 4 scopes: Volume, Attribute, Aggregate, and Multi-Source Consistency. |
| **`src/reporting/`** | Output | Transforms raw validation results into styled dashboards, structured workbooks, and Markdown summaries. |
| **`src/warehouse/`** | Migration | Runs the DDL schema builder, handles ETL pipelines, and transforms relational source files to Star Schema facts and dimensions. |
| **`src/scaling/`** | Scaling | Synthesizes and scales seed transactional data to run volume/load tests while keeping primary and foreign keys referentially intact. |
| **`src/web/`** | User Interface | Flask server and HTML dashboard allowing users to trigger migration, scaling, and reconciliation through a web browser. |
| **`tests/`** | QA Unit Tests | Integrates 14 formal test suites (7 passing baseline test cases and 7 failing anomaly detection test cases) using Python's `unittest`. |
| **`main.py`** | Entry Point | The execution terminal hook. Calls `src/cli.py` to route user inputs. |

---

## 2. 🌐 Multi-Environment Deployment (Where & How Things Happen)

The reconciliation framework can run in three different configurations depending on your infrastructure:

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│                                   DEPLOYMENT MODES                                          │
├───────────────────────┬───────────────────────────────────┬─────────────────────────────────┤
│ Local Workstation     │ Microsoft Azure                   │ Amazon Web Services (AWS)       │
├───────────────────────┼───────────────────────────────────┼─────────────────────────────────┤
│ • Source: Excel files │ • Source: Azure SQL Database      │ • Source: RDS (PostgreSQL/MySQL)│
│ • Target: SQLite DB   │ • Target: Snowflake on Azure      │ • Target: Snowflake on AWS      │
│ • Engine: Local CLI/UI│ • Engine: Azure VM or Func App    │ • Engine: AWS ECS or Lambda     │
└───────────────────────┴───────────────────────────────────┴─────────────────────────────────┘
```

### 1. Microsoft Azure Infrastructure Flow
- **Raw Transactional Source:** Data is inserted into an **Azure SQL Database** (OLTP).
- **Target Data Warehouse:** Data is migrated into **Snowflake** (hosted on the Azure cloud platform).
- **Reconciliation Runner:** A Python script runs in an **Azure Function App** or an **Azure Virtual Machine (VM)**. It retrieves connection strings from **Azure Key Vault**, connects to both databases using the `SQLAlchemyConnector`, runs validation tests, and saves mismatch reports to **Azure Blob Storage**.

### 2. Amazon Web Services (AWS) Infrastructure Flow
- **Raw Transactional Source:** Data resides in an **AWS RDS (PostgreSQL or MySQL)** instance.
- **Target Data Warehouse:** Data is loaded into **Snowflake** (hosted on AWS).
- **Reconciliation Runner:** The framework runs as an automated job inside an **AWS ECS Fargate container** or **AWS Lambda**. It connects to both databases, performs validation, and uploads generated reports to an **Amazon S3 Bucket** for download.

---

## 3. 🧪 Manual to Automated Test Case Mapping

Here is how manual test steps are mapped to automated Python logic in our framework:

### Test Scenario 1: Volume Reconciliation (Row Counts)
- **Manual Test Method:** Open the source database tool, execute `SELECT COUNT(*) FROM source_table`, write down the number. Open target database tool, run `SELECT COUNT(*) FROM target_table`, compare the numbers, check for differences.
- **Automated Python Logic:** Implemented in [`src/reconciliation/volume_validator.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/src/reconciliation/volume_validator.py). The engine queries both databases dynamically, calculates the difference (`diff = target_count - source_count`), matches missing keys via set difference (`set(source_keys) - set(target_keys)`), and flags a `FAIL` status if the difference exceeds the configured tolerance percentage.

### Test Scenario 2: Attribute-Level Validation (Cell-by-Cell Check)
- **Manual Test Method:** Export 100 rows from source to CSV. Export corresponding 100 rows from target. Align rows by ID, compare values column-by-column in Excel using `VLOOKUP` or `=A2=B2` formulas.
- **Automated Python Logic:** Implemented in [`src/reconciliation/attribute_validator.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/src/reconciliation/attribute_validator.py). The engine fetches both datasets, merges them on the defined primary keys, normalizes string casings, strips trailing whitespace, applies floating point tolerances (`|src - tgt| <= atol + rtol * |src|`), identifies mismatches, and logs the exact row keys and column names that failed.

### Test Scenario 3: Aggregate Measure Validation
- **Manual Test Method:** Run `SELECT SUM(amount) FROM source` and compare it with the analytical value in the target facts table to check for currency or calculation discrepancies.
- **Automated Python Logic:** Implemented in [`src/reconciliation/aggregate_validator.py`](file:///c:/Users/faiza/Downloads/Testing%20Profile/ETL%20testing/src/reconciliation/aggregate_validator.py). The engine runs dynamic aggregation functions (`sum`, `avg`, `min`, `max`, `stddev`) on the target database, compares them against the source sums/averages, and checks if they match within the specified mathematical tolerance.

---

## 4. 🚀 The Initial Stage: How to Proceed with a File

If you want to validate a new data file manually or run the automation pipeline from scratch, follow these step-by-step phases:

### Phase 1: Ingesting the File
Place your Excel data files in the root folder:
- **Relational Source Workbook:** `manufacturing_relational_data.xlsx` (contains normalized tables).
- **Flat Mock Data Workbook:** `manufacturing_mock_data.xlsx` (contains flat denormalized logs).

### Phase 2: Processing via CLI
Open your terminal and run:
```bash
# 1. Migrate the Excel data to the SQLite DWH
python main.py --action migrate

# 2. Run the reconciliation engine to check for mismatches
python main.py --action reconcile
```

### Phase 3: Processing via Web UI (Highly Recommended)
1. Run the web server in your terminal:
   ```bash
   python src/web/app.py
   ```
2. Open your web browser and go to `http://127.0.0.1:5000`.
3. Click **1. Run ETL Migration** to rebuild and load the warehouse.
4. Click **3. Run Reconciliation** to execute all 25 test suites.
5. In the right panel, download the resulting Excel or HTML dashboard reports under **Download Mismatch Reports** to review mismatches.
