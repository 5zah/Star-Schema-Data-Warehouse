"""
Flask Web Application acting as an Interactive Dashboard for the ETL Automation Framework.
Allows executing Migration, Data Scaling, Reconciliation, and Anomaly Injection from a web UI.
"""
import os
import sys
import io
import json
from flask import Flask, render_template, jsonify, request, send_from_directory
from flask_cors import CORS

# Add root folder to python path so we can import src
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from src.cli import (
    build_parser, 
    run_migration_action, 
    run_scaling_action, 
    run_reconciliation_action, 
    run_anomaly_test_action
)

app = Flask(__name__, template_folder="templates")
CORS(app)

REPORTS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "reports"))
DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "data"))
CONFIG_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "config"))

# Capture console output helper
class Capturing(list):
    def __enter__(self):
        self._stdout = sys.stdout
        sys.stdout = self._stringio = io.StringIO()
        return self
    def __exit__(self, *args):
        self.extend(self._stringio.getvalue().splitlines())
        sys.stdout = self._stdout

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/config", methods=["GET"])
def get_config():
    config_path = os.path.join(CONFIG_DIR, "reconciliation_config.yaml")
    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            return jsonify({"status": "success", "config": f.read()})
    return jsonify({"status": "error", "message": "Config file not found"})

@app.route("/api/reports/list", methods=["GET"])
def list_reports():
    reports = []
    if os.path.exists(REPORTS_DIR):
        for f in os.listdir(REPORTS_DIR):
            if f.endswith((".html", ".xlsx", ".json", ".md")):
                path = os.path.join(REPORTS_DIR, f)
                reports.append({
                    "name": f,
                    "size": f"{os.path.getsize(path) / 1024:.2f} KB",
                    "type": f.split(".")[-1].upper()
                })
    return jsonify(reports)

@app.route("/api/reports/download/<filename>", methods=["GET"])
def download_report(filename):
    return send_from_directory(REPORTS_DIR, filename, as_attachment=True)

@app.route("/api/action", methods=["POST"])
def trigger_action():
    data = request.json or {}
    action = data.get("action", "reconcile")
    multiplier = int(data.get("multiplier", 5))

    parser = build_parser()
    args_list = ["--action", action]
    if action == "scale":
        args_list.extend(["--multiplier", str(multiplier)])
    
    args = parser.parse_args(args_list)
    logs = []

    try:
        with Capturing() as output:
            if action == "migrate":
                run_migration_action(args)
            elif action == "scale":
                run_scaling_action(args)
            elif action == "reconcile":
                run_reconciliation_action(args)
            elif action == "test-anomaly":
                run_anomaly_test_action(args)
        logs = list(output)
        
        # If reconciliation was run, fetch json results for the UI
        rec_data = None
        if action in ["reconcile", "test-anomaly"]:
            json_path = os.path.join(REPORTS_DIR, "reconciliation_results.json")
            if os.path.exists(json_path):
                with open(json_path, "r", encoding="utf-8") as f:
                    rec_data = json.load(f)

        return jsonify({
            "status": "success",
            "action": action,
            "logs": logs,
            "results": rec_data
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "action": action,
            "message": str(e),
            "logs": logs + [f"[ERROR] {str(e)}"]
        }), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
