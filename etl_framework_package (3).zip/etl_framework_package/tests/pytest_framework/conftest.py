"""
Pytest Context and Configuration File (conftest.py).
Defines shared database connection fixtures for Microsoft Azure SQL and Snowflake.
Provides fallback drivers for SQLite to ensure immediate local execution.
"""
import os
import pytest
import yaml
import sqlalchemy as sa

# Load config path
CONFIG_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "config", "reconciliation_config.yaml"))

def load_reconciliation_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {}

@pytest.fixture(scope="session")
def app_config():
    """Loads configuration parameters from reconciliation_config.yaml."""
    return load_reconciliation_config()

@pytest.fixture(scope="session")
def azure_sql_engine(app_config):
    """
    Creates and returns an active SQLAlchemy connection engine for Azure SQL.
    Falls back to a local SQLite database for offline demo execution.
    """
    # Attempt to read from environment variables or config
    connection_string = os.getenv(
        "AZURE_SQL_CONNECTION_STRING",
        "sqlite:///data/manufacturing_dwh.db" # Local fallback
    )
    
    # In a real Azure setup, this would be:
    # "mssql+pyodbc://username:password@yourserver.database.windows.net/db?driver=ODBC+Driver+17+for+SQL+Server"
    
    engine = sa.create_engine(connection_string)
    yield engine
    engine.dispose()

@pytest.fixture(scope="session")
def snowflake_engine(app_config):
    """
    Creates and returns an active SQLAlchemy connection engine for Snowflake.
    Falls back to a local test SQLite database for offline demo execution.
    """
    connection_string = os.getenv(
        "SNOWFLAKE_CONNECTION_STRING",
        "sqlite:///data/test_manufacturing_dwh.db" # Local fallback
    )
    
    # In a real Snowflake setup, this would be:
    # "snowflake://username:password@account_identifier/database/schema?warehouse=wh"
    
    engine = sa.create_engine(connection_string)
    yield engine
    engine.dispose()
