"""
Pytest Test Suite (test_dwh_reconciliation.py).
Contains Positive and Negative test scenarios validating data integrity,
volumes, aggregates, and structural schemas using raw SQL queries.
"""
import pytest
import pandas as pd
from sqlalchemy import text


# ====================================================================
# SECTION 1: POSITIVE SCENARIOS (Asserting correct system state)
# ====================================================================

def test_positive_volume_reconciliation(azure_sql_engine, snowflake_engine):
    """
    [Positive] Verify that overall row counts match between Source and Target.
    Query Target: fact_work_orders
    Query Source: work_orders / dim_plant (checking matching plants count)
    """
    query_src = text("SELECT COUNT(*) AS row_count FROM fact_work_orders;")
    query_tgt = text("SELECT COUNT(*) AS row_count FROM fact_work_orders;")
    
    with azure_sql_engine.connect() as conn_src:
        src_count = conn_src.execute(query_src).scalar()
        
    with snowflake_engine.connect() as conn_tgt:
        tgt_count = conn_tgt.execute(query_tgt).scalar()
        
    print(f"\n[VOLUME MATCH] Source Count: {src_count} | Target Count: {tgt_count}")
    assert src_count == tgt_count, f"Volume mismatch: Source has {src_count} but Target has {tgt_count}"


def test_positive_aggregate_reconciliation(azure_sql_engine, snowflake_engine):
    """
    [Positive] Verify total sum of Planned Quantity matches within a tolerance of 0.01.
    """
    query_src = text("SELECT SUM(planned_quantity) FROM fact_work_orders;")
    query_tgt = text("SELECT SUM(planned_quantity) FROM fact_work_orders;")
    
    with azure_sql_engine.connect() as conn_src:
        src_sum = conn_src.execute(query_src).scalar() or 0.0
        
    with snowflake_engine.connect() as conn_tgt:
        tgt_sum = conn_tgt.execute(query_tgt).scalar() or 0.0
        
    diff = abs(src_sum - tgt_sum)
    print(f"\n[AGGREGATE MATCH] Source Sum: {src_sum} | Target Sum: {tgt_sum} | Diff: {diff}")
    assert diff <= 0.01, f"Aggregate sum drift detected: {diff} exceeds threshold 0.01"


def test_positive_schema_integrity(snowflake_engine):
    """
    [Positive] Verify target Fact table contains correct analytical surrogate keys.
    """
    query = text("SELECT * FROM fact_work_orders LIMIT 1;")
    with snowflake_engine.connect() as conn:
        df = pd.read_sql(query, conn)
        
    expected_columns = ["order_date_key", "plant_key", "line_key", "product_key"]
    for col in expected_columns:
        assert col in df.columns, f"Required surrogate key column '{col}' is missing from Target Schema!"


# ====================================================================
# SECTION 2: NEGATIVE SCENARIOS (Asserting no errors / anomalies exist)
# ====================================================================

def test_negative_duplicate_business_keys(snowflake_engine):
    """
    [Negative] Assert that no duplicate business keys exist in fact_work_orders.
    If duplicates exist, the test will fail and display the duplicates.
    """
    query = text("""
        SELECT work_order_number, COUNT(*) AS duplicate_count
        FROM fact_work_orders
        GROUP BY work_order_number
        HAVING COUNT(*) > 1;
    """)
    with snowflake_engine.connect() as conn:
        df = pd.read_sql(query, conn)
        
    duplicate_count = len(df)
    print(f"\n[DUPLICATES CHECK] Found {duplicate_count} duplicate work order keys.")
    assert duplicate_count == 0, f"Duplicate keys found in Target fact table: \n{df.to_string()}"


def test_negative_orphaned_foreign_keys(snowflake_engine):
    """
    [Negative] Assert that no orphaned work orders exist in the target fact table.
    All plant_key values in fact table must link to a valid plant in dim_plant.
    """
    query = text("""
        SELECT f.work_order_number, f.plant_key
        FROM fact_work_orders f
        LEFT JOIN dim_plant p ON f.plant_key = p.plant_key
        WHERE p.plant_key IS NULL;
    """)
    with snowflake_engine.connect() as conn:
        df = pd.read_sql(query, conn)
        
    orphans = len(df)
    print(f"\n[ORPHANS CHECK] Found {orphans} orphaned records.")
    assert orphans == 0, f"Referential integrity failure! Found {orphans} orphaned fact rows: \n{df.to_string()}"


def test_negative_null_constraints(snowflake_engine):
    """
    [Negative] Assert that mandatory PK and FK columns do not contain NULL values.
    """
    query = text("""
        SELECT 
            SUM(CASE WHEN work_order_number IS NULL THEN 1 ELSE 0 END) AS null_numbers,
            SUM(CASE WHEN order_date_key IS NULL THEN 1 ELSE 0 END) AS null_dates,
            SUM(CASE WHEN plant_key IS NULL THEN 1 ELSE 0 END) AS null_plants,
            SUM(CASE WHEN product_key IS NULL THEN 1 ELSE 0 END) AS null_products
        FROM fact_work_orders;
    """)
    with snowflake_engine.connect() as conn:
        df = pd.read_sql(query, conn)
        
    total_nulls = df.iloc[0].sum()
    print(f"\n[NULL CHECK] Total nulls in PK/FK columns: {total_nulls}")
    assert total_nulls == 0, f"Null constraints violated in Target PK/FK columns: \n{df.to_string()}"


def test_negative_out_of_bounds_operational_limits(snowflake_engine):
    """
    [Negative] Assert that no work order has values violating manufacturing bounds
    (e.g., yield_percent > 100.0% or produced_quantity < 0).
    """
    query = text("""
        SELECT work_order_number, yield_percent, produced_quantity
        FROM fact_work_orders
        WHERE yield_percent > 100.0 OR produced_quantity < 0;
    """)
    with snowflake_engine.connect() as conn:
        df = pd.read_sql(query, conn)
        
    violations = len(df)
    print(f"\n[BOUNDS CHECK] Found {violations} business rule violations.")
    assert violations == 0, f"Data out of operational bounds detected: \n{df.to_string()}"
