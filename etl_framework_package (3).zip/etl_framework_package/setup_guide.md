# Setup Guide — ETL Testing Framework on a New Laptop
## Enterprise ETL Testing & Multi-Database Reconciliation Engine

> **Time to set up:** ~10–15 minutes  
> **Prerequisites:** Internet connection, Windows 10/11

---

## Step 1: Install Python 3.11+ (if not installed)

1. Go to: **https://www.python.org/downloads/**
2. Download **Python 3.11 or 3.13** (Windows 64-bit installer).
3. Run the installer.
4. ⚠️ **IMPORTANT:** On the first screen, check **"Add Python to PATH"** before clicking Install Now.
5. Verify in PowerShell:
```powershell
python --version
# Expected: Python 3.11.x or Python 3.13.x

pip --version
# Expected: pip 24.x.x
```

---

## Step 2: Install Git (if not installed)

1. Go to: **https://git-scm.com/downloads**
2. Download the Windows 64-bit installer.
3. Run with all default options (make sure "Git from the command line" is selected).
4. Verify in a **new** PowerShell window:
```powershell
git --version
# Expected: git version 2.x.x.windows.x
```
5. Configure your identity (one time only):
```powershell
git config --global user.name "Your Name"
git config --global user.email "your.email@gds.ey.com"
```

---

## Step 3: Clone the Repository

Open PowerShell and navigate to where you want the project:
```powershell
# Navigate to your desired folder (example: Documents)
cd C:\Users\YourUsername\Documents

# Clone the repository from GitHub
git clone https://github.com/<your-username>/<your-repository-name>.git

# Navigate into the project folder
cd "etl-testing-framework"    # or whatever your repo is named
```

> If you have not pushed to GitHub yet, you can copy the project folder directly to the new laptop via USB or shared drive and skip this step.

---

## Step 4: Copy Source Data Files

The Excel source data files are **not stored in Git** (they are large binary files). You need to copy them manually into the project root folder:

```
ETL testing/
├── manufacturing_mock_data.xlsx        ← COPY THIS FROM YOUR ORIGINAL MACHINE
├── manufacturing_relational_data.xlsx  ← COPY THIS FROM YOUR ORIGINAL MACHINE
```

**How to transfer:**
- USB Drive → Copy both `.xlsx` files to the project root.
- OneDrive / SharePoint → Download to the project root.
- Email attachment (if files are < 25MB each).

---

## Step 5: Create a Virtual Environment (Recommended)

A virtual environment keeps your project dependencies isolated from other Python projects.

```powershell
# Create virtual environment inside the project folder
python -m venv venv

# Activate it
.\venv\Scripts\Activate.ps1
```

> If you get an error about execution policy, run this first then retry:
> ```powershell
> Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
> ```

Your terminal prompt will now show `(venv)` at the start — this means it is active.

---

## Step 6: Install Project Dependencies

```powershell
# Make sure you are inside the project folder with venv active
pip install -r requirements.txt
```

This will install:
- `pandas` — Data manipulation and Excel reading
- `openpyxl` — Excel file engine
- `SQLAlchemy` — Multi-database abstraction layer
- `PyYAML` — Configuration file parsing
- `numpy` — Numeric operations
- `Jinja2` — HTML report template engine
- `pytest` — Test runner

**Verify installation:**
```powershell
pip list | Select-String "pandas|SQLAlchemy|openpyxl|PyYAML"
```

---

## Step 7: Create Required Directories

These directories are not tracked in Git (they hold generated databases and reports):
```powershell
mkdir data
mkdir reports
```

---

## Step 8: Run the ETL Migration (Build the Data Warehouse)

```powershell
python main.py --action migrate
```

**Expected Output:**
```
====================================================================
[MIGRATE] STARTING MANUFACTURING DATA WAREHOUSE MIGRATION PIPELINE
====================================================================
[*] Step 1: Initializing Star Schema DDL at: sqlite:///data/manufacturing_dwh.db
    [OK] Dimensions, Facts, and Indexes created successfully.
[*] Step 2: Extracting source tables from manufacturing_relational_data.xlsx...
    ...
[*] Step 4: Loading clean Dimensions and Facts into Target Data Warehouse...
    [LOADED] Dimension: dim_date                  (  2558 rows)
    [LOADED] Fact Table: fact_work_orders          (  1000 rows)
    ...
--------------------------------------------------------------------
[SUCCESS] MIGRATION COMPLETED in ~15s! Total Loaded Rows: 20261
====================================================================
```

---

## Step 9: Run the Reconciliation Engine

```powershell
python main.py --action reconcile
```

**Expected Output:**
```
[SCOPE 1/4] Running Data Volume Reconciliation...
    [PASS]   Plants Dimension Volume             | Src:  1000 | Tgt:  1000
    ...
[SCOPE 2/4] Running Attribute-Level & Cell Reconciliation...
    [PASS]   Work Orders Attribute Validation    | Cells:  14000 | Match: 100.00%
    ...
[SCOPE 3/4] Running Aggregate Measure Reconciliation...
    [PASS]   Work Orders Production Aggregates   | Passed: 8/8
    ...
[SCOPE 4/4] Running Multi-Source Consistency Assessment...
    [PASS]   Production Operational Bounds       ...
--------------------------------------------------------------------
[SUMMARY] RECONCILIATION: PASS (25/25 Passed, 100.0%)
====================================================================
```

**Generated Reports (open these to review results):**
- `reports/Reconciliation_Report.html` — Interactive dashboard (open in browser)
- `reports/Reconciliation_Report.xlsx` — Multi-tab Excel report
- `reports/Reconciliation_Summary.md` — Markdown summary
- `reports/reconciliation_results.json` — Machine-readable log

---

## Step 10: Run the Full Test Suite

```powershell
python -m unittest tests/test_reconciliation.py -v
```

**Expected Output (14 tests):**
```
test_F01_volume_fail_missing_rows ... ok
test_F02_volume_fail_truncated_table ... ok
test_F03_attribute_fail_numeric_corruption ... ok
test_F04_attribute_fail_string_corruption ... ok
test_F05_aggregate_fail_zeroed_costs ... ok
test_F06_multi_source_fail_cross_system ... ok
test_F07_business_rule_fail_negative_scrap ... ok
test_P01_schema_tables_created ... ok
test_P02_migration_row_counts ... ok
test_P03_volume_reconciliation ... ok
test_P04_attribute_cell_reconciliation ... ok
test_P05_aggregate_measure_reconciliation ... ok
test_P06_multi_source_consistency ... ok
test_P07_data_scaler ... ok
----------------------------------------------------------------------
Ran 14 tests in ~70s

OK
```

---

## Step 11: (Optional) Run Full End-to-End Pipeline

```powershell
# Run: Migrate → Scale 5x → Reconcile → Anomaly Injection Test
python main.py --action all
```

---

## Quick Command Reference

| Task | Command |
| :--- | :--- |
| Build Data Warehouse | `python main.py --action migrate` |
| Run Reconciliation Engine | `python main.py --action reconcile` |
| Scale dataset 10x | `python main.py --action scale --multiplier 10` |
| Run Anomaly Injection Test | `python main.py --action test-anomaly` |
| Run all | `python main.py --action all` |
| Run Test Suite | `python -m unittest tests/test_reconciliation.py -v` |
| Activate venv | `.\venv\Scripts\Activate.ps1` |
| Deactivate venv | `deactivate` |

---

## Troubleshooting

| Problem | Solution |
| :--- | :--- |
| `python not recognized` | Reinstall Python with "Add to PATH" checked, or restart terminal |
| `git not recognized` | Restart terminal after Git install, or run `$env:Path += ";C:\Program Files\Git\cmd"` |
| `ModuleNotFoundError: pandas` | Run `pip install -r requirements.txt` with venv activated |
| `FileNotFoundError: manufacturing_relational_data.xlsx` | Copy both Excel files to the project root folder (see Step 4) |
| `PermissionError: data/manufacturing_dwh.db` | Close any DB Browser for SQLite or other tool that has the file open |
| PowerShell script error on venv activate | Run `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser` |

---

## Project Folder Structure After Setup

```
ETL testing/
├── .git/                               ← Git version control (auto-created)
├── config/
│   ├── dwh_schema.sql                  ← Star Schema DDL (12 Dims, 8 Facts)
│   ├── reconciliation_config.yaml      ← Test suite config & column mappings
│   └── scale_config.yaml               ← Scaling rules
├── data/                               ← GENERATED — SQLite databases
│   ├── manufacturing_dwh.db            ← Main Star Schema DWH
│   ├── scaled_manufacturing_relational.db
│   └── test_*.db                       ← Test databases (auto-created)
├── reports/                            ← GENERATED — Reconciliation reports
│   ├── Reconciliation_Report.html
│   ├── Reconciliation_Report.xlsx
│   ├── Reconciliation_Summary.md
│   └── reconciliation_results.json
├── src/
│   ├── connectors/                     ← DB + File connectors
│   ├── warehouse/                      ← ETL Migration pipeline
│   ├── scaling/                        ← Data scaler
│   ├── reconciliation/                 ← 4-pillar validation engine
│   ├── reporting/                      ← HTML, Excel, Markdown reporters
│   └── cli.py
├── tests/
│   └── test_reconciliation.py          ← 14 test cases (7 PASS + 7 FAIL)
├── manufacturing_mock_data.xlsx        ← SOURCE DATA (copy manually)
├── manufacturing_relational_data.xlsx  ← SOURCE DATA (copy manually)
├── main.py
├── requirements.txt
├── .gitignore
└── README.md
```
