# Test Case Specification Document
## Enterprise ETL Testing & Multi-Database Reconciliation Framework

| Field | Detail |
| :--- | :--- |
| **Project** | Manufacturing Data Warehouse — ETL Testing Framework |
| **Author** | Faizah Shaikh (`faizah.shaikh@gds.ey.com`) |
| **Version** | 2.0.0 |
| **Tool** | Python `unittest` — `tests/test_reconciliation.py` |
| **Total Test Cases** | 14 (7 PASS + 7 FAIL) |
| **Last Run** | 26-Aug-2026 — `Ran 14 tests in 70.5s — OK` |
| **Coverage** | Volume Reconciliation, Attribute Validation, Aggregate Reconciliation, Multi-Source Consistency, Business Rule Validation, Data Scaling |

---

## Test Environment

| Component | Details |
| :--- | :--- |
| **Source 1** | `manufacturing_relational_data.xlsx` (15 Relational Sheets, 3NF structure) |
| **Source 2** | `manufacturing_mock_data.xlsx` (1,000 rows × 212 columns, denormalized flat file) |
| **Clean Target DWH** | `data/test_manufacturing_dwh.db` (Star Schema SQLite, used by PASS tests) |
| **Corrupted Target DWH** | `data/test_fail_dwh.db` (Star Schema clone with 5 injected defects, used by FAIL tests) |
| **Python Version** | 3.13 |
| **Test Runner** | `python -m unittest tests/test_reconciliation.py -v` |

---

## Section A: PASS Test Cases
> These tests verify the ETL migration is correct. They run against the **clean target DWH**.

---

### TC-P01 — Star Schema Table Creation

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-P01 |
| **Test Name** | `test_P01_schema_tables_created` |
| **Category** | Schema Structural Validation |
| **Priority** | Critical |
| **Objective** | Verify that all 12 Dimension tables and 8 Fact tables are created in the target data warehouse after DDL execution. |
| **Preconditions** | `DWHDDLBuilder.build_schema(drop_existing=True)` has been called on a clean SQLite database. |

**Test Steps:**
1. Instantiate `DWHDDLBuilder` with the test connection string.
2. Call `builder.get_table_list()` to retrieve all table names from the database.
3. Assert that each of the 12 expected dimension tables is present in the list.
4. Assert that each of the 8 expected fact tables is present in the list.

**Expected Result:**
- All 20 tables (`dim_date`, `dim_location`, `dim_color`, `dim_plant`, `dim_production_line`, `dim_product`, `dim_machine`, `dim_operator`, `dim_supplier`, `dim_material`, `dim_material_sales`, `dim_defect_catalog`, `fact_work_orders`, `fact_sales_detail`, `fact_order_detail`, `fact_machine_telemetry`, `fact_quality_inspections`, `fact_labor_performance`, `fact_cost_financials`, `fact_procurement`) are present.

**Actual Result:** ✅ PASS — All 20 tables confirmed present.

---

### TC-P02 — ETL Migration Row Count Verification

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-P02 |
| **Test Name** | `test_P02_migration_row_counts` |
| **Category** | ETL Load Completeness |
| **Priority** | Critical |
| **Objective** | Verify the migration pipeline reports SUCCESS and that all key fact and dimension tables contain data after a complete ETL run. |
| **Preconditions** | `MigrationPipeline.run_migration()` has completed. `migration_summary` dict is available. |

**Test Steps:**
1. Assert `migration_summary["status"] == "SUCCESS"`.
2. Retrieve `migration_summary["table_counts"]` dictionary.
3. Assert `fact_work_orders > 0`.
4. Assert `fact_sales_detail > 0`.
5. Assert `fact_order_detail > 0`.
6. Assert `dim_plant > 0`.
7. Assert `dim_color > 0`.

**Expected Result:** Migration returns `SUCCESS` and all checked tables have records > 0 (actual: 20,261 total rows).

**Actual Result:** ✅ PASS — `SUCCESS`, 20,261 rows loaded across 20 tables.

---

### TC-P03 — Volume Reconciliation (Clean Load)

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-P03 |
| **Test Name** | `test_P03_volume_reconciliation` |
| **Category** | Data Volume Reconciliation |
| **Priority** | Critical |
| **Objective** | Confirm that the row count of `Work_Orders` in the relational Excel source exactly matches the row count of `fact_work_orders` in the clean DWH. No records should be missing. |
| **Preconditions** | Clean DWH has been loaded. Both `ExcelConnector` and `SQLAlchemyConnector` are initialized. |

**Test Steps:**
1. Instantiate `VolumeValidator`.
2. Call `validate_table_pair()` comparing source `Work_Orders` sheet to target `fact_work_orders` table.
3. Assert `result["status"] == "PASS"`.
4. Assert `result["diff"] == 0` (no row delta).
5. Assert `result["missing_in_target_count"] == 0` (no orphaned source keys).

**Expected Result:** `status=PASS`, `diff=0`, `missing_in_target_count=0`.

**Actual Result:** ✅ PASS — Source: 1,000 rows | Target: 1,000 rows | Delta: 0.

---

### TC-P04 — Attribute-Level Cell Reconciliation

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-P04 |
| **Test Name** | `test_P04_attribute_cell_reconciliation` |
| **Category** | Attribute & Cell-Level Validation |
| **Priority** | Critical |
| **Objective** | Perform 100% cell-by-cell comparison of 5 mapped columns (3 numeric, 1 percentage, 1 string) between the `Work_Orders` source and `fact_work_orders` target. |
| **Preconditions** | Clean DWH loaded. Column mappings defined (source→target): `Planned_Quantity→planned_quantity`, `Produced_Quantity→produced_quantity`, `Good_Quantity→good_quantity`, `Yield_Percent→yield_percent`, `Order_Status→order_status`. |

**Test Steps:**
1. Instantiate `AttributeValidator`.
2. Call `validate_attributes()` with PK map `Work_Order_Number → work_order_number`.
3. Pass 5 column mappings with `type: float` (atol=0.01) for numerics and `type: string` for status.
4. Assert `result["status"] == "PASS"`.
5. Assert `result["match_percent"] == 100.0`.
6. Assert `result["mismatched_cells_count"] == 0`.

**Expected Result:** 14,000 cells checked (1,000 rows × 5 mapped columns × 2 sides + join = 1,000 matched records × 5 columns). Match rate = 100.00%.

**Actual Result:** ✅ PASS — 14,000 cells, 100.00% match, 0 mismatches.

---

### TC-P05 — Aggregate Measure Reconciliation

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-P05 |
| **Test Name** | `test_P05_aggregate_measure_reconciliation` |
| **Category** | Aggregate Measure Validation |
| **Priority** | High |
| **Objective** | Verify that mathematical aggregate metrics (SUM and AVG) computed from the source match those computed from the clean DWH target within absolute tolerance of ±0.01. |
| **Preconditions** | Clean DWH loaded. 4 aggregate metrics defined. |

**Test Steps:**
1. Instantiate `AggregateValidator`.
2. Call `validate_aggregates()` with metrics: `SUM(Planned_Quantity)`, `SUM(Produced_Quantity)`, `SUM(Good_Quantity)`, `AVG(Yield_Percent)`.
3. Assert `result["status"] == "PASS"`.
4. Assert `result["failed_metrics"] == 0`.

**Expected Result:** All 4 aggregate metrics match source-to-target within ±0.01 tolerance.

**Actual Result:** ✅ PASS — 4/4 metrics passed.

---

### TC-P06 — Multi-Source Consistency (Flat vs Relational)

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-P06 |
| **Test Name** | `test_P06_multi_source_consistency` |
| **Category** | Multi-Source Cross-System Consistency |
| **Priority** | High |
| **Objective** | Confirm that the denormalized flat Excel file (`Manufacturing_Data`) and the normalized relational sheet (`Work_Orders`) report the same values for shared columns, using `Work_Order_Number` as the join key. |
| **Preconditions** | Both Excel connectors initialized. Columns to compare: `Plant_Code`, `Product_SKU`, `Planned_Quantity`, `Produced_Quantity`. |

**Test Steps:**
1. Instantiate `MultiSourceValidator`.
2. Call `assess_cross_source_consistency()` joining on `Work_Order_Number`.
3. Compare 4 columns across sources.
4. Assert `result["status"] == "PASS"`.

**Expected Result:** Both source files report identical values for all 4 columns across all matching records.

**Actual Result:** ✅ PASS — All 4 column comparisons consistent across Flat and Relational sources.

---

### TC-P07 — Data Scaler Referential Integrity (2x)

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-P07 |
| **Test Name** | `test_P07_data_scaler` |
| **Category** | Data Volume Scaling & Referential Integrity |
| **Priority** | Medium |
| **Objective** | Verify that the data scaler generates a 2x dataset where all foreign key relationships remain intact (Work Orders reference valid Plants, Production Lines, and Products). |
| **Preconditions** | `manufacturing_relational_data.xlsx` is accessible. Multiplier = 2. |

**Test Steps:**
1. Instantiate `ManufacturingDataScaler` with seed file.
2. Call `scale_dataset(multiplier=2)`.
3. Assert `Work_Orders >= 2000 rows`.
4. Assert `Plants >= 2000 rows`.
5. Assert `Machines >= 2000 rows`.
6. For every `Plant_Code` in `Work_Orders`, verify it exists in `Plants`.
7. For every `Line_ID` in `Work_Orders`, verify it exists in `Production_Lines`.
8. For every `Product_SKU` in `Work_Orders`, verify it exists in `Products`.

**Expected Result:** 2,000 Work Orders, 2,000 Plants, 20,000+ Machines with 100% valid FK references.

**Actual Result:** ✅ PASS — 2,000 Work Orders, 2,000 Plants, 20,929 Machines. 0 orphaned FK violations.

---

## Section B: FAIL Test Cases
> These tests verify the engine **correctly detects** ETL defects. They run against the **corrupted DWH clone**.
> Each test `assertIn(result["status"], ["FAIL", "WARNING"])` — confirming the defect was caught.

### Injected Defects in Corrupted DWH (`data/test_fail_dwh.db`)

| Defect # | SQL Injected | Tables Affected |
| :--- | :--- | :--- |
| D1 | `DELETE ... WHERE work_order_number IN ('WO-2023000','WO-2023001','WO-2023002')` | `fact_work_orders` |
| D2 | `UPDATE ... SET planned_quantity=99999.0, scrap_quantity=-500.0 WHERE work_order_number='WO-2023003'` | `fact_work_orders` |
| D3 | `UPDATE ... SET order_status='INVALID_STATUS_XYZ' WHERE work_order_number='WO-2023004'` | `fact_work_orders` |
| D4 | `UPDATE ... SET material_cost_usd=0, labor_cost_usd=0, total_unit_cost_usd=0 WHERE rowid <= 10` | `fact_cost_financials` |
| D5 | `DELETE FROM fact_machine_telemetry WHERE rowid <= 50` | `fact_machine_telemetry` |

---

### TC-F01 — Volume FAIL: Missing Rows (Partial Load)

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-F01 |
| **Test Name** | `test_F01_volume_fail_missing_rows` |
| **Category** | Volume Reconciliation — Defect Detection |
| **Priority** | Critical |
| **ETL Defect Simulated** | Truncate-and-reload job aborted mid-run; 3 work orders were not reloaded |
| **Injected Anomaly** | `DELETE FROM fact_work_orders WHERE work_order_number IN ('WO-2023000','WO-2023001','WO-2023002')` |
| **Objective** | Verify that the VolumeValidator flags a FAIL/WARNING when 3 rows are missing from the target. |

**Test Steps:**
1. Instantiate `VolumeValidator`.
2. Call `validate_table_pair()` with source `Work_Orders` (1,000 rows) vs corrupted target `fact_work_orders` (997 rows).
3. Assert `result["status"] in ["FAIL", "WARNING"]`.
4. Assert `result["diff"] < 0` (target has fewer rows than source).
5. Assert `result["missing_in_target_count"] > 0`.

**Expected Result:** Engine flags status as `WARNING` or `FAIL`, `diff = -3`, `missing_in_target_count = 3`.

**Actual Result:** ✅ PASS (defect detected) — `status=WARNING`, `diff=-3`, `missing_in_target_count=3`.

---

### TC-F02 — Volume FAIL: Truncated IoT Telemetry Table

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-F02 |
| **Test Name** | `test_F02_volume_fail_truncated_table` |
| **Category** | Volume Reconciliation — Defect Detection |
| **Priority** | Critical |
| **ETL Defect Simulated** | Network timeout during high-frequency IoT sensor data ingestion; 50 readings lost |
| **Injected Anomaly** | `DELETE FROM fact_machine_telemetry WHERE rowid <= 50` |
| **Objective** | Verify that the VolumeValidator flags a FAIL/WARNING when 50 machine telemetry rows are missing from the target. |

**Test Steps:**
1. Instantiate `VolumeValidator`.
2. Call `validate_table_pair()` with source `Machine_Process_Readings` (1,000 rows) vs corrupted `fact_machine_telemetry` (950 rows).
3. Assert `result["status"] in ["FAIL", "WARNING"]`.
4. Assert `result["diff"] < 0`.

**Expected Result:** `diff = -50`, status flagged as FAIL/WARNING.

**Actual Result:** ✅ PASS (defect detected) — `status=WARNING`, `diff=-50`.

---

### TC-F03 — Attribute FAIL: Numeric Value Corruption

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-F03 |
| **Test Name** | `test_F03_attribute_fail_numeric_corruption` |
| **Category** | Attribute Cell-Level Validation — Defect Detection |
| **Priority** | Critical |
| **ETL Defect Simulated** | Data type casting overflow produced an impossibly large `planned_quantity` (99,999 vs expected ~500) |
| **Injected Anomaly** | `UPDATE fact_work_orders SET planned_quantity=99999.0, scrap_quantity=-500.0 WHERE work_order_number='WO-2023003'` |
| **Objective** | Verify that AttributeValidator detects the corrupted numeric cell exceeding the 0.01 absolute tolerance threshold. |

**Test Steps:**
1. Instantiate `AttributeValidator`.
2. Map `Planned_Quantity → planned_quantity` (type: float, atol: 0.01) and `Scrap_Quantity → scrap_quantity` (type: float, atol: 0.01).
3. Run `validate_attributes()` against corrupted DWH.
4. Assert `result["status"] == "FAIL"`.
5. Assert `result["mismatched_cells_count"] > 0`.

**Expected Result:** At least 2 mismatched cells (one for `planned_quantity`, one for `scrap_quantity`), status = FAIL.

**Actual Result:** ✅ PASS (defect detected) — `status=FAIL`, `mismatched_cells_count=2`.

---

### TC-F04 — Attribute FAIL: Invalid String Enum Value

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-F04 |
| **Test Name** | `test_F04_attribute_fail_string_corruption` |
| **Category** | Attribute Cell-Level Validation — Defect Detection |
| **Priority** | High |
| **ETL Defect Simulated** | Stale or unrefreshed lookup/mapping table during migration caused an invalid status code to be written to target |
| **Injected Anomaly** | `UPDATE fact_work_orders SET order_status='INVALID_STATUS_XYZ' WHERE work_order_number='WO-2023004'` |
| **Objective** | Verify that AttributeValidator detects the invalid `order_status` string that doesn't match the source value. |

**Test Steps:**
1. Instantiate `AttributeValidator`.
2. Map `Order_Status → order_status` (type: string).
3. Run `validate_attributes()` against corrupted DWH.
4. Assert `result["status"] == "FAIL"`.
5. Assert `result["mismatched_cells_count"] > 0`.

**Expected Result:** 1 mismatched cell (`WO-2023004`: source = `Completed`, target = `INVALID_STATUS_XYZ`). Status = FAIL.

**Actual Result:** ✅ PASS (defect detected) — `status=FAIL`, `mismatched_cells_count=1`.

---

### TC-F05 — Aggregate FAIL: Zeroed Cost Measures

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-F05 |
| **Test Name** | `test_F05_aggregate_fail_zeroed_costs` |
| **Category** | Aggregate Measure Reconciliation — Defect Detection |
| **Priority** | High |
| **ETL Defect Simulated** | A NULL-handling bug in the ETL transformation replaced NULL source values with `0` instead of passing them through, causing SUM-level drift across 10 records |
| **Injected Anomaly** | `UPDATE fact_cost_financials SET material_cost_usd=0, labor_cost_usd=0, total_unit_cost_usd=0 WHERE rowid <= 10` |
| **Objective** | Verify that AggregateValidator detects drift in `SUM(material_cost_usd)`, `SUM(labor_cost_usd)`, and `AVG(total_unit_cost_usd)` caused by zeroing 10 rows. |

**Test Steps:**
1. Instantiate `AggregateValidator`.
2. Define 3 metrics: `SUM(Material_Cost_USD)`, `SUM(Labor_Cost_USD)`, `AVG(Total_Unit_Cost_USD)`.
3. Run `validate_aggregates()` comparing source `Cost_Records` to corrupted `fact_cost_financials`.
4. Assert `result["status"] == "FAIL"`.
5. Assert `result["failed_metrics"] > 0`.

**Expected Result:** At least 2 aggregate metrics fail (SUM-level drift due to zeroed rows). Status = FAIL.

**Actual Result:** ✅ PASS (defect detected) — `status=FAIL`, `failed_metrics=2`.

---

### TC-F06 — Multi-Source FAIL: Cross-System Drift

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-F06 |
| **Test Name** | `test_F06_multi_source_fail_cross_system` |
| **Category** | Multi-Source Consistency Assessment — Defect Detection |
| **Priority** | High |
| **ETL Defect Simulated** | DWH was refreshed from wrong historical snapshot, causing values to diverge from the relational source of truth |
| **Injected Anomaly** | Defects D1 + D2 (missing rows and corrupted values) affect cross-system join comparison |
| **Objective** | Verify that MultiSourceValidator detects column-level drift when comparing the clean relational source (`Work_Orders`) to the corrupted DWH (`fact_work_orders`). |

**Test Steps:**
1. Instantiate `MultiSourceValidator`.
2. Join on `Work_Order_Number → work_order_number`.
3. Compare columns: `Planned_Quantity → planned_quantity`, `Scrap_Quantity → scrap_quantity`.
4. Assert `result["status"] == "FAIL"`.
5. Assert at least 1 entry in `result["column_comparisons"]` has `status == "FAIL"`.

**Expected Result:** `planned_quantity` column comparison shows FAIL (corrupted value on `WO-2023003`). Overall status = FAIL.

**Actual Result:** ✅ PASS (defect detected) — `status=FAIL`, 1 column-level FAIL detected.

---

### TC-F07 — Business Rule FAIL: Negative Scrap Quantity

| Field | Detail |
| :--- | :--- |
| **Test Case ID** | TC-F07 |
| **Test Name** | `test_F07_business_rule_fail_negative_scrap` |
| **Category** | Business Logic Rule Validation — Defect Detection |
| **Priority** | High |
| **ETL Defect Simulated** | Sign inversion bug in the transformation logic produced physically impossible negative scrap quantities, which would cause negative yield-loss KPIs |
| **Injected Anomaly** | `scrap_quantity = -500.0` on `WO-2023003` |
| **Objective** | Verify that MultiSourceValidator's business rule engine detects `scrap_quantity < 0` as a constraint violation. |

**Test Steps:**
1. Instantiate `MultiSourceValidator`.
2. Call `validate_business_logic_expression()` with rule: `scrap_quantity >= 0`.
3. Target table: `fact_work_orders` in corrupted DWH.
4. Assert `result["status"] == "FAIL"`.
5. Assert `result["violations_count"] > 0`.

**Expected Result:** 1 violation record (`WO-2023003`, `scrap_quantity = -500.0`). Status = FAIL.

**Actual Result:** ✅ PASS (defect detected) — `status=FAIL`, `violations_count=1`.

---

## Summary Table

| Test ID | Test Name | Scope | Type | Expected | Actual |
| :--- | :--- | :--- | :---: | :---: | :---: |
| TC-P01 | Schema Table Creation | Structural | PASS | PASS | ✅ PASS |
| TC-P02 | Migration Row Count | Load Completeness | PASS | PASS | ✅ PASS |
| TC-P03 | Volume Reconciliation | Volume | PASS | PASS | ✅ PASS |
| TC-P04 | Attribute Cell Validation | Attribute | PASS | 100% Match | ✅ PASS |
| TC-P05 | Aggregate Reconciliation | Aggregate | PASS | 4/4 Metrics | ✅ PASS |
| TC-P06 | Multi-Source Consistency | Cross-System | PASS | PASS | ✅ PASS |
| TC-P07 | Data Scaler FK Integrity | Scaling | PASS | 0 FK Violations | ✅ PASS |
| TC-F01 | Volume: Missing 3 Rows | Volume | FAIL | FAIL/WARNING | ✅ Detected |
| TC-F02 | Volume: Truncated Table (50 rows) | Volume | FAIL | FAIL/WARNING | ✅ Detected |
| TC-F03 | Attribute: Numeric Corruption | Attribute | FAIL | FAIL | ✅ Detected |
| TC-F04 | Attribute: Invalid String Enum | Attribute | FAIL | FAIL | ✅ Detected |
| TC-F05 | Aggregate: Zeroed Cost Measures | Aggregate | FAIL | FAIL | ✅ Detected |
| TC-F06 | Multi-Source: Cross-System Drift | Cross-System | FAIL | FAIL | ✅ Detected |
| TC-F07 | Business Rule: Negative Scrap | Business Rule | FAIL | FAIL | ✅ Detected |

**Final Result: 14/14 Tests Passed (`Ran 14 tests in 70.527s — OK`)**
