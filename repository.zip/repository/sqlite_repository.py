"""
SQLite Repository Layer for Persisting Test Executions, Detailed Results, and Mismatches.
Enables execution history retrieval, search, filtering, and replaying past runs.
"""
import os
import json
import sqlite3
import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from config.settings import REPO_DB_PATH
from config.models import ExecutionSummary, TestResult, MismatchRecord, TestStatus


class SQLiteRepository:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or REPO_DB_PATH
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._get_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS executions (
                    execution_id TEXT PRIMARY KEY,
                    timestamp TEXT NOT NULL,
                    scenario_name TEXT NOT NULL,
                    source_desc TEXT NOT NULL,
                    target_desc TEXT NOT NULL,
                    overall_status TEXT NOT NULL,
                    total_validations INTEGER DEFAULT 0,
                    passed_count INTEGER DEFAULT 0,
                    failed_count INTEGER DEFAULT 0,
                    warnings_count INTEGER DEFAULT 0,
                    errors_count INTEGER DEFAULT 0,
                    pass_rate_pct REAL DEFAULT 100.0,
                    total_rows_audited INTEGER DEFAULT 0,
                    total_cells_audited INTEGER DEFAULT 0,
                    total_mismatches INTEGER DEFAULT 0,
                    cell_match_pct REAL DEFAULT 100.0,
                    execution_duration_sec REAL DEFAULT 0.0,
                    config_json TEXT,
                    report_html_path TEXT,
                    report_excel_path TEXT
                );
            """)

            conn.execute("""
                CREATE TABLE IF NOT EXISTS test_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    execution_id TEXT NOT NULL,
                    test_name TEXT NOT NULL,
                    category TEXT NOT NULL,
                    status TEXT NOT NULL,
                    source_metric TEXT,
                    target_metric TEXT,
                    delta TEXT,
                    delta_pct REAL,
                    details_json TEXT,
                    mismatches_count INTEGER DEFAULT 0,
                    execution_time_sec REAL DEFAULT 0.0,
                    FOREIGN KEY (execution_id) REFERENCES executions(execution_id)
                );
            """)

            conn.execute("""
                CREATE TABLE IF NOT EXISTS mismatches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    execution_id TEXT NOT NULL,
                    validation_test TEXT NOT NULL,
                    record_key TEXT NOT NULL,
                    source_column TEXT,
                    target_column TEXT,
                    source_value TEXT,
                    target_value TEXT,
                    difference TEXT,
                    status TEXT DEFAULT 'MISMATCH',
                    FOREIGN KEY (execution_id) REFERENCES executions(execution_id)
                );
            """)
            conn.commit()

    def save_execution(self, summary: ExecutionSummary) -> str:
        """Persists the complete execution summary, test results, and mismatches."""
        with self._get_conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO executions (
                    execution_id, timestamp, scenario_name, source_desc, target_desc,
                    overall_status, total_validations, passed_count, failed_count,
                    warnings_count, errors_count, pass_rate_pct, total_rows_audited,
                    total_cells_audited, total_mismatches, cell_match_pct,
                    execution_duration_sec, config_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                summary.execution_id,
                summary.timestamp,
                summary.scenario_name,
                summary.source_desc,
                summary.target_desc,
                summary.overall_status.value,
                summary.total_validations,
                summary.passed_count,
                summary.failed_count,
                summary.warnings_count,
                summary.errors_count,
                summary.pass_rate_pct,
                summary.total_rows_audited,
                summary.total_cells_audited,
                summary.total_mismatches,
                summary.cell_match_pct,
                summary.execution_duration_sec,
                json.dumps(summary.config, default=str) if summary.config else None
            ))

            for r in summary.results:
                conn.execute("""
                    INSERT INTO test_results (
                        execution_id, test_name, category, status, source_metric,
                        target_metric, delta, delta_pct, details_json, mismatches_count, execution_time_sec
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    summary.execution_id,
                    r.test_name,
                    r.category,
                    r.status.value,
                    str(r.source_metric) if r.source_metric is not None else None,
                    str(r.target_metric) if r.target_metric is not None else None,
                    str(r.delta) if r.delta is not None else None,
                    r.delta_pct,
                    json.dumps(r.details, default=str) if r.details else None,
                    r.mismatches_count,
                    r.execution_time_sec
                ))

            for m in summary.mismatches[:1000]:  # Cap at max saved mismatches
                conn.execute("""
                    INSERT INTO mismatches (
                        execution_id, validation_test, record_key, source_column,
                        target_column, source_value, target_value, difference, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    summary.execution_id,
                    m.validation_test,
                    m.record_key,
                    m.source_column,
                    m.target_column,
                    str(m.source_value),
                    str(m.target_value),
                    str(m.difference),
                    m.status
                ))

            conn.commit()
        return summary.execution_id

    def list_executions(self, limit: int = 50, status_filter: Optional[str] = None, scenario_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        """Returns historical execution records with filtering."""
        query = "SELECT * FROM executions WHERE 1=1"
        params = []

        if status_filter and status_filter != "ALL":
            query += " AND overall_status = ?"
            params.append(status_filter)

        if scenario_filter:
            query += " AND scenario_name LIKE ?"
            params.append(f"%{scenario_filter}%")

        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self._get_conn() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Fetches full execution details including test results and mismatches."""
        with self._get_conn() as conn:
            exec_row = conn.execute("SELECT * FROM executions WHERE execution_id = ?", (execution_id,)).fetchone()
            if not exec_row:
                return None

            data = dict(exec_row)
            
            # Fetch test results
            results_rows = conn.execute("SELECT * FROM test_results WHERE execution_id = ?", (execution_id,)).fetchall()
            data["results"] = [dict(r) for r in results_rows]

            # Fetch mismatches
            mismatch_rows = conn.execute("SELECT * FROM mismatches WHERE execution_id = ?", (execution_id,)).fetchall()
            data["mismatches"] = [dict(m) for m in mismatch_rows]

            return data

    def get_mismatches(self, execution_id: str, limit: int = 200, offset: int = 0, search: Optional[str] = None) -> Tuple[List[Dict[str, Any]], int]:
        """Returns paginated mismatch records for an execution."""
        query = "SELECT * FROM mismatches WHERE execution_id = ?"
        count_query = "SELECT COUNT(*) FROM mismatches WHERE execution_id = ?"
        params = [execution_id]
        count_params = [execution_id]

        if search:
            search_clause = " AND (record_key LIKE ? OR source_column LIKE ? OR target_column LIKE ?)"
            query += search_clause
            count_query += search_clause
            for _ in range(3):
                params.append(f"%{search}%")
                count_params.append(f"%{search}%")

        query += " LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        with self._get_conn() as conn:
            total_count = conn.execute(count_query, count_params).fetchone()[0]
            cursor = conn.execute(query, params)
            records = [dict(row) for row in cursor.fetchall()]
            return records, total_count
