"""
Mismatch CSV Exporter.
Exports paginated and filtered mismatch records to CSV or Excel for audit investigation.
"""
import pandas as pd
from typing import List
from config.models import MismatchRecord


class MismatchReporter:
    @staticmethod
    def export_csv(mismatches: List[MismatchRecord], output_path: str) -> str:
        data = [
            {
                "Validation Test": m.validation_test,
                "Record Key": m.record_key,
                "Source Column": m.source_column,
                "Target Column": m.target_column,
                "Source Value": m.source_value,
                "Target Value": m.target_value,
                "Difference": m.difference,
                "Status": m.status
            }
            for m in mismatches
        ]
        df = pd.DataFrame(data)
        df.to_csv(output_path, index=False)
        return output_path
