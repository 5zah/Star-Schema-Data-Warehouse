"""
Excel Multi-Tab Audit Report Generator.
Outputs formatted workbook containing:
- Executive Summary
- Volume Reconciliation
- Attribute / Cell Validation
- Aggregate Measures
- Business Rules
- Mismatch Details
"""
import pandas as pd
from pathlib import Path
from config.models import ExecutionSummary, TestStatus


class ExcelReporter:
    def __init__(self, summary: ExecutionSummary):
        self.summary = summary

    def generate(self, output_path: str) -> str:
        s = self.summary
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
            # 1. Summary Sheet
            summary_data = [
                {"KPI / Parameter": "Execution ID", "Value": s.execution_id},
                {"KPI / Parameter": "Timestamp", "Value": s.timestamp},
                {"KPI / Parameter": "Scenario Name", "Value": s.scenario_name},
                {"KPI / Parameter": "Source Object", "Value": s.source_desc},
                {"KPI / Parameter": "Target Object", "Value": s.target_desc},
                {"KPI / Parameter": "Overall Status", "Value": s.overall_status.value},
                {"KPI / Parameter": "Pass Rate %", "Value": s.pass_rate_pct},
                {"KPI / Parameter": "Total Validations", "Value": s.total_validations},
                {"KPI / Parameter": "Passed Validations", "Value": s.passed_count},
                {"KPI / Parameter": "Failed Validations", "Value": s.failed_count},
                {"KPI / Parameter": "Total Rows Audited", "Value": s.total_rows_audited},
                {"KPI / Parameter": "Total Cells Audited", "Value": s.total_cells_audited},
                {"KPI / Parameter": "Cell Match %", "Value": s.cell_match_pct},
                {"KPI / Parameter": "Total Mismatches", "Value": s.total_mismatches},
                {"KPI / Parameter": "Execution Duration (sec)", "Value": s.execution_duration_sec},
            ]
            pd.DataFrame(summary_data).to_excel(writer, sheet_name="Executive Summary", index=False)

            # 2. Test Results Sheet
            results_data = [
                {
                    "Status": r.status.value,
                    "Category": r.category,
                    "Validation Test": r.test_name,
                    "Source Metric": r.source_metric,
                    "Target Metric": r.target_metric,
                    "Delta / Discrepancy": r.delta,
                    "Delta %": r.delta_pct,
                    "Mismatches Count": r.mismatches_count,
                    "Execution Time (s)": r.execution_time_sec
                }
                for r in s.results
            ]
            pd.DataFrame(results_data).to_excel(writer, sheet_name="Validation Results", index=False)

            # 3. Volume Validation Sheet
            volume_data = [
                {
                    "Test": r.test_name,
                    "Status": r.status.value,
                    "Source Rows": r.source_metric,
                    "Target Rows": r.target_metric,
                    "Delta": r.delta,
                    "Delta %": r.delta_pct
                }
                for r in s.results if r.category == "Volume"
            ]
            if volume_data:
                pd.DataFrame(volume_data).to_excel(writer, sheet_name="Volume Reconciliation", index=False)

            # 4. Aggregates Sheet
            agg_data = [
                {
                    "Test": r.test_name,
                    "Status": r.status.value,
                    "Source Metric": r.source_metric,
                    "Target Metric": r.target_metric,
                    "Delta": r.delta,
                    "Delta %": r.delta_pct
                }
                for r in s.results if r.category == "Aggregates"
            ]
            if agg_data:
                pd.DataFrame(agg_data).to_excel(writer, sheet_name="Aggregate Measures", index=False)

            # 5. Business Rules Sheet
            rule_data = [
                {
                    "Rule": r.test_name,
                    "Status": r.status.value,
                    "Records Evaluated": r.source_metric,
                    "Compliance Metric": r.target_metric,
                    "Violations": r.delta
                }
                for r in s.results if r.category == "Business Rules"
            ]
            if rule_data:
                pd.DataFrame(rule_data).to_excel(writer, sheet_name="Business Rules", index=False)

            # 6. Mismatch Details Sheet
            mismatch_data = [
                {
                    "Validation Test": m.validation_test,
                    "Record Key": m.record_key,
                    "Source Column": m.source_column,
                    "Target Column": m.target_column,
                    "Source Value": m.source_value,
                    "Target Value": m.target_value,
                    "Difference": m.difference,
                    "Status": m.status
                }
                for m in s.mismatches[:5000]
            ]
            if mismatch_data:
                pd.DataFrame(mismatch_data).to_excel(writer, sheet_name="Mismatch Drill-Down", index=False)

        return output_path
