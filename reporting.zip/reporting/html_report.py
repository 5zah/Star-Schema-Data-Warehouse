"""
HTML Report Generator matching the Visual & Architectural Structure of the Reference Report.
Generates a standalone, beautiful HTML dashboard with KPI cards, validation category sections,
reconciliation tables, pass/fail indicators, aggregates, and mismatch drill-down tables.
"""
import os
import datetime
from pathlib import Path
from config.models import ExecutionSummary, TestStatus


class HTMLReporter:
    def __init__(self, summary: ExecutionSummary):
        self.summary = summary

    def generate(self, output_path: str) -> str:
        s = self.summary
        
        status_color = "#10b981" if s.overall_status == TestStatus.PASS else "#ef4444"
        status_bg = "rgba(16, 185, 129, 0.1)" if s.overall_status == TestStatus.PASS else "rgba(239, 68, 68, 0.1)"

        # Generate Test Result Rows
        test_rows_html = ""
        for r in s.results:
            badge_color = "#10b981" if r.status == TestStatus.PASS else "#ef4444" if r.status == TestStatus.FAIL else "#f59e0b"
            badge_bg = "rgba(16, 185, 129, 0.12)" if r.status == TestStatus.PASS else "rgba(239, 68, 68, 0.12)" if r.status == TestStatus.FAIL else "rgba(245, 158, 11, 0.12)"
            
            test_rows_html += f"""
            <tr>
                <td style="padding: 12px; border-bottom: 1px solid #1f2937;">
                    <span style="background: {badge_bg}; color: {badge_color}; border: 1px solid {badge_color}40; padding: 4px 8px; border-radius: 6px; font-weight: 700; font-size: 11px;">
                        {r.status.value}
                    </span>
                </td>
                <td style="padding: 12px; border-bottom: 1px solid #1f2937; font-weight: 600; color: #f3f4f6;">{r.category}</td>
                <td style="padding: 12px; border-bottom: 1px solid #1f2937; color: #818cf8; font-weight: 500;">{r.test_name}</td>
                <td style="padding: 12px; border-bottom: 1px solid #1f2937; font-family: monospace; color: #9ca3af;">{r.source_metric or '-'}</td>
                <td style="padding: 12px; border-bottom: 1px solid #1f2937; font-family: monospace; color: #9ca3af;">{r.target_metric or '-'}</td>
                <td style="padding: 12px; border-bottom: 1px solid #1f2937; font-family: monospace; color: {'#34d399' if r.status == TestStatus.PASS else '#f87171'}; font-weight: 600;">{r.delta or '0'}</td>
                <td style="padding: 12px; border-bottom: 1px solid #1f2937; color: #9ca3af; font-size: 11px;">{r.execution_time_sec}s</td>
            </tr>
            """

        # Generate Mismatch Sample Rows
        mismatch_rows_html = ""
        for m in s.mismatches[:50]:
            mismatch_rows_html += f"""
            <tr>
                <td style="padding: 10px; border-bottom: 1px solid #1f2937; color: #cbd5e1; font-family: monospace; font-size: 11px;">{m.record_key}</td>
                <td style="padding: 10px; border-bottom: 1px solid #1f2937; color: #818cf8; font-family: monospace; font-size: 11px;">{m.source_column}</td>
                <td style="padding: 10px; border-bottom: 1px solid #1f2937; color: #38bdf8; font-family: monospace; font-size: 11px;">{m.target_column}</td>
                <td style="padding: 10px; border-bottom: 1px solid #1f2937; color: #f87171; font-family: monospace; font-size: 11px;">{m.source_value}</td>
                <td style="padding: 10px; border-bottom: 1px solid #1f2937; color: #34d399; font-family: monospace; font-size: 11px;">{m.target_value}</td>
                <td style="padding: 10px; border-bottom: 1px solid #1f2937; color: #facc15; font-family: monospace; font-size: 11px;">{m.difference}</td>
            </tr>
            """

        if not mismatch_rows_html:
            mismatch_rows_html = """
            <tr>
                <td colspan="6" style="padding: 24px; text-align: center; color: #9ca3af;">No record discrepancies found. All checks passed with 100% parity.</td>
            </tr>
            """

        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETL Reconciliation Audit Report - {s.execution_id}</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {{
            font-family: 'Outfit', sans-serif;
            background: #090d16;
            color: #f3f4f6;
            margin: 0;
            padding: 32px;
        }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .header {{
            background: rgba(17, 24, 39, 0.7);
            backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 20px;
            padding: 24px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }}
        .kpi-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }}
        .kpi-card {{
            background: rgba(17, 24, 39, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 16px;
            padding: 20px;
        }}
        .kpi-title {{ font-size: 11px; text-transform: uppercase; font-weight: 700; color: #9ca3af; letter-spacing: 0.05em; }}
        .kpi-value {{ font-size: 28px; font-weight: 800; margin-top: 4px; color: #818cf8; }}
        .card {{
            background: rgba(17, 24, 39, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 20px;
            padding: 24px;
            margin-bottom: 24px;
        }}
        .card-title {{ font-size: 18px; font-weight: 700; color: #ffffff; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }}
        table {{ width: 100%; border-collapse: collapse; text-align: left; font-size: 12px; }}
        th {{ background: #111827; padding: 12px; color: #9ca3af; text-transform: uppercase; font-size: 10px; font-weight: 700; border-bottom: 1px solid #1f2937; }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div>
                <h1 style="margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.02em;">
                    RECONCILIATION <span style="color: #818cf8;">AUDIT REPORT</span>
                </h1>
                <p style="margin: 4px 0 0 0; color: #9ca3af; font-size: 12px;">
                    Scenario: <strong>{s.scenario_name}</strong> &bull; {s.source_desc} &rarr; {s.target_desc}
                </p>
            </div>
            <div>
                <span style="background: {status_bg}; color: {status_color}; border: 1px solid {status_color}40; padding: 8px 16px; border-radius: 12px; font-weight: 800; font-size: 14px;">
                    {s.overall_status.value}
                </span>
            </div>
        </div>

        <!-- KPI Grid -->
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-title">PASS RATE</div>
                <div class="kpi-value" style="color: {status_color};">{s.pass_rate_pct}%</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-title">TOTAL VALIDATIONS</div>
                <div class="kpi-value">{s.total_validations}</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-title">ROWS AUDITED</div>
                <div class="kpi-value">{s.total_rows_audited:,}</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-title">CELL MATCH RATE</div>
                <div class="kpi-value" style="color: #38bdf8;">{s.cell_match_pct}%</div>
            </div>
            <div class="kpi-card">
                <div class="kpi-title">EXECUTION TIME</div>
                <div class="kpi-value" style="color: #c084fc;">{s.execution_duration_sec}s</div>
            </div>
        </div>

        <!-- Validation Results Section -->
        <div class="card">
            <div class="card-title">Validation Suites & Reconciliation Checks</div>
            <table>
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Category</th>
                        <th>Validation Test</th>
                        <th>Source Metric</th>
                        <th>Target Metric</th>
                        <th>Delta / Discrepancy</th>
                        <th>Duration</th>
                    </tr>
                </thead>
                <tbody>
                    {test_rows_html}
                </tbody>
            </table>
        </div>

        <!-- Mismatch Drill-Down Section -->
        <div class="card">
            <div class="card-title">Mismatch & Discrepancy Drill-Down (Sample)</div>
            <table>
                <thead>
                    <tr>
                        <th>Record Key</th>
                        <th>Source Column / Rule</th>
                        <th>Target Column</th>
                        <th>Source / Expected Value</th>
                        <th>Target / Actual Value</th>
                        <th>Difference</th>
                    </tr>
                </thead>
                <tbody>
                    {mismatch_rows_html}
                </tbody>
            </table>
        </div>

        <div style="text-align: center; color: #6b7280; font-size: 11px; margin-top: 32px;">
            Generated by Production ETL Validation Platform &bull; {s.timestamp} &bull; Execution ID: {s.execution_id}
        </div>
    </div>
</body>
</html>
"""
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html_content)
        return output_path
